
#ifndef _PASS_2_H
#define _PASS_2_H

int pass_2(void);
int create_a_new_section_structure(void);

#endif
