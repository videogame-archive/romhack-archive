FF4Ultima_MObreckPatches.zip

Patches:

-The Goblin All The Bravest sprite replacer
-The Cockatrice, Red Giant, and Coeurl All The Bravest sprite replacer
-Rosa, Palom, Porom, Golbez, and both Rydia sprite replacers based off Pixel Remaster (Heavily edited to conform with the SNES version's size and palette restrictions)

Other notes:

-All the player sprites except Golbez should work with both Ultima and any unheadered 1.1 version of Final Fantasy 2 SNES. Golbez only works with Ultima due to modifying the custom playable version.
-The enemy patches need Ultima and the v2 version of the 4BPP patch installed to work properly