package services.lz;

public abstract class Command {

    abstract public byte[] getBytes();
}
