SNES Japanese To English Translation
=====================================
<br />
** This translation is now discontinued **<br />
Please go to: https://www.romhacking.net/translations/5666/<br />
For a full 100% complete translation.
