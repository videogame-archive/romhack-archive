                --------------------------
                | Magic Knight Rayearth  |
                --------------------------

   ++++++++++++++++++++++++++++++++++++++++++++++++++++
   +          Unofficial English Translation          +
   ++++++++++++++++++++++++++++++++++++++++++++++++++++
   +        March 18th, 1999  - Version 1.00          +
   ++++++++++++++++++++++++++++++++++++++++++++++++++++

* Note * - Please do NOT distribute the patch file without
this file, since it contains important information.

  This is the Unofficial Magic Knight Rayearth english translation!
It has been a great experience to work on this game and we are proud
to present you the best. This project was considered at first, the 
impossible game, due to its weird script compression. But with the 
awesome effort of our team and the skills of a lot of great people, we
were able to produce the best! 

  To get the latest version of Magic Knight Rayearth or any of
our other great translations, go visit the RPGe Home Page,
at http://www.lfx.org/rpge/.

----------------------------------------------------------
 C O N T E N T S
----------------------------------------------------------

1. What's New?
2. Introduction
3. How to play
   3a. Controller Functions
4. Credits and Special Thanks
5. RPGe
6. Disclaimer

----------------------------------------------------------
1. What's New?
----------------------------------------------------------

v1.0 (3/18/99):
- Wai! The patch is released! ^_^
v1.01 (3/19/99):
- Spelling errors corrected
- Bonus patch added

----------------------------------------------------------
2. Introduction
----------------------------------------------------------

  The translation of Magic Knight Rayearth is the result of the
combined effort of many people. Starting off with the project's
founder Dibz` along with hacker StSCC and translator Makutosu.
The project encountered some problems, mostly because of the
main dialogue pointers and it was paused. Then the cute, awesome, 
amazing and powerful, Lina-chan took over the project. (That's me!)
With Dibz`, StSCC and Makutosu as former members and mentors. After
a few months Lina managed to figure out the secret to the mysterious
pointers and started inserting the little she had translated already
while she fried her mind with the hacking. Then the ASM God, Neill
Corlett decided to help the MKR team by doing an amazing job with
the font, enabling us to fit more characters per window. A month or 
so later the main hacker for this game joined, LordTech, and basically
redid everything from scratch, using his amazing talents. Shortly
after, translator Nuku-Nuku joined the team, doing an excellent and 
near to perfect job, in our honest opinion.

----------------------------------------------------------
3. How to Start
----------------------------------------------------------

  The archive includes an IPS file.  The IPS file is to be
applied to ROM images acquired from somewhere else, and
it's up to you to obtain it.

  First, you need a copy of the Magic Knight Rayearth ROM image,
and an IPS patching program.  An easy-to-use patching
program for MS-DOS based systems, IPS.EXE, can be obtained
at RPGe (http://www.lfx.org/rpge/archives/).

  This patch must be applied to the ORIGINAL, unmodified
ROM.

  To use IPS.EXE with the Magic Knight Rayearth patch, get
yourself a DOS prompt and type the following:

  IPS MKR.SMC MKR-V101.IPS

  Replace MKR.SMC with the filename of your ROM image.

  After you've patched your ROM image, load the game
inside your favorite SNES emulator, and you should see the
intro screen.  You're ready to start.

Included with the translation patch is another patch, mkrhard.ips, to 
make the game a little more difficult.  The patch modifies the way 
life increases throughout the game.  It is not necessary to use this
patch and it is suggested that you play the game normally first.  

----------------------------------------------------------
3a. Controller functions:
----------------------------------------------------------

  The controls are similar to those in Final Fantasy II,
and Final Fantasy III, released in English for the SNES.

Walkabout mode:
D-Pad    : Move characters
A Button : Confirm
B Button : Cancel
X Button : Activate Menu screen

Menu mode:
D-Pad    : Move cursor
A Button : Confirm
B Button : Cancel
L/R      : Previous/Next

Battle mode:
D-Page   : Move cursor
A Button : Confirm
B Button : Cancel


----------------------------------------------------------
4. Credits and Special Thanks
----------------------------------------------------------

  Magic Knight Rayearth was worked on by the following members 
of RPGe:

Dibz`     : Project Founder
            ROM editing
StSCC     : Script Dumper
Maktosu   : Item/Spell/Monster Translator
Lina-chan : Project Leader
            Preliminary dialogue translation
            Early Hacking
            Dialogue revision
Nuku-Nuku : Dialogue translation
LordTech  : Dialogue revision
            Main ROM hacker
            Title Screen Artist
Neill1712 : Early Font Hacker
aziwoqpd  : Title Screen Hacker



  Special thanks to the following for helping to make this
project possible:

blahblah  :  Menu Descriptions
awj       :  Beta Tester
Dantares  :  Beta Tester


And all the people on EFNET's #romhack ^_^

----------------------------------------------------------
5. RPGe
----------------------------------------------------------

  RPGe is a internet-based group of semi-intelligent
people who like to share their hobby, to translate video
games to English, with the world.

  The following is a list of the members of RPGe:

- MagitekKn       President
- harmony7        Web Site Maintainer
- Lina-chan       Assistant Web Site Maintainer 
- Barubary
- CrazyBred
- Som2Freak
- Dibz
- Makutosu
- StSCC
- Nuku-Nuku
- LordTech
- maht
- Rydia_

  You can reach us at http://www.lfx.org/rpge/.  If you need
to send e-mail, direct it to rpge@lfx.org.  If you need
to contact a specific member, see the feedback page at the
RPGe web site.

----------------------------------------------------------
6. Disclaimer
----------------------------------------------------------

Magic Knight Rayearth and all other likenesses are copyright
of CLAMP.

(c) 1999 RPGe

There is no video game company or any other company
associated with RPGe.  In no event shall RPGe be held
liable or responsible for any damages that may occur from
direct, indirect, or consequential results of the ability
or disability to use or misuse any material it provides.
