# bring your own dump!  

```
name: Super Famicom Wars (Japan) (NP).sfc
md5:  d88b4ed9a9d834696357ce4c9ef95359
```
