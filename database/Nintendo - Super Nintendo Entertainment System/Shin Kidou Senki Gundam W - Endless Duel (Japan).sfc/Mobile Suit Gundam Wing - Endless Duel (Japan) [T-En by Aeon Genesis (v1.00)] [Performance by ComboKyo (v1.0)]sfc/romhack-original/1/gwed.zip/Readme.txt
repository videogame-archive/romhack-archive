GUNDAM WING - ENDLESS DUEL
ENGLISH TRANSLATION V1.00
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Gundam Wing
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions

-------------------
1.About Gundam Wing
-------------------
Gundam Wing is a tournament fighter. There's a pitifully
small amount of text in it, and it didn't really -need-
to be translated, but it was a quick project (sort of...)
it was fun to work on, and it's a great game that deserves
some attention. So here it is!

---------------
2.Patch History
---------------
This particular translation project started on February 23,
1999. No kidding. It, along with a crappy Dragonball Z game,
was one of my first two projects. Well guess what? As soon
as I started working on it, it went nowhere fast. Two months
later, it was still going nowhere fast. It kept up that
blistering pace of going nowhere fast for over three years
when I finally acquired enough skill to be able to hack it.
Five days later, the project was complete. Whoo!

June 23, 2002 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE GUNDAM WING TEAN
Gideon Zhi - Project leader, romhacker
satsu - Visual art support
Shih Tzu, Eien Ni Hen, Tetsuo, Healeth - MO's board support.
Thanks a million, guys! It feels great to finally get this
out the door!

--------------
4.Known Issues
--------------
There are no known issues.
Please report any bugs, spelling errors, and such
on The Pantheon (http://donut.parodius.com/agtp)

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "live.smc" make sure the patch
is "live.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM DOES HAVE
a header. If you right-click the ROM and select Properties, it
should read "Size: 2.00MB (2,097,664 bytes)". SNESTool will add
headers to your ROM easily enough; the answers to the questions it
prompts you with only matter if you have a copier.
