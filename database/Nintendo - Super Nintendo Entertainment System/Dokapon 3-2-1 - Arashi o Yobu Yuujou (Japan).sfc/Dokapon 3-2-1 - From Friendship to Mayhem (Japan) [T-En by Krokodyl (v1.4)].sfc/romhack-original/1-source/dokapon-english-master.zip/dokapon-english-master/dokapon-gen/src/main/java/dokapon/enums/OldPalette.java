package dokapon.enums;

public abstract class OldPalette {

    public abstract FontColor getFontColor(int i);
    public abstract FontColor getFontColor(String hexa);

}
