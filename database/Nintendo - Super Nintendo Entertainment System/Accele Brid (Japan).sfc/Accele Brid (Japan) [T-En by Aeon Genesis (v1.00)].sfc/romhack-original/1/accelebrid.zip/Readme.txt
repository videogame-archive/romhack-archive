ACCELEBRID
ENGLISH TRANSLATION V1.00
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Accelebrid
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions

------------------
1.About Accelebrid
------------------
Accelebrid is a chase-view shooter. The main character,
Ginei, is heading off in his high-powered combat suit
"Silver Mare" to do battle with a group of terrorists
who attacked the G.Bowman circuit of the Accelebrid
race and kidnapped his manager girlfriend person. Okay,
so it doesn't have much of a story, but c'mon, it's a
SHOOTER.

---------------
2.Patch History
---------------
The work was all but completed between the dates of
April 17 and April 23 or so. Then the boss speeches
pissed me off and I stopped. The boss speeches are
"done" to the best of my ability in this patch. I'm
not 100% satisfied with 'em, but it's a friggin'
shooter and it works and it doesn't look nasty or
anything. I just wish I could have fit more text in
there.

May 28, 2002 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE ACCELEBRID TEAN
Gideon Zhi - Project leader, romhacker
Ian Kelley - Translator
Tomato - Translator
Oogami - Translator
Kyo, EienNiHen, Shih Tzu - MO's Board Translation

--------------
4.Known Issues
--------------
There are no known issues.
Please report any bugs, spelling errors, and such
on The Pantheon (http://donut.parodius.com/agtp)

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "live.smc" make sure the patch
is "live.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM DOES NOT HAVE
a header. If you right-click the ROM and select Properties, it
should read "Size: 2.00MB (2,097,152 bytes)". SNESTool will remove all
of your headers for you easily.
