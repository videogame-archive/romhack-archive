package dokapon.lz.entities;

public enum NodeType {

    UNTREATED,
    REPEAT,
    DATA
}
