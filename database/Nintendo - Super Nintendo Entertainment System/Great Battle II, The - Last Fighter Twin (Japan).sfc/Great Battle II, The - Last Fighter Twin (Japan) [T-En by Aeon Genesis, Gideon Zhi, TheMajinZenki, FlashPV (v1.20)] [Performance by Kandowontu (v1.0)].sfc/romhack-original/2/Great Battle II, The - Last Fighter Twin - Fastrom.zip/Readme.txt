This is FASTROM for The Great Battle II: Last Fighter Twin and is fully compatible with the Aeon Genesis translation.

MISTER Cheat files have been provided for both japanese and english translation roms.

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5