        .,g8$$$$$$$$$$$$$$$$$$$$$$"""""$$$$$$$$$$$$$$$$$$$$$$$$$$$$8g,.       
       d$$$$$$$$     $$P$"`"$OY$$$     l$$$$$$$$$$$$$`````$$$$$$$$$$$$$b       
      l$$$$$$$$$     $l   dy,  'Y$     '$$$$$$$     $$$$$$$$$$$$$$$$$$$$l      
      $$$$$$$$$$     l`  l$$b    Y      'Y$$$P`     $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$         $$""             `$`       $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$     b   `Y$$$$$$$     by,   ,d     $     $$$$$$$$$$$$$$$      
      $$$$$$P$"      $b      $""""     $$$$y$$$     $     $$$$$$$$$$$$$$$      
      $$P$"   ,y     $"   ,  $   l     $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$     d$$         `$  $b        $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$b    """     b                 $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$$8y,.        $8y,     .,y8$$$$$$$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$$    $$$$$$$$$$$$$$$$$$$$$$$$$$ggggg$$$$$$$$$$$$$$$$$$$$$      
      $$$P$"""$OY    P_"`"OY$""""""""$OY$$$$$$$$$P$"""$OY$$$$P$"`"$OY$$$$      
      $$l   dy,    .$       'Y$$$8$by,  'Y$$$$$$l   dy,  'Y$l   dy,  'Y$$      
      $l`  l$$b        ,g,    Y     $b    Y$$$$l`  l$$b    l`  l$$b    Y$      
      $    $$""        l$l    l     $'   ,d$$$$    $$""        $$""     $      
      $b   `Y$$$$$    ;$P d   `     yy,    ``$l    $$$$$$$$b   `Y$$$$$$$$      
      $$b      $$$;   ;P d;         $$$$b     ;    $$$$$""""       $""""       
      $$"   ,yy$$$l     dl    ;     $$$$$l         $$$$$   l    ,  $   l       
      $    `$$$$$$b    `$'    d     $$$$$$     .   `$Y$$b      `$  $b          
      $     $$$$$$$b,       ,d$     $$$$$$     b                               
      $     $$$$$$$$$by,.,yd$$$ggggg$$$$$$     $8y,     .,y8$y,     .,y8$      
      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     $$$$$$$$$$$$$$$$$$$$$$$$$$      
                                                          trip(RMRS/iCE)    

                         " Let's fighting love "




                             R E L E A S E
,d$b.                    "" $$b  yy $$$$ ,d$$b,                          ,d$b.
$$  '                    $$ $$Yb $$ $$__ $$  $$                          `  $$
`qb                      $$ $$ Yb$$ $$"" $$  $S                            qb'
,d$b.                    $$ ``  $$$ $$   $YyyP$                          ,d$b.
`  $$                                                                    $$  '
  qb'         Release      : Famicom Detective Club II Translation       `qb
,d$b.         File         : NDF-F210.ZIP                                ,d$b.
$$  '         Validity     : [ ] Alpha   [ ] Beta     [x] Final          `  $$
`qb           Medium       : SNES                                          qb'
,d$b.         Version      : 1.00                                        ,d$b.
`  $$         Date         : 10-10-4                                     $$  '
  qb'                                                                    `qb
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'    CREDIT:                                                         `qb  
,d$b.                                                                    ,d$b.
$$  '       Translation: Demi, Haeleth                                   `  $$
`qb                                                                        qb'
,d$b.       Hacking: Demi, Bongo                                         ,d$b.
`  $$                                                                    $$  '
  qb'       Graphics: FuSoYa (compression), Demi (art)                   `qb  
,d$b.                                                                    ,d$b.
$$  '       Beta Testing: Haeleth, Gideon Zhi, Datenshi, Yuuchi          `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '    TRANSLATION NOTES:                                              `  $$
`qb                                                                        qb'
,d$b.       Oh man...  it's 7pm and  I've been  working on the  final    ,d$b.
`  $$      touches  on this  game  since I  woke  up, so  like,  this    $$  '
  qb'      readme is probably gonna come out all weird.                  `qb  
,d$b.                                                                    ,d$b.
$$  '       This has been a  project of mine for about the  last year    `  $$
`qb        and a half. I  got into shortly after we finished  work on      qb'
,d$b.      Radical Dreamers, when Tomato brought it  to my attention.    ,d$b.
`  $$      Apparently he'd  been shopping it  around to  a few of  us    $$  '
  qb'      translators after he'd decided he didn't  have enough time    `qb  
,d$b.      to work on it  himself. At the time he approached  me, the    ,d$b.
$$  '      most  help he'd  gotten  so far  was  from Bongo  --  he'd    `  $$
`qb        written  a partially  functional  variable-width font  for      qb'
,d$b.      the game. In addition, Tomato had  dumped some preliminary    ,d$b.
`  $$      japanese scripts himself.                                     $$  '
  qb'                                                                    `qb  
,d$b.       So when I  (Demi) took on the  project, I took a  look at    ,d$b.
$$  '      the total  amount of progress  that had  been made on  it,    `  $$
`qb        and went from there.  I expanded the rom and  remapped all      qb'
,d$b.      text pointers,  recoded  the variable  width font  (Bongo,    ,d$b.
`  $$      you were closer  than you may have thought),  redumped the    $$  '
  qb'      script into  a proprietary  format similar  to my  Radical    `qb  
,d$b.      Dreamers script, and translated the game from scratch.        ,d$b.
$$  '                                                                    `  $$
`qb         To give you  some sense of the  scope of this  project, I      qb'
,d$b.      think I've worked like 5 or 6  different places ever since    ,d$b.
`  $$      I started  this translation. I'm  a consultant though,  so    $$  '
  qb'      that's not  really bad  at all.  But man, this  one job  I    `qb  
,d$b.      had, it SUCKED,  okay? Well, no, the  job was cool  (I was    ,d$b.
$$  '      editing   children's  books   for   McGraw  Hill)...   the    `  $$
`qb        management was just  kind of incompetent. At one  point, I      qb'
,d$b.      got  so sick  of  all  the  bureaucracy there,  I  started    ,d$b.
`  $$      working on  this translation there  in the office  instead    $$  '
  qb'      of doing the miniscule  amount of work assigned to  me. So    `qb  
,d$b.      like, in addition to how you are  most likely breaking the    ,d$b.
$$  '      law because of playing  this game with a stolen  rom, rest    `  $$
`qb        assured in  knowing that you  are further corrupting  your      qb'
,d$b.      soul by  playing  a translated  game  which was  partially    ,d$b.
`  $$      created on  a Fortune  500 company's  dime, without  their    $$  '
  qb'      foreknowledge or consent. Booyah.                             `qb  
,d$b.                                                                    ,d$b.
$$  '       Anyhow, back  to  the lecture  at hand.  FuSoYa was  once    `  $$
`qb        again at my side  when it came time to hack  the graphics.      qb'
,d$b.      He helped me out bigtime with Radical  Dreamers and he was    ,d$b.
`  $$      no less the lifesaver here. The  graphics were compressed,    $$  '
  qb'      but he managed to crack the compression  in like 5 seconds    `qb  
,d$b.      or something.  He then built  me a  custom version of  his    ,d$b.
$$  '      Lunar Compress  tool  in no  time, which  allowed for  the    `  $$
`qb        compression   /  insertion   of   FDC2  format   graphics.      qb'
,d$b.      Inserting my  art  (the title  image,  the chapter  names,    ,d$b.
`  $$      etc) into the rom  was a snap -- his util  never failed me    $$  '
  qb'      once. Big ups to FuSoYa on this one.  Damn you got a funky    `qb  
,d$b.      name dude.                                                    ,d$b.
$$  '                                                                    `  $$
`qb         As I finished up  the translation, I invited a few  of my      qb'
,d$b.      Radical Dreamers beta  testers to come test the  game. One    ,d$b.
`  $$      of the guys  who really got into  it was Haeleth;  he went    $$  '
  qb'      above and beyond the  call of duty to really get  into the    `qb  
,d$b.      script and offer  a lot of retranslations for  things that    ,d$b.
$$  '      weren't up to snuff.  I really appreciated it, and  so, he    `  $$
`qb        got co-translator  credit  on this  project. This  release      qb'
,d$b.      wouldn't have  been  half of  what it  is  with you,  bud!    ,d$b.
`  $$      Thanks!                                                       $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$    GAME INFO:                                                      $$  '
  qb'                                                                    `qb  
,d$b.       This is actually a remake of a  Famicom Disk System game,    ,d$b.
$$  '      which is  in itself  a prequel  to Famicom Detective  Club    `  $$
`qb        Part I.  FDC1 is  elite,  I mean,  I wanna  find out  what      qb'
,d$b.      happens after the events in this  game and everything, but    ,d$b.
`  $$      I just can't seem to get into those nappy 8-bit graphics.     $$  '
  qb'                                                                    `qb  
,d$b.       There was a third game released  for the SNES Satellaview    ,d$b.
$$  '      add-on, but I haven't  gotten too far into it. All  I know    `  $$
`qb        is that  the  characters' mouths  move  really weird  when      qb'
,d$b.      they  talk in  it.  It's  like  watching cats  lick  their    ,d$b.
`  $$      butts... you can't seem to look away.                         $$  '
  qb'                                                                    `qb  
,d$b.       I don't wanna sound like I'm kissing  this game's ass too    ,d$b.
$$  '      much, but  it's  really got  an  intricate story.  There's    `  $$
`qb        been more than a  few times where I've found  myself going      qb'
,d$b.      "man, are these  mystery stories as difficult to  write as    ,d$b.
`  $$      I think they are?"  -- I dunno though, there's  a shitload    $$  '
  qb'      of Law  and Order and  CSI and whatever  on TV right  now.    `qb  
,d$b.      But to  be fair,  those shows  pale in  comparison to  the    ,d$b.
$$  '      hidden treasure that is Phamicom Detective Club Part Deux.    `  $$
`qb                                                                        qb'
,d$b.       Tomato and  Haeleth are the  resident experts on  Famicom    ,d$b.
`  $$      Detective Club  games.  Tomato got  me  interested in  the    $$  '
  qb'      series, and I know  he spent a period of time  when he got    `qb  
,d$b.      deep into  all kinds of  oldskool text-based horror  story    ,d$b.
$$  '      games like this. Haeleth  on the other hand spent  tons of    `  $$
`qb        time on Japanese websites in order to get  to know FDC2 so      qb'
,d$b.      well that  he was able  to beta test  the hell out  of it.    ,d$b.
`  $$      Sometimes he would figure stuff out, and  I'd just be like    $$  '
  qb'      "Uhh...  yeah!  Of course  I  knew  about  that!  Yeah..."    `qb  
,d$b.      Anyhow, if you  want to know  more about games  like this,    ,d$b.
$$  '      these are your guys.                                          `  $$
`qb                                                                        qb'
,d$b.       Finally, I'd like  to mention that I recently  started to    ,d$b.
`  $$      look into translating FDC1, but I don't  know if I'm going    $$  '
  qb'      to undertake it if it's as difficult as  I'm afraid it is.    `qb  
,d$b.      I heard a while  ago that some people were once  trying to    ,d$b.
$$  '      translate  this  (I  think  I've  heard  Necrosaro's  name    `  $$
`qb        tossed around once or  twice) but I don't think  I've ever      qb'
,d$b.      heard anything  about it publically.  I've got the  script    ,d$b.
`  $$      dumped almost  the way  I want  it, but I'm  having a  few    $$  '
  qb'      issues with  the pointers.  So, if  there's anybody  who'd    `qb  
,d$b.      like  to  share  some  knowledge  on  FDC1,  please  don't    ,d$b.
$$  '      hesitate to ask.  Haeleth has agreed to translate  it once    `  $$
`qb        a decent script is produced, and I don't  want to keep him      qb'
,d$b.      waiting.                                                      ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.    PATCHING INSTRUCTIONS:                                          ,d$b.
`  $$                                                                    $$  '
  qb'       There are  two versions  of the  Japanese rom out  there:    `qb  
,d$b.      1.0 and  1.1. You  gotta use  1.0 with  this patch.  Using    ,d$b.
$$  '      this patch on a 1.1 rom will make  it break. GoodSNES will    `  $$
`qb        help you  figure out  which rom  you have. Cherryroms  has      qb'
,d$b.      both  versions (I  think  it's  listed as  something  like    ,d$b.
`  $$      "Famicom Tantei Kurabu").                                     $$  '
  qb'                                                                    `qb  
,d$b.       I was  gonna  release patches  for both  versions of  the    ,d$b.
$$  '      rom,  cuz   I  built   my  translator   program  to   make    `  $$
`qb        translations for both  versions, but at the last  minute I      qb'
,d$b.      realized that  there's one teeny  tiny thing that  doesn't    ,d$b.
`  $$      work with the  1.1 rom. And  like, I coded  the translator    $$  '
  qb'      program with Visual C++ 6.0 years ago,  which I don't even    `qb  
,d$b.      have  on  my  computer anymore!!  I  only  use  .NET  now!    ,d$b.
$$  '      Ahhhhh!!!!                                                    `  $$
`qb                                                                        qb'
,d$b.       So like, if you manage to find out  what makes 1.1 really    ,d$b.
`  $$      really  REALLY REALLY  a  lot  better  than 1.0,  I  might    $$  '
  qb'      consider putting  dumbass  VC6 on  my  computer again  and    `qb  
,d$b.      fixing / recompiling my translator program  so that we can    ,d$b.
$$  '      all have version 1.1 translated too. But like, eh!!!!!        `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '    WORD UP:                                                        `  $$
`qb                                                                        qb'
,d$b.       Tomato - You translate  Dragon Ball for work. That  is so    ,d$b.
`  $$      cool, it makes me hurt all the way down in my peepee.         $$  '
  qb'                                                                    `qb  
,d$b.       Haeleth - You're very skilled at  balancing diplomacy and    ,d$b.
$$  '      pragmatism.  Good  luck  to  you  in   your  acedemic  and    `  $$
`qb        professional enveavours -- I'm sure you'll go far.              qb'
,d$b.                                                                    ,d$b.
`  $$       Culp - Go bit buster!!!!                                     $$  '
  qb'                                                                    `qb  
,d$b.       People at SquareEnix - Thank you for  the lovely music in    ,d$b.
$$  '      your  games.  Listening   to  your  soundtracks   while  I    `  $$
`qb        translate really seems to open up my doors.                     qb'
,d$b.                                                                    ,d$b.
`  $$       MO - We really do  need to go hang out some  time. I live    $$  '
  qb'      close enough now!!                                            `qb  
,d$b.                                                                    ,d$b.
$$  '       Spinner 8 - I'm gonna need around 5  random cuss words in    `  $$
`qb        the Whirlpool news item for this release.                       qb'
,d$b.                                                                    ,d$b.
`  $$       Y0shi  - h0h0h0  I  finally gave  you  money for  hosting    $$  '
  qb'      service!!! Did you ever think it was  gonna happen? 3y3 4m    `qb  
,d$b.      l337                                                          ,d$b.
$$  '                                                                    `  $$
`qb         FuSoYa - thanks again for Lunar Compress!                      qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb      DYSTRO:                                                           qb'
,d$b.                                                                    ,d$b.
`  $$       Demiforce Homepage .................... www.demiforce.com    $$  '
  qb'       Tomato's Non-Loser Page .............. tomato.starmen.net    `qb  
,d$b.       MO's Translation Board ............ donut.parodius.com/mo    ,d$b.
$$  '       FuSoYa's Niche ...................... fusoya.cg-games.net    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '    BTW:                                                            `  $$
`qb                                                                        qb'
,d$b.       Go see Napoleon Dynamite                                     ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
