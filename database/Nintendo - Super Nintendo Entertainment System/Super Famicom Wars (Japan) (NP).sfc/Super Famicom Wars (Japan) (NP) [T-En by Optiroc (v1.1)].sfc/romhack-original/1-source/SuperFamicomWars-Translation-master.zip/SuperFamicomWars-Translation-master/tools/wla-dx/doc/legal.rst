Legal Note
==========

WLA DX (the whole package) was originally written by Ville Helin in 1998-2008.
After that everybody has been able to take part in the development of WLA DX,
and recently via GitHub. The authors are not responsible for anything the
software does.

WLA DX is GPL software. For more information about GPL, take a look at the
``LICENCE`` file.

Game Boy and Game Boy Color are copyrighted by Nintendo.

Pocket Voice is copyrighted by Bung HK.