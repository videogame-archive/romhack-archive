package enums;

public enum PointerOption {
    
    MENU,
    COUNTER,
    INDIRECT,
    FIXED_LENGTH
    
}
