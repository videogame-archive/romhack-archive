        .,g8$$$$$$$$$$$$$$$$$$$$$$"""""$$$$$$$$$$$$$$$$$$$$$$$$$$$$8g,.       
       d$$$$$$$$     $$P$"`"$OY$$$     l$$$$$$$$$$$$$`````$$$$$$$$$$$$$b       
      l$$$$$$$$$     $l   dy,  'Y$     '$$$$$$$     $$$$$$$$$$$$$$$$$$$$l      
      $$$$$$$$$$     l`  l$$b    Y      'Y$$$P`     $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$         $$""             `$`       $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$     b   `Y$$$$$$$     by,   ,d     $     $$$$$$$$$$$$$$$      
      $$$$$$P$"      $b      $""""     $$$$y$$$     $     $$$$$$$$$$$$$$$      
      $$P$"   ,y     $"   ,  $   l     $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$     d$$         `$  $b        $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$b    """     b                 $$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$$8y,.        $8y,     .,y8$$$$$$$$$$$$$     $     $$$$$$$$$$$$$$$      
      $$$$$$$$$$$    $$$$$$$$$$$$$$$$$$$$$$$$$$ggggg$$$$$$$$$$$$$$$$$$$$$      
      $$$P$"""$OY    P_"`"OY$""""""""$OY$$$$$$$$$P$"""$OY$$$$P$"`"$OY$$$$      
      $$l   dy,    .$       'Y$$$8$by,  'Y$$$$$$l   dy,  'Y$l   dy,  'Y$$      
      $l`  l$$b        ,g,    Y     $b    Y$$$$l`  l$$b    l`  l$$b    Y$      
      $    $$""        l$l    l     $'   ,d$$$$    $$""        $$""     $      
      $b   `Y$$$$$    ;$P d   `     yy,    ``$l    $$$$$$$$b   `Y$$$$$$$$      
      $$b      $$$;   ;P d;         $$$$b     ;    $$$$$""""       $""""       
      $$"   ,yy$$$l     dl    ;     $$$$$l         $$$$$   l    ,  $   l       
      $    `$$$$$$b    `$'    d     $$$$$$     .   `$Y$$b      `$  $b          
      $     $$$$$$$b,       ,d$     $$$$$$     b                               
      $     $$$$$$$$$by,.,yd$$$ggggg$$$$$$     $8y,     .,y8$y,     .,y8$      
      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     $$$$$$$$$$$$$$$$$$$$$$$$$$      
                                                          trip(RMRS/iCE)      

                " The more you drink, the better we look. "




                             R E L E A S E
,d$b.                    "" $$b  yy $$$$ ,d$$b,                          ,d$b.
$$  '                    $$ $$Yb $$ $$__ $$  $$                          `  $$
`qb                      $$ $$ Yb$$ $$"" $$  $S                            qb'
,d$b.                    $$ ``  $$$ $$   $YyyP$                          ,d$b.
`  $$                                                                    $$  '
  qb'         Release      : Radical Dreamers English Translation        `qb
,d$b.         File         : NDF-RD14.ZIP                                ,d$b.
$$  '         Validity     : [ ] Alpha   [ ] Beta     [x] Final          `  $$
`qb           Medium       : SNES                                          qb'
,d$b.         Version      : 1.4                                         ,d$b.
`  $$         Date         : 12-25-5                                     $$  '
  qb'                                                                    `qb
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'    TABLE OF CONTENTS:                                              `qb  
,d$b.                                                                    ,d$b.
$$  '       WHAT'S NEW ........................ Just below this thing    `  $$
`qb                                                                        qb'
,d$b.       TRANSLATION NOTES ...................... Right after that    ,d$b.
`  $$                                                                    $$  '
  qb'       MO SPEAKS ................... After the translation notes    `qb  
,d$b.                                                                    ,d$b.
$$  '       GAME INFO ................. Like maybe about halfway down    `  $$
`qb                                                                        qb'
,d$b.       HOW TO USE AN IPS FILE ......... A little ways after that    ,d$b.
`  $$                                                                    $$  '
  qb'       TRANSLATION CREDITS ........... About 3/4 of the way down    `qb  
,d$b.                                                                    ,d$b.
$$  '       CODING / HACKING CREDITS .. After the other credits (duh)    `  $$
`qb                                                                        qb'
,d$b.       QUESTIONS / BUGS .............. 4th thing from the bottom    ,d$b.
`  $$                                                                    $$  '
  qb'       PROFESSIONAL AVAILABILITY ............. Almost at the end    `qb  
,d$b.                                                                    ,d$b.
$$  '       CONTACT INFORMATION ..... Really really almost at the end    `  $$
`qb                                                                        qb'
,d$b.       DYSTRO ........................... All the way down baby!    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.    WHAT'S NEW:                                                     ,d$b.
$$  '                                                                    `  $$
`qb         This  release will  probably  be  the REAL  final  patch,      qb'
,d$b.      since this patch  incorporates Radical R's patch  with the    ,d$b.
`  $$      offical patch.  Now  in-games saves  are  enabled and  the    $$  '
  qb'      Satellaview screen  is GONE!  Plus, fixed  the crash  when    `qb  
,d$b.      the  Exit  command  was  chosen.  Also,  included  in  the    ,d$b.
$$  '      standard round of  typos corrections. One may  notice that    `  $$
`qb        Radical R  is listed  as part  of the group  below. He  is      qb'
,d$b.      included in this  release ONLY, since this  patch contains    ,d$b.
`  $$      the changes from his  patch. So kudos to him, and  this is    $$  '
  qb'      proof that he needs to get a life! Also thanks to             `qb  
,d$b.       Dreamer_Nom for figuring  out how the in-game  saves work    ,d$b.
$$  '      and passing  the data  onto Radical  R. If  it wasn't  for    `  $$
`qb        this guy, there  would be no chance  of playing this  on a      qb'
,d$b.      copier. Speaking of which, if anyone got  a copier, if you    ,d$b.
`  $$      could please test this and let me or  Radical R know, that    $$  '
  qb'      would be awesome.                                             `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '    TRANSLATION NOTES:                                              `  $$
`qb                                                                        qb'
,d$b.       This thing  took forever!$!@#$ I  swear I've put  in more    ,d$b.
`  $$      time  into  translating  this  than  like   all  my  other    $$  '
  qb'      translation projects  combined! Sheesh!  I've heard  about    `qb  
,d$b.      some guy  once  who translated  Star Ocean  in  a week  or    ,d$b.
$$  '      something like  that,  but let  me tell  you, there  isn't    `  $$
`qb        anybody, anywhere, who  could get through this thing  in a      qb'
,d$b.      week. Yeah, I know,  I should have been busy  making money    ,d$b.
`  $$      or  living life  up  or  getting  laid or  something,  but    $$  '
  qb'      someone had to translate this game,  and nobody was really    `qb  
,d$b.      stepping up to the plate, so I figured what the hell.         ,d$b.
$$  '                                                                    `  $$
`qb         I think I started on it back around  two and a half years      qb'
,d$b.      ago years ago (late  2000), when I found somewhere  a font    ,d$b.
`  $$      Disnesquick had ripped out  of the ROM. I asked  around if    $$  '
  qb'      anybody wanted to tackle  the game, but all the  good guys    `qb  
,d$b.      were already busy  with their own projects. My  old friend    ,d$b.
$$  '      Darkforce gave  a  little help,  however -  after a  quick    `  $$
`qb        trace, he  told me  where the  script was  located in  the      qb'
,d$b.      ROM. That's all I needed to start  getting myself more and    ,d$b.
`  $$      more entangled in  this mess of  a project. Over  the next    $$  '
  qb'      few  months,  I   would  learn  about  the  evils   of  LZ    `qb  
,d$b.      compression, and the mysterious ways of  script encoding a    ,d$b.
$$  '      la Squaresoft.  Eventually, after I'd  gained the help  of    `  $$
`qb        some guys who helped me understand  the game's compression      qb'
,d$b.      method, we made tools to decompress  the script, but could    ,d$b.
`  $$      never get  it quite right...  It was  always a little  bit    $$  '
  qb'      off. Unfortunately,  when you  try and  try something  day    `qb  
,d$b.      after day  but  nothing ever  happens, you  start to  lose    ,d$b.
$$  '      interest.                                                     `  $$
`qb                                                                        qb'
,d$b.       The project just  sat there, stalled on my  computer, for    ,d$b.
`  $$      months. Maybe even  a year... who  knows. To tell  you the    $$  '
  qb'      truth, I was really busy with my final  year of college at    `qb  
,d$b.      the time,  and on top  of that I  was doing crew  (rowing)    ,d$b.
$$  '      with Ohio State,  so anything like this  was unfortunately    `  $$
`qb        low priority for  a long while.  But then, one  day (we're      qb'
,d$b.      now up to  around March 2002 I  think), this guy  I'd been    ,d$b.
`  $$      working with named Nick Burtner suggested  something new -    $$  '
  qb'      forget decompressing the  script, because the  game itself    `qb  
,d$b.      decompresses it into memory when it  starts, and we should    ,d$b.
$$  '      theoretically be  able to find  it in  RAM. So, I  checked    `  $$
`qb        the in-game memory, and  there it was! on May 30,  after a      qb'
,d$b.      custom version  of  ZSNES was  made for  me  by _Demo_,  I    ,d$b.
`  $$      procured  the  decompressed  script  from  memory  and  we    $$  '
  qb'      finally had  a  complete script  in our  hands, ready  for    `qb  
,d$b.      translation.                                                  ,d$b.
$$  '                                                                    `  $$
`qb         By June, I had refined and readied  the script decoder (a      qb'
,d$b.      program that  takes the  script in  the game's own  format    ,d$b.
`  $$      and  turns it  into  a  readable, editable  textfile)  and    $$  '
  qb'      reencoder  (for  the  reverse).  I  had   to  learn  65816    `qb  
,d$b.      assembly in July when noone came to my  call for help with    ,d$b.
$$  '      some  low-level  coding issues,  but  I  didn't  run  into    `  $$
`qb        anything too difficult. I'd really like  to mention Gideon      qb'
,d$b.      Zhi here; his DMA textfile was my  biggest help in getting    ,d$b.
`  $$      off the  ground with  learning SNES  assembly. If more  of    $$  '
  qb'      the experienced translating community was  to start making    `qb  
,d$b.      tutorials as assible as his, I know it  would help out the    ,d$b.
$$  '      learning  curve in  the  scene immensely.  Anyhow,  within    `  $$
`qb        about two  weeks, I had  a new font  system in place,  and      qb'
,d$b.      managed to make it so that the script  didn't even need to    ,d$b.
`  $$      be recompressed when  being reinserted back into  the ROM.    $$  '
  qb'      I  really  lucked  out,  being  able   to  avoid  all  the    `qb  
,d$b.      compression issues completely.                                ,d$b.
$$  '                                                                    `  $$
`qb         By this time,  the translating was finally  getting under      qb'
,d$b.      way, which was  a heap of work  in its own right.  I would    ,d$b.
`  $$      have liked to have  more translators help me on it,  but I    $$  '
  qb'      suppose it  was  fate that  decreed that  it  would be  my    `qb  
,d$b.      Japanese skills  which would gain  all those thousands  of    ,d$b.
$$  '      hours of translating practice. Muahahaha.                     `  $$
`qb                                                                        qb'
,d$b.       In a  lure to attract  more and more  people to my  cause    ,d$b.
`  $$      and  hopefully hire  a  translator or  two,  I released  a    $$  '
  qb'      preemptive "teaser"  patch on August  17th, 2002 with  the    `qb  
,d$b.      first ten or  so minutes of the game  translated. Actually    ,d$b.
$$  '      it was pretty  much just begging  for help, but  hey, what    `  $$
`qb        are you gonna do. Anyhow, it was only  then that I started      qb'
,d$b.      to   receive   some   serious   offers   for   translation    ,d$b.
`  $$      assistance. Don't  get me wrong,  I would get  emails from    $$  '
  qb'      potential translators  all  the time,  but  very few  were    `qb  
,d$b.      actually willing  to sit  down for  more than  a week  and    ,d$b.
$$  '      tackle any  significant  amount of  text -  the script  is    `  $$
`qb        about  700   pages,  which   I  can   admit  is   somewhat      qb'
,d$b.      intimidating. The  best  guy who  approached me  is now  a    ,d$b.
`  $$      good friend  of  mine, who  goes by  the  nickname MO.  He    $$  '
  qb'      managed  to translate  and  edit about  150  pages for  me    `qb  
,d$b.      while  his  girlfriend  was  over  in  Europe  and  needed    ,d$b.
$$  '      something  to  keep  his mind  off  things,  which  I  can    `  $$
`qb        understand completely.                                          qb'
,d$b.                                                                    ,d$b.
`  $$       But,  the  majority   of  the  translation  fell   on  my    $$  '
  qb'      shoulders. I have a  BA in Japanese, and I've  spent three    `qb  
,d$b.      or  so months  in  Japan a  couple  of  years ago,  but  I    ,d$b.
$$  '      wouldn't exactly call  myself fluent. I relied  heavily on    `  $$
`qb        dictionaries  such  as EDICT  (supplied  with  JWPce,  the      qb'
,d$b.      Japanese text  editor  I used  for  Radical Dreamers)  and    ,d$b.
`  $$      Japan's  Goo online  dictionary.  However, these  left  me    $$  '
  qb'      hanging sometimes,  and occasionally I  would hit a  tough    `qb  
,d$b.      spot in  the  translation. When  this  happened, we  would    ,d$b.
$$  '      discuss  them  on   MO's  wwwboard  (a  great   place  for    `  $$
`qb        translators to hang out,  see link at the bottom)  and try      qb'
,d$b.      to figure  out the  best possible  way to  convey what  we    ,d$b.
`  $$      thought was being said.                                       $$  '
  qb'                                                                    `qb  
,d$b.       In the  end, it all  worked out fine,  I'd say. I'm  much    ,d$b.
$$  '      better  with  Japanese now  than  I've  ever  been  before    `  $$
`qb        thanks  to  all this.  I  translated  the  script's  final      qb'
,d$b.      Japanese sentence on  the chilly afternoon of  March 12th,    ,d$b.
`  $$      2003. From  there, only  a few  more bits  remained to  be    $$  '
  qb'      edited.  Once  that  was out  of  the  way,  private  beta    `qb  
,d$b.      testing  began  on  March 27th,  and  soon  after  that  I    ,d$b.
$$  '      decided to  publically  release the  translation on  April    `  $$
`qb        15th for my mother's birthday.                                  qb'
,d$b.                                                                    ,d$b.
`  $$       We're probably gonna get some heat  for this translation,    $$  '
  qb'      because it's  not really word  for word, like  some people    `qb  
,d$b.      want. Wordings  were changed to  make things flow  better,    ,d$b.
$$  '      and  cultural "in-jokes"  were  altered  to be  funny  for    `  $$
`qb        English   speakers.   However,   things   like   character      qb'
,d$b.      progression, plot structure, and narrative  style were all    ,d$b.
`  $$      left untouched so  that the game  retained as much  of its    $$  '
  qb'      original feel as possible.                                    `qb  
,d$b.                                                                    ,d$b.
$$  '       We kept more in  line with the English versions  of names    `  $$
`qb        as they appear in the American  versions of Chrono Trigger      qb'
,d$b.      and  Chrono  Cross,  instead  of  retaining  the  Japanese    ,d$b.
`  $$      naming conventions. Such changes include:                     $$  '
  qb'                                                                    `qb  
,d$b.                 Yamaneko ....................... Lynx              ,d$b.
$$  '                 Gil ........................... Magil              `  $$
`qb                   Grandleon .................. Masamune                qb'
,d$b.                 Snakebone Colonel ..... General Viper              ,d$b.
`  $$                 Taubanjan ..............Mick Van Jovi              $$  '
  qb'                 Snakebone Mansion ....... Viper Manor              `qb  
,d$b.                 Parepori ...................... Porre              ,d$b.
$$  '                 Jarii ........................... Imp              `  $$
`qb                   Silvard ....................... Epoch                qb'
,d$b.                                                                    ,d$b.
`  $$       We're  fully aware  of  the many  people  who take  these    $$  '
  qb'      games very  seriously and want  to know every  last detail    `qb  
,d$b.      as correctly as  it was given  in the Japanese  version. I    ,d$b.
$$  '      like to think  of myself as  one of those  people; believe    `  $$
`qb        me, I wouldn't have  spent all this time on this  thing if      qb'
,d$b.      I didn't like Chrono Trigger so much. And  like I said, we    ,d$b.
`  $$      tried to translate it  the best we knew how.  Still, we're    $$  '
  qb'      only human.  So, if  you see  something you  think we  did    `qb  
,d$b.      wrong, let us know and we'll offer an  update to the patch    ,d$b.
$$  '      in due time.                                                  `  $$
`qb                                                                        qb'
,d$b.       And yes,  the Mars  scenario is  supposed to  be like  an    ,d$b.
`  $$      acid trip. I don't know why. I just work here.                $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$    MO SPEAKS:                                                      $$  '
  qb'                                                                    `qb  
,d$b.       I  wanted  to  say  some  stuff   about  the  process  of    ,d$b.
$$  '      translating the game, and thank some  people, so, uh, here    `  $$
`qb        are my thoughts on that:                                        qb'
,d$b.                                                                    ,d$b.
`  $$       I had  not really ever  talked to  Demi before I  started    $$  '
  qb'      working on  this project...let  me take  this time to  say    `qb  
,d$b.      that he's  a great  guy to  work with.   He was  extremely    ,d$b.
$$  '      nice to  me from the  very begining and  I never felt  any    `  $$
`qb        kind  of arrogance  or  a "do  this",  "do that"  kind  of      qb'
,d$b.      pressure from him.   At the same  time, he doesn't  BS you    ,d$b.
`  $$      at all and tells  you exactly where things stand.   I also    $$  '
  qb'      got to  know him a  lot better  during the process,  which    `qb  
,d$b.      was nice.  He really  is quite an individual, I'd  like to    ,d$b.
$$  '      meet him someday. :-)                                         `  $$
`qb                                                                        qb'
,d$b.       This  whole   game   was  quite   fun  to   work  on,   I    ,d$b.
`  $$      think...although  I  helped  with   the  translation,  the    $$  '
  qb'      writing is all  Demi...I think he's a terrific  writer and    `qb  
,d$b.      what you're reading is basically all him.                     ,d$b.
$$  '                                                                    `  $$
`qb         I'd also like to  thank all of our beta  testers, akujin,      qb'
,d$b.      Haeleth, and Datenshi. Seriously, I don't  think you could    ,d$b.
`  $$      find better guys  than these in  the whole scene  to help.    $$  '
  qb'      They're all  extremely  capable guys,  and their  Japanese    `qb  
,d$b.      knowledge  is  all very,  very  good.  Datenshi's  grammar    ,d$b.
$$  '      knowledge alone  amazes me. ;-)  Also, thanks to  everyone    `  $$
`qb        who helped at my board with any  translations of the game,      qb'
,d$b.      off the top of  my head, Tomato and Shih Tzu.  Actually, I    ,d$b.
`  $$      dunno if Tomato  actually helped with Radical  Dreamers at    $$  '
  qb'      all, but,  he's helped  with translations  of mine in  the    `qb  
,d$b.      past, and he's a cool guy.                                    ,d$b.
$$  '                                                                    `  $$
`qb         Not sure  about Shih  Tzu either,  but, hey, he  deserves      qb'
,d$b.      some  mention,   if  only   to  plug   his  Rad   Project:    ,d$b.
`  $$      www.flammie.net/vse/things/rad/index.htm  ;-)   He's  also    $$  '
  qb'      the funniest guy in the scene, in my opinion.                 `qb  
,d$b.                                                                    ,d$b.
$$  '       Thanks   also   to:   Angela    Silletto,   Brian   Dunn,    `  $$
`qb        Avicalendriya  Das  Morgan,  Hirotaka  Takase  (MC  Hiro),      qb'
,d$b.      Andrew Fitch, Gideon Zhi, and Jair.                           ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.    GAME INFO:                                                      ,d$b.
`  $$                                                                    $$  '
  qb'       Radical  Dreamers  is a  side-story  to  Demi's  favorite    `qb  
,d$b.      game,  Chrono  Trigger.   It  was  released  in   1996  by    ,d$b.
$$  '      Squaresoft  through  this thing  called  the  Satellaview,    `  $$
`qb        Nintendo's Japanese-only competitor for  the Sega Channel.      qb'
,d$b.      It was this thing  that fit onto the top of  your SNES and    ,d$b.
`  $$      let you download  games through the  phone line. RD  was a    $$  '
  qb'      game released exclusively through this system  for a short    `qb  
,d$b.      while,  so it  remained  relatively  of unheard  of  until    ,d$b.
$$  '      recently.                                                     `  $$
`qb                                                                        qb'
,d$b.       Radical  Dreamers is  a  storybook  game. I  don't  think    ,d$b.
`  $$      Americans have really  seen this type of game  before, but    $$  '
  qb'      they're common  in Japan,  I think.  They're sort of  like    `qb  
,d$b.      Text Adventures  (like  the old  Zork  games) but  they're    ,d$b.
$$  '      driven by menus  instead of text input. You  could compare    `  $$
`qb        them to  computerised "Choose  Your Own Adventure"  books.      qb'
,d$b.      These games  are  100% reading,  so if  you're  not a  big    ,d$b.
`  $$      reader, chances  are you  won't be  having much fun  here.    $$  '
  qb'      But hey,  you're  probably here  because Radical  Dreamers    `qb  
,d$b.      has ties  to the Chrono  games, not  because it's a  great    ,d$b.
$$  '      game on its own, so what the hell.                            `  $$
`qb                                                                        qb'
,d$b.       Radical Dreamers  is really  not like  Chrono Trigger  or    ,d$b.
`  $$      Chrono Cross  at all in  the sense that  it's not an  RPG,    $$  '
  qb'      but it does seem to take place in  the Chrono universe. It    `qb  
,d$b.      features characters from Chrono Cross  and Chrono Trigger,    ,d$b.
$$  '      and places like Viper Manor and Porre  are integral to the    `  $$
`qb        plot.                                                           qb'
,d$b.                                                                    ,d$b.
`  $$       They  say  Radical  Dreamers  was  somewhat  remade  into    $$  '
  qb'      Chrono Cross. And indeed, if you look  closely you can see    `qb  
,d$b.      bits and peices  of Radical Dreamers which ended  up being    ,d$b.
$$  '      reused  in   Chrono   Cross,  with   varying  degrees   of    `  $$
`qb        familiarity. Such  concepts include  the Acacia  Dragoons,      qb'
,d$b.      an ocean  at standstill, Lynx  and his offspring,  and the    ,d$b.
`  $$      fusion of a girl and a beast.                                 $$  '
  qb'                                                                    `qb  
,d$b.       While I'm at it, here's an another  piece of trivia about    ,d$b.
$$  '      Radical Dreamers: one  day when I was deciphering  its RAM    `  $$
`qb        layout, I discovered that there's  an environment variable      qb'
,d$b.      set for  each scenario  that you  finish. The  interesting    ,d$b.
`  $$      thing is  that  there are  eight of  these variables,  but    $$  '
  qb'      only seven scenarios. What may have  happened was that the    `qb  
,d$b.      writers originally created more than  seven scenarios, but    ,d$b.
$$  '      some were deemed  too incomplete (or bad, or  whatever) to    `  $$
`qb        be included.  That being  said, I  wonder where they  drew      qb'
,d$b.      the line - at  times, some of the remaining  scenarios get    ,d$b.
`  $$      pretty... interesting.                                        $$  '
  qb'                                                                    `qb  
,d$b.       Yes, this  game may  seem a  bit strange,  and at  times,    ,d$b.
$$  '      incomplete. It is in  fact a pretty rushed game,  with its    `  $$
`qb        fair  share of  convoluted  plotlines and  one-dimensional      qb'
,d$b.      characters  (wait,  no,  that  would   describe  most  any    ,d$b.
`  $$      Squaresoft game...). But, like I said, it's  a part of the    $$  '
  qb'      Chrono series nonetheless. My assumption  on what happened    `qb  
,d$b.      was  that   Squaresoft   probably  got   into  the   whole    ,d$b.
$$  '      Satellaview thing  right after completing  Chrono Trigger,    `  $$
`qb        and as such,  they decided to pump  out a few  quick games      qb'
,d$b.      using the technologies they had  just finished developing.    ,d$b.
`  $$      One  of  these  games  ended  up   making  use  of  Chrono    $$  '
  qb'      Trigger's  sprites  and  backgrounds  (DynamiTracer),  one    `qb  
,d$b.      made  use of  Chrono  Trigger's  mode 7  rendering  engine    ,d$b.
$$  '      (Treasure Conflix), and of course, one  made use of Chrono    `  $$
`qb        Trigger's story (Radical Dreamers).                             qb'
,d$b.                                                                    ,d$b.
`  $$       Anyhow,  besides  the  storyline   connection  to  Chrono    $$  '
  qb'      Trigger, the other  big draw about  this game is  the fact    `qb  
,d$b.      that  Yasunori Mitsuda,  a  top name  in  symphony-calibur    ,d$b.
$$  '      video game  music, composed the  soundtrack. He worked  on    `  $$
`qb        Radical  Dreamers  after Front  Mission  and  just  before      qb'
,d$b.      starting Xenogears, I  believe. If that's true,  then this    ,d$b.
`  $$      was his final soundtrack for the  SNES. Looking at Radical    $$  '
  qb'      Dreamers' soundtrack  in this  regard, it's apparent  that    `qb  
,d$b.      he probably was composing with a  higher level of intimacy    ,d$b.
$$  '      with the SNES's  sound capabilities than when  he composed    `  $$
`qb        any of his  other SNES soundtracks. Despite the  fact that      qb'
,d$b.      much of the  material here is ambient (or  minimalistic to    ,d$b.
`  $$      say the least),  the majority of  the stuff here  is quite    $$  '
  qb'      good if  you're into  this sort  of music,  much like  Tim    `qb  
,d$b.      Follin's  quiet   yet  excellent  soundtrack   for  Sony's    ,d$b.
$$  '      Equinox.                                                      `  $$
`qb                                                                        qb'
,d$b.       A  handful of  the  tracks, like  the  battle theme,  the    ,d$b.
`  $$      Frozen Flame  theme, and Viper  Manor's theme were  reused    $$  '
  qb'      in   Chrono  Cross,   enhanced   with  Playstation   audio    `qb  
,d$b.      capabilities. Head  over  to www.zophar.net  one of  these    ,d$b.
$$  '      days and check out the SPC and PSF  music libraries - it's    `  $$
`qb        now possible to  play ripped soundtracks of both  SNES and      qb'
,d$b.      Playstation  music   (among  others)   directly  on   your    ,d$b.
`  $$      computer,  allowing  you  to  compare   the  material  for    $$  '
  qb'      yourself through a player like Winamp.                        `qb  
,d$b.                                                                    ,d$b.
$$  '       My favorite song? Song 06, "Under  Moonlight". It's has a    `  $$
`qb        certain special significance in RD, as you may discover...      qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb      HOW TO USE THE PATCH:                                             qb'
,d$b.                                                                    ,d$b.
`  $$       This archive  does not  contain the  game itself, just  a    $$  '
  qb'      patch. We translators distribute our work  this way to get    `qb  
,d$b.      around the legal red  tape of the digital age,  which says    ,d$b.
$$  '      it's   illegal  to   distribute   other  peoples'   works,    `  $$
`qb        especially  if   they're   modified  (which   is  what   a      qb'
,d$b.      translation pretty  much is). So  instead we distribute  a    ,d$b.
`  $$      patch which changes the game into  the translated version,    $$  '
  qb'      provided you've  already somehow  got ahold  of a copy  of    `qb  
,d$b.      the game.                                                     ,d$b.
$$  '                                                                    `  $$
`qb         Don't ask us where to get the game. We can't tell you.         qb'
,d$b.                                                                    ,d$b.
`  $$       Anyhow,  if you  do  have the  game,  just rename  it  to    $$  '
  qb'      rad-j.smc, unzip all these files into  the same folder the    `qb  
,d$b.      game  is in,  and  then run  cabbage.  If everything  goes    ,d$b.
$$  '      well, you  should  have a  translated  version of  Radical    `  $$
`qb        Dreamers sitting right there before you know it.                qb'
,d$b.                                                                    ,d$b.
`  $$       Alternatively, if you  know how to work  the commandline,    $$  '
  qb'      you can  type stuff like  "cabbage radical.smc" and  it'll    `qb  
,d$b.      patch  radical.smc   instead  of   rad-j.smc.  It's   case    ,d$b.
$$  '      sensitive  though, so  make  sure  you  know if  your  ROM    `  $$
`qb        filename is capitalised  or not (windows can  really throw      qb'
,d$b.      you off sometimes when it comes to that).                     ,d$b.
`  $$                                                                    $$  '
  qb'       This  patching  program is  for  DOS  and  Windows  only.    `qb  
,d$b.      Sorry, I just program stuff for what I  use. If you're one    ,d$b.
$$  '      of  the  types  of  people  who   insist  on  using  these    `  $$
`qb        alternative  operating systems,  chances  are you're  also      qb'
,d$b.      resourceful enough to  find a copy of the  translated game    ,d$b.
`  $$      on your own without having to bother with my program.         $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$    TRANSLATION CREDITS:                                            $$  '
  qb'                                                                    `qb  
,d$b.       1) Kid: Le Tr�sor Interdit                                   ,d$b.
$$  '          Translated by Demi, MO, and Loek van Kooten.              `  $$
`qb            Edited by Demi.                                             qb'
,d$b.                                                                    ,d$b.
`  $$       2) Magil: Caught between Love and Adventure                  $$  '
  qb'          Translated & edited by Demi.                              `qb  
,d$b.                                                                    ,d$b.
$$  '       3) Kid and the Sunflower                                     `  $$
`qb            Translated by MO. Edited by MO and Demi.                    qb'
,d$b.                                                                    ,d$b.
`  $$       4) SuperXtreme Alphacosmos Police Case EX Ultra              $$  '
  qb'          Translated & edited by MO, Demi, Datenshi, and Akujin.    `qb  
,d$b.                                                                    ,d$b.
$$  '       5) Homecoming: Shea's Light                                  `  $$
`qb            Translated & edited by Demi.                                qb'
,d$b.                                                                    ,d$b.
`  $$       6) The Enigmatic Gigaweapon: Paradise X                      $$  '
  qb'          Translated by MO. Edited by MO and Demi.                  `qb  
,d$b.                                                                    ,d$b.
$$  '       7) The Shadow Realm and the Goddess of Death                 `  $$
`qb            Translated & edited by Demi.                                qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'       A very  special thanks goes  out to  Moe Kotoi, who  runs    `qb  
,d$b.      the best  Japanese  Radical Dreamers  website  I know  of,    ,d$b.
$$  '      complete  with  commentary  on  each   of  the  scenarios.    `  $$
`qb        Despite  all the  buzz,  there  was actually  very  little      qb'
,d$b.      detailed information  on this  game out  there, so when  I    ,d$b.
`  $$      got  it here,  it  was  very  much appreciated.  She  even    $$  '
  qb'      helped me  out  (in Japanese)  when I  had some  questions    `qb  
,d$b.      about the game. Thanks!!                                      ,d$b.
$$  '                                                                    `  $$
`qb         And of  course, a  very special  THANKS FOR NOTHING  goes      qb'
,d$b.      out  to  Zelda  Dude,  for  confusing   the  hell  out  of    ,d$b.
`  $$      everybody by doing nothing more than  running Miss Kotoi's    $$  '
  qb'      website through  Altavista's Japanese translating  program    `qb  
,d$b.      and trying  to pass off  the entire  unreadable mess as  a    ,d$b.
$$  '      full translation  /  walkthru! Head  over to  gamefaqs.com    `  $$
`qb        one of these days  and check it out if you  have the time.      qb'
,d$b.      It's good for a laugh but not much else.                      ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.    CODING / HACKING CREDITS:                                       ,d$b.
`  $$                                                                    $$  '
  qb'       Disnesquick: The original  RD hackah! He dumped  the font    `qb  
,d$b.      which originally got me interested in working on the game!    ,d$b.
$$  '                                                                    `  $$
`qb         Madoka:  Wait  no, this  dude  (girl?)  is  the  original      qb'
,d$b.      original RD dude. He  was the guy who somehow  figured out    ,d$b.
`  $$      how to dump  a Satellaview game  into a ROM  (!?@#$) -and-    $$  '
  qb'      hack the game so that it uses its  own font instead of the    `qb  
,d$b.      Satellaview's. A super duper mother fucker in my book.        ,d$b.
$$  '                                                                    `  $$
`qb         Darkforce: He  showed me where  the script was,  but made      qb'
,d$b.      me to find out the rest on my  own. (thanks, this actually    ,d$b.
`  $$      was pretty fun)                                               $$  '
  qb'                                                                    `qb  
,d$b.       Maximilian  Rehkopf &  Nick  Ratelle: These  guys  helped    ,d$b.
$$  '      figure out the  script's LZ compression  routine. (however    `  $$
`qb        in the  end,  we managed  to bypass  it, avoiding  getting      qb'
,d$b.      into compression altogether!)                                 ,d$b.
`  $$                                                                    $$  '
  qb'       Nick Burtner: Coded  an updated script  decompressor, and    `qb  
,d$b.      provided essential help which finally allowed  us to get a    ,d$b.
$$  '      decent  script dumped!  Without  this  guy, I  might  have    `  $$
`qb        seriously given up on Radical Dreamers!                         qb'
,d$b.                                                                    ,d$b.
`  $$       Akujin, Ballz,  Datenshi,  Haeleth, Gideon  Zhi, and  MO:    $$  '
  qb'      These gentlemen provided  hour upon hour of  daunting beta    `qb  
,d$b.      testing. I really  appreciate all the  last-minute testing    ,d$b.
$$  '      they did so  that we could meet  the deadline with  a good    `  $$
`qb        version. I owe you one, guys!                                   qb'
,d$b.                                                                    ,d$b.
`  $$       _Demo_: aside from coding ZSNES, which  is worth thanking    $$  '
  qb'      in its own regard, he compiled a  special version of ZSNES    `qb  
,d$b.      for me one day that allowed special  supersize SRAMs to be    ,d$b.
$$  '      saved, allowing me to nab the script.                         `  $$
`qb                                                                        qb'
,d$b.       Radical R:  For updating the  source code to  include the    ,d$b.
`  $$      changes that his patch did and  for obessively running the    $$  '
  qb'      only known english fan website.                               `qb  
,d$b.                                                                    ,d$b.
$$  '       Dreamer_Nom: For  posting information  about the  changes    `  $$
`qb        for  ASM code  that  allows saving  and  various of  other      qb'
,d$b.      things.                                                       ,d$b.
`  $$                                                                    $$  '
  qb'       Demi: I reverse  engineered the script's  control format,    `qb  
,d$b.      and wrote tools to decode and reencode  the script. I also    ,d$b.
$$  '      took  care  of the  assembly-level  work,  made  the  game    `  $$
`qb        playable on SNES  copiers, and rendered the  English font.      qb'
,d$b.      I also own you very much.                                     ,d$b.
`  $$                                                                    $$  '
  qb'       And of course,  a big thanks to  all the people  who have    `qb  
,d$b.      offered their help along  the way in one form  or another.    ,d$b.
$$  '      Sorry, there's way too  many of you to remember.  You know    `  $$
`qb        who you are  though. Ah, hell, if  you know you  should be      qb'
,d$b.      listed in here, email me and I'll throw ya in.                ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.    QUESTIONS / BUGS:                                               ,d$b.
`  $$                                                                    $$  '
  qb'       First of all, if  you wanna try and translate  this thing    `qb  
,d$b.      into another language like Spanish or  something, go right    ,d$b.
$$  '      ahead. Just contact  me and I'll  let you have  the script    `  $$
`qb        and all the necessary tools.                                    qb'
,d$b.                                                                    ,d$b.
`  $$       If you have a bug report, please keep it to yourself.        $$  '
  qb'                                                                    `qb  
,d$b.       No, just  kidding.  Feel free  to  visit the  sourceforge    ,d$b.
$$  '      page  (there's   a  link   at  the   bottom),  click   the    `  $$
`qb        'sourceforge' link, and  log onto the bug  reporting forum      qb'
,d$b.      there. We'll update the patch once a  good amount of stuff    ,d$b.
`  $$      is fixed (I  don't want to release  a new version  of this    $$  '
  qb'      thing every  other  day -  it'll clutter  up the  GoodSNES    `qb  
,d$b.      set).                                                         ,d$b.
$$  '                                                                    `  $$
`qb         If you're  wondering how  to save  your game, here's  the      qb'
,d$b.      low-down: the game's saving feature doesn't  seem to work,    ,d$b.
`  $$      so use savestates. Savestates  from untranslated versions,    $$  '
  qb'      or  previous translation  versions  are incompatible  with    `qb  
,d$b.      this version,  just as how  this version will  probably be    ,d$b.
$$  '      incompatible  with the  next  version,  if there  is  one.    `  $$
`qb        Well, that's not entirely true -  loading a savestate from      qb'
,d$b.      an  untranslated  version   will  definitely  fuck   up  a    ,d$b.
`  $$      translated version.  However, loading  a savestate from  a    $$  '
  qb'      previous  translation  version  might   work,  but  you'll    `qb  
,d$b.      probably  end up  at  a  different  place than  where  you    ,d$b.
$$  '      should be at, and  the game engine might get  confused and    `  $$
`qb        crash. If  you need to  do this though,  try to save  your      qb'
,d$b.      savestate near  the entrance  to the  mansion. The  closer    ,d$b.
`  $$      you are to the entrance, the less  chance there'll be that    $$  '
  qb'      it'll crash.                                                  `qb  
,d$b.                                                                    ,d$b.
$$  '       If you're  wondering why I  chose to  write my own  patch    `  $$
`qb        instead of  using an IPS  patch or something,  here's why.      qb'
,d$b.      There are two versions of the Japanese  game out there; an    ,d$b.
`  $$      8mb version  and a 16mb  version. However, IPS  patches is    $$  '
  qb'      really  only  good  for  when  you're   dealing  with  one    `qb  
,d$b.      specific target file.  An IPS patch designed for  the 16mb    ,d$b.
$$  '      version won't  work for the  8mb version, and  vice versa.    `  $$
`qb        This would  have caused a  lot of confusion  and headache,      qb'
,d$b.      because you know  there are tons  of people out  there who    ,d$b.
`  $$      don't  read directions...  they'd  be patching  the  wrong    $$  '
  qb'      version  and   complaining  everywhere   because  of   it.    `qb  
,d$b.      Cabbage, on the other hand, works  for either version. You    ,d$b.
$$  '      may bow to cabbage now.                                       `  $$
`qb                                                                        qb'
,d$b.       Finally, if  you  have a  question about  if there's  any    ,d$b.
`  $$      hidden stuff in the  game, the answer is no,  there isn't.    $$  '
  qb'      Like our  other projects, we  have completely removed  any    `qb  
,d$b.      and all secret features before public release.                ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$                                                                    $$  '
  qb'                                                                    `qb  
,d$b.    PROFESSIONAL AVAILABILITY:                                      ,d$b.
$$  '                                                                    `  $$
`qb         Adam (MO) and I  (Demi) are both looking for  better jobs      qb'
,d$b.      at the  moment.  Adam's interested  in  getting hooked  up    ,d$b.
`  $$      with a Japanese translation job somewhere  in the northern    $$  '
  qb'      California  area,   and   I'm  leaving   myself  open   to    `qb  
,d$b.      programming,  translating,  or  graphics  work  throughout    ,d$b.
$$  '      America.  If you  or  someone you  know  is interested  in    `  $$
`qb        hiring someone who  has obvious passion for what  they do,      qb'
,d$b.      throw either  one of  us  an email  and we'll  send you  a    ,d$b.
`  $$      resume faster than you can say "recession". Thanks!           $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.                                                                    ,d$b.
`  $$    CONTACT INFORMATION:                                            $$  '
  qb'                                                                    `qb  
,d$b.       Steve Demeter (Demi), Owner ... demiforce1999@hotmail.com    ,d$b.
$$  '       Adam Fitch (MO), Asst. Translator ..... adam@viszeral.com    `  $$
`qb         Nick Burtner (CStrife), Code ...... cstrife@1ststreet.com      qb'
,d$b.       Maximilian Rehkopf, Code .................. ikari@gmx.net    ,d$b.
`  $$       Sean Ritzo, Code ..................... radicalr@gmail.com    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
,d$b.    DYSTRO:                                                         ,d$b.
`  $$                                                                    $$  '
  qb'       Demiforce Homepage ............... demiforce.parodius.com    `qb  
,d$b.       RD Sourceforce Page ..... radicaldreamers.sourceforge.net    ,d$b.
$$  '       MO's Translation Board ............ donut.parodius.com/mo    `  $$
`qb         Kotoi's RD Page .... village.infoweb.ne.jp/~kotoi/top.htm      qb'
,d$b.       Satellaview Info ......... csd.varlew.net/satellaview.htm    ,d$b.
`  $$       Radical R's site ... members.lycos.co.uk/ticktock/RD.html    $$  '
  qb'                                                                    `qb  
,d$b.                                                                    ,d$b.
$$  '                                                                    `  $$
`qb                                                                        qb'
