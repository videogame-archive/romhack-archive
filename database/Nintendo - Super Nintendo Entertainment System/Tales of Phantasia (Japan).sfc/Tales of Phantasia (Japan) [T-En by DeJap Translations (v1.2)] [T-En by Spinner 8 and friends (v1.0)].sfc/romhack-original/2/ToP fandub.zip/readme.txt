Tales of Phantasia fandub patch for de-interleaved ROMs
-------------------------------------------------------

The fandub patch for Tales of Phantasia for SNES is a thing of
true beauty, but the patch requires the ROM to be in a format
that nobody uses anymore. Many of SNES ROM utilities, even the
seriously old-school ones, don't support it. This patch is for
the much more Tales of Phantasia ROM format floating around
these days.

Use this patch on top of an original Japanese ROM without a
header.

This patch incorporates the English translation version 1.2
FINAL (lower-case 8x8 font) by DeJap Translations, and the
English fandub version 0.999 by Topping Translations, and does
not assume credit for either. Huge thanks to my friends Dark
Force and Gingo17, and to everyone else who was involved with
these projects.

For questions contact spinner_8 on Twitter, or message
Spinner 8 on the Romhacking.net forum.