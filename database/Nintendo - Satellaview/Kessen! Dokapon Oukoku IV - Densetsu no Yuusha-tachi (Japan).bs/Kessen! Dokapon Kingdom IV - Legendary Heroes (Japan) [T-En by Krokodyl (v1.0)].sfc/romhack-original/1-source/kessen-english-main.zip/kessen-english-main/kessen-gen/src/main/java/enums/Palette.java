package enums;

public abstract class Palette {

    public abstract FontColor getFontColor(int i);
    public abstract FontColor getFontColor(String hexa);

}
