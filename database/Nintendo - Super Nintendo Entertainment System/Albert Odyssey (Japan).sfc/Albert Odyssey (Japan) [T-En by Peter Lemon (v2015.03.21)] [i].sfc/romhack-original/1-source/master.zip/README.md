SNES Japanese To English Translation
=====================================
<br />
Translation by krom (Peter Lemon).<br />
<br />
All code compiles out of box with the bass assembler:<br />
http://byuu.org/tool/bass<br />
I have also included an IPS file of the translation as a patch.<br />
<br />
Please check out RomHacking & their forum, a great resource for translation work:<br />
http://www.romhacking.net<br />
<br />
Howto Compile:<br />
You will need the original Japanese ROM in .sfc (Little-Endian) Format, without a header, in the root directory of this patch<br />
All the code compiles into a single binary (ROMNAME.sfc) file.<br />
Using bass Run: make.bat<br />
Or you can patch the original Japanese ROM using the IPS file.<br />
<br />
Howto Run:<br />
I only test with a real SNES using a SD2SNES Cartridge by ikari:<br />
http://sd2snes.de<br />
<br />
You can also use SNES emulators like higan & the MESS SNES Driver.
