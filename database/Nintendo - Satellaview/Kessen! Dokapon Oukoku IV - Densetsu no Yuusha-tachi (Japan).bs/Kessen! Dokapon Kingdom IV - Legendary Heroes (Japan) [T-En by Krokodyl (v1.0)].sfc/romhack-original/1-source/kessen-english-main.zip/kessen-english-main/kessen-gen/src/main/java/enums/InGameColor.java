package enums;

public enum InGameColor {

    TRANSPARENT,
    GREY,
    BLUE,
    WHITE

}
