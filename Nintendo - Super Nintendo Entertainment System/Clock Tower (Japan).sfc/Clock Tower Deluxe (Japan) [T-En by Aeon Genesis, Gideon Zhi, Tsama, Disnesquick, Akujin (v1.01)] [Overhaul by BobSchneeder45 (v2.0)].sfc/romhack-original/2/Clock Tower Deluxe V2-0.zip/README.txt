﻿IMPORTANT!
A certain key has been moved to where you find it in the PlayStation version, so walkthroughs written for the original SNES version might mislead you. Additionally, a cut puzzle has been added to the last part  of the game (see List of changes spreadsheet).

--- Patching ---
First apply any translation patch (not included). Then apply the corresponding Deluxe patch (choose either regular or Classic Chase).

--- Updating ---
Do not apply the patch to a ROM with an earlier version of this mod, as it could cause crashes!
Save files from earlier versions should be compatible.

--- Supported translations ---
English, by Aeon Genesis (Headered ROM!)
Chinese, by Я929
Korean, by Cyjzero
Spanish by IlDucci (Headered ROM!)
Turkish, by knighTeen87 (Headered ROM!)
German, by RedScorpion
Portuguese, by Denver
French, by Naboo

--- Features ---
Mouse support
Lost bedroom, clown doll, zombie, extra cave event ported from the PlayStation version
Can run up and down the stairs (can also run to all hotspots)
Refined chase system (opt out by using the classic chase patch)
Hold UP or DOWN to speed up the credits
Faster health regeneration
Region error screen disabled

--- Mouse ---
Left button: walk/ click things
Right button: stop/ panic button
Press SELECT to change mouse speed (on real hardware). Changes cursor speed for the gamepad instead if no mouse connected.
Move the cursor down to access the inventory. Right clicking there will switch to the default cursor.

--- Additional features ---
See the List of changes spreadsheet

--- Tools used ---
DiztinGUIsh for code inspection
Mesen-S 0.4.0 for debugging
Notepad++ for code, assembled with Asar 1.81
Hex Workshop for hex editing
Custom tools for research, new sprites, animations and compression
YY-CHR for editing existing graphics

This hack has been tested on a PAL SNES and an NTSC SFC system, with an original Super NES Mouse.

--- Credits ---
Deluxe subtitle for title screen by FlamePurge