Angelique Patch 0.02

How to use-
Rename this patch to match the ROM and ZSNES will patch automatically.
For example, if the ROM is named xyz.smc the patch should be renamed xyz.ips.
Otherwise, use a program like IPS or SNESTOOL.

Note- This patch is for Angelique not Angelique Voice Fantasy.

Get the newest patch at the Angelique Translation Project page-
http://www.hal-pc.org/~selc29/ange/trans/index.html

What's New-
0.02 A bunch of the responses are translated, though the questions are still gibberish.

Translation and hacking-
Marfisa

Special thanks to-
John Fleming, for creating the font
Naru, for helping with the table