rm sc4.sfc; cp sc4_base.sfc sc4.sfc && asar -Dstrict=1 main.asm sc4.sfc
