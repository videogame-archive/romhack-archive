=================================================================================
         #######################                                             ####
     #############################                                     #########
   #################################                               ############ 
  #######     #######       ########   #########        ######    ############ 
 #######     #######      #########   ###########    ##########      ########
#######     #####################     #####  ####  #####   ####     ########
           ###################       ##########  #####             ########
          #################         #####       #####   #######   ########
         #######   ########        #####        #####    ####    ########
        #######    ########      ########       ############    ########
       #######     ########     ########         ##########    ########
      #######      #########                                 ##########
     ###########   ##########################################################
    #############  ###########################################################
   ############### ############################################################
  ################  ############################################################
 #################    ###########################################################

    R   P   G   O   N   E      T   R   A   N   S   L   A   T   I   O   N   S
=================================================================================

                                   Presents

                       ================================
                       |                              |
                       |   Super Gussun Oyoyo 2 SFC   |
                       |   English Translation v1.0   |
                       |                              |
                       ================================

                            http://www.rpgone.net

=================================================================================

-------------------
 Table of Contents 
-------------------
I.     What's New
II     Patch Contents
III.   Project Information
IV.    About the Game
V.     How to Start Playing
VI.    Playing the Game 
VII.   Known Bugs
VIII.  Credits
IX.    Disclaimer


-------------
I. What's New
-------------

v 1.0 (December 24, 2004) - First release.  See the Known Bugs list below for
bugs present in this patch.


------------------
II. Patch Contents
------------------

 The ZIP file you downloaded should contain the following files:

SGO2E_10.IPS - The patch itself.
README.TXT - This file.

 See the How to Start Playing section for instructions on what to do with the
IPS file.


------------------------
III. Project Information
------------------------

Sky Render's Comments:

 The Super Gussun Oyoyo 2 translation was started, more than anything, by good
old fashioned curiosity.  Sevaral years prior, I was looking for a new SNES game
to play, and came across SGO2.  The zany, almost cartoonish tone of the game
caught my attention, but at the time, I wasn't a part of RPGOne.  I took note of
the game, but didn't expect to ever have the ability to recode it myself.  A long
time passed, and I joined RPGOne.  One day, Chris asked me if there were any
potentially small translation projects I might be interested in working on, and
SGO2 came to mind.  And so, work began.  From the start, the project was fairly
secret (only one or two other people knew about it), so making it a surprise
release later proved quite easy.

 The script got translated quickly (there's only about 20 pages of it; puzzle
games rarely have a lot of story), while the recoding went underway in bursts
between other, bigger projects.  Come late September, Chris got the idea of
releasing the game as a Halloween treat, to which I of course agreed.  We both
doubled our efforts on the game (him working on the recoding, me working on the
myriad of Japanese text in images that needed to be translated).  I don't doubt
that mine was the easier task, for though it can be tedious to re-design images
to match the original art and be in English, Chris' task was far more time-
consuming and arduous.  His patience and perseverance never ceases to amaze me.
Anyway, we didn't meet our planned release.  But that was okay, as there turned
out to be a few stray things we forgot about anyway.  So we kept up work on the
project for the next two months (on and off, as it were; Chris was having some
health problems), did some quick testing (not a lot was needed; SGO2 is a small
game), and decided to send the game out to the public as a Christmas/holiday
treat instead.

 Working on this game was a joy, especially after the long and arduous Final
Fantasy VI translation.  I was given a chance to do something in it that FF6 did
not afford me, that being the redesigning the myriad of images to be in English.
It was an experience worth having, as well as a great challenge, as there would
always be yet another little thing popping up that needed translation.  In the
end, if I had to choose again, I would gladly take on SGO2 without a second
thought involved.

Translation Notes:

 As said before, this game was much easier to translate than the behemoth that
was FF6.  However, there were a few things I intentionally left untranslated,
which will be explained here.  First is the banner on the stage select screen.
It's hard to make out properly due to the pole the flag is on, but it's the Kanji
for ice (koori).  Second is the curtain in Puzzle mode.  It has the Kanji for
drama (geki) on it, and is basically a theatre curtain.  Lastly is during
George's ending, where his ship's flags and name are left untranslated.  The
flags both say Big Fish (oo sakana), and the boat is called the Perfect Man (maru
otoko).  None of these really needed to be translated, as they either have
absolutely no significance whatsoever (ice banner and George's ship), or are
there more for stylistic reasons anyway (drama curtain).  Other than those,
everything is translated more or less as literally as possible, given the general
on-screen space limitations.

Sky Render
RPGOne Translations


ChrisRPG's Comments:

Super Gussun Oyoyo 2 is a really great puzzle game worth some playtime, though it
may be frustrating at times for the people like me who are not very coordinated
between eye and hand movement. After we finished the 1.0 version of Final Fantasy
6, I wanted to work with him on some other smaller games as well. Since we worked
well together and I knew he would always do his best, it was a logical decision
for me to want to work on other great games we haven't had the pleasure of
playing in our own language yet. Not to mention that translators are very hard to
come by, or at least responsible hard-working ones that keep in touch. So at
Sky's suggestion I played the game a little, and ended up really liking it
because it was a very different game than I had ever played before. It is a
puzzle game with a cute little story and some very challenging levels as well.

We started the process soon after FF6 was done. Sky made the tables and I dumped
the text and sent it off to him. He had it done very quickly, and I was impressed
at how fast I got it back in English. But I had other projects to work on too
like FF6 1.2, Slayers, Koryu no Mimi, DQ12 French, DQ12 Portuguese, DQ3, etc. So
I just never got around to working really hard on it. I was thinking it would be
done in a very short amount of time anyways. Boy was I wrong! There were things I
have done on this game I havent for any other, technically speaking, like reading
the second joypad. I still managed to learn lots of new things about the SNES and
how it and its programming works. This is great because it will carry over to our
other up and coming projects. During the early part of October 2004 (I think) we
decided we would try and finish it up for our Halloween celebration at RPGOne on
the 31st. Well doing variable width fonts for all 3 text systems alone was going
to be a job in that amount of time, and I just couldnt quite get it all together
by then. Sky Render did all the graphic work for this game including fonts and
title screen and most of it during that month. We even learned better ways of
dealing with graphics in SNES projects as a result. I had managed to get a
sketchy vwf routine for 1 of the 3 text systems in place with many problems left
in it, and finish the menus (which are done in pseudo-vwf) and pretty much all
the rest of the games graphic text. But there were still too many issues to have
a 1.0 version done for that day. During November I just couldnt find enough
ooomph to get the font programming done due to health and other reasons, but when
December came around that all changed. It seemed after a couple weeks of
scrapping all my variable width font work and starting over I was just not making
any progress, but I kept at it. On December 21st 2004, it all started to finally
look good and come together at once. In the past 2 days, the game has gone from
pretty bad shape still to comepletely done. What you have here is the final
result of our efforts so far.

If it wasn't for Sky Render shouldering the burden of a lot of things on this
project we would probably still be working on it. So a lot of credit goes to him
for this game translation. It is a really fun game, so give it a try! I hope you
enjoy it as much as we are now.

ChrisRPG
RPGOne Translations


------------------
IV. About the Game
------------------

 Super Gussun Oyoyo 2 is very different from most games, and has a brief history,
which befits such a simple title.  The game's predecessor was released originally
as an arcade game in Japan, and with its strange mix of Lemmings and Tetris
gameplay, it hit off fairly well.  When the time came to make a sequel, they
decided to change a number of things from the first game.  The second game is set
on an island instead of in a cave, and it also contains numerous layout and
control improvements.  They also added a new gameplay mode (Puzzle Gussun), and
modified the Versus mode to be more interesting and fun.  Unlike the original
Super Gussun Oyoyo, SGO2 has never been released on any other system (SGO1 was
later re-released on the Sega CD, with improved graphics).

 IREM still makes Gussun Oyoyo games, their latest being a PlayStation one called
Gussun Paradise (or Yoyo's Puzzle Park in Europe and Australia; it was never
released in the US).  They're also known for making the R-TYPE series, and are
planning to release an action RPG soon called Bumpy Trot.


-----------------------
V. How to Start Playing
-----------------------

 You will need to apply this patch onto a ROM image of Super Gussun Oyoyo 2.
Please do not ask us where to obtain this image, it can be done with a careful
search of the Internet.  However, it is required that this patch be applied to an
ORIGINAL, unmodified ROM.

 To apply the image, you will need an IPS patching program.  The easiest one to
use would be IPSWin. You can get this and other programs from www.emuxhaven.net.
Open this IPS program and apply the patch (SGO2E.IPS) to the original Super
Gussun Oyoyo 2 ROM.  After you patched the ROM, just start up your emulator, load
up the ROM, and start playing!


--------------------
VI. Playing the Game 
--------------------

Super Gussun Oyoyo 2 controls:

D-Pad:   Move cursor (menus), move current block (game)
A:       Confirm (menus), rotate block clockwise/detonate bomb (game)
B:       Cancel (menus), rotate block counter-clockwise/detonate bomb (game)
X:       Not used
Y:       Not used
Select:  Not used
Start:   Pause (game)
L:       Not used
R:       Not used

 Either controller can be used.  Controller 1 controls Gussun, controller 2
controls Oyoyo.

 Gameplay Modes: There are 3 modes: Game, Puzzle, and Versus.  Game mode is
outlined in detail in the sections below, and is where the game's story can be
found.  Puzzle mode has you trying to get your villager to the goal as quickly as
possible, usually via some very fiendish puzzles.  Versus mode is a 2-player-only
mode that lets you test your block-stacking and villager-moving skill against a
fellow player.  Sadly, there is no CPU setting for Versus mode.

 Gameplay Basics: Your goal, for Game and Puzzle mode, is to get your Nanoda
Villager (Gussun, Oyoyo, or one you've made for Puzzle mode) to one of the exits
for the current level.  In Versus, your goal is simply to survive.  Both of these
goals require you to utilize the blocks you have control of to help the Nanoda
Villagers get to where you want them.  The simplest way to do this is by building
staircases out of the blocks for them to climb up, but more subtle means exist;
the villagers are always on the move, and can climb onto objects even before they
are placed.  You can also push them with objects, which can be a useful way to
get them to goals.  And you can also scare them for a few seconds by dropping a
block right next to them.  They move twice as fast and climb instantly when
scared.  However, they're also harder to keep up with when they're this way.

 Hazards: Quite a number of obstacles lie in your way.  Most notably are
monsters, spikes, and water.  Monsters can be dealt with by either squishing them
(be careful when doing this from above; your block will drop out of control once
the enemy is squished!) or trapping them.  The latter is preferred, as the
monsters will respawn after a certain amount of time.  Spikes are a more terrain-
based hazard, and easily avoided; they can only kill the Nanoda Villagers from
the side they're facing, so if you block off that side, they can't do anything.
Water is the biggest hazard of them all.  After a certain amount of time in a
level, the water will start rising, and if the villager gets too far underwater,
they'll drown!  The easiest solution to this is to reach the exit before the
water can get high enough to cause this.

 Items: There are a number of items you can obtain in SGO2.  First is the mini-
villager.  These smaller villagers will trail your hero, and if they reach the
goal along with the hero, they'll be added to your total.  Any time you collect
10 of them, you get an extra life.  Next up is the Chalice, which will cause your
villager to kill any enemies he touches for the next 10 seconds, starting from
when he's hit.  There's also the Air Bubble, which will let your villager survive
underwater for 10 seconds.  The Water Crystal will lower the water level by half
of the level's total height, and is critical in certain levels.  The Stopwatch
will halt all enemies and prevent the water from rising for 10 seconds.  And
lastly, food items give point bonuses.  You can carry up to two Chalices and/or
Air Bubbles with you between levels, but all other items cannot be transferred
over (save mini-villagers, as explained above).

Versus Items: Versus mode uses a different set of items entirely.  These items
are as follows: the X block (which causes the next 3 blocks dropped by your
opponent to be immovable), the fire extinguisher (which stops the flames on your
side for about 10 seconds), the medkit (which restores some health), and the
bomb (which drops a bomb in a random location on your opponent's side).


---------------
VII. Known Bugs
---------------

 These are the known issues caused by the Super Gussun Oyoyo 2 patch.

* - The ending sequence does not flicker excessively, but it does in the Japanese
version.  (Sky's note: I don't really think that's a bug; more like an
improvement.  Then again, I'm not a big fan of excessively flickering things...)

 These issues are inherent in the game.

* - In Versus mode, if the current level drops 1 or more greater than the level
that your character is standing on, and there is a block above them in the
appropriate position, they will become trapped inside of that block when the
level is done dropping.


-------------
VIII. Credits
-------------

Project Leaders           ChrisRPG
                          Sky Render

Programming               ChrisRPG

Text and Image            Sky Render
  Translation

Play-Testing              Phantasia Knights
                          Sky Render

Tools Programming         Cynsob (Scripter)
                          Klarth (Atlas)
                          Byuu (XKAS)
                          D (FEIDIAN)


--------------
IX. Disclaimer
--------------

Super Gussun Oyoyo 2 is Copyright (c) IREM and Banpresto, and all related images,
names, and themes are trademarks of IREM and Banpresto.

RPGOne is in no way or form affiliated with IREM or Banpresto, or any other video
game companies.  It shall not be held liable for any damages of any type arising
out of or in any way connected with your use of the patches and utilities it
releases, nor be involved in any legal procedures that result from this usage.

This patch is FREEWARE. You may NOT distribute this patch with a ROM image or
applied to a ROM image.

We do not endorse game piracy.  If you like the game, please support IREM and
Banpresto and buy it.

Visit RPGOne's webpage at http://www.rpgone.net/ for more information on the game
and on our other projects.  We hope you enjoy this patch!