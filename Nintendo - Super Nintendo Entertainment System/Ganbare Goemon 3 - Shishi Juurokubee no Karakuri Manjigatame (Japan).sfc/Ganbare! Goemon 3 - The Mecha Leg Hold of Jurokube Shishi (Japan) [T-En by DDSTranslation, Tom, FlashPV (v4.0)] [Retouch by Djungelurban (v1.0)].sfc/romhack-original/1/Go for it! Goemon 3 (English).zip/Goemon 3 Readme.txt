Go for it!

Goemon 3:
The Mecha Leg Hold of Jurokube Shishi

Translation Patch (Version Four)


Version Four
  - Reverts a word back to Japanese.

Version Three
  - Updates some graphics to use solid black instead of transparent pixels.
  - Fixes the Walker sprite when jumping north off of ledges.
  - Moved some ledges in the Mechanical Tower to dissuade players accidentally getting stuck above them.
  - Fixed typos and positioning of text.

Version Two
  - Fixes the Game Over screen.
  - Fixes pink screen bug when playing on hardware.


-----------------------
  GENERAL INFORMATION
-----------------------

This patch is for Goemon 3 on the Super Famicom.
The text has been translated from Japanese into American English.

Two patching formats are provided, so you can use either .bps or .ips.
(Do not apply both patches.)

The original Japanese file should have a CRC32 checksum of 7E5929E8, with a file size of 2,097,152 bytes.
In ROM sets, it will likely be labeled as the "version 1.0" one.


-----------
  CREDITS
-----------

Hacking and testing:
DDSTranslation

Translation:
Tom

Graphics:
FlashPV
