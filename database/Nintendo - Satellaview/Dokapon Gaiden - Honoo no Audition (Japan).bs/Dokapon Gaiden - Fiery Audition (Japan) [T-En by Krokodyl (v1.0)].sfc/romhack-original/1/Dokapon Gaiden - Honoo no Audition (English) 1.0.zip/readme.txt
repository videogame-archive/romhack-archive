########################################################################

This is the English translation for Dokapon Gaiden 〜Honō no Audition〜
released in 1995 for the Super Famicom.

Current version : 1.0

It applies to the following ROM :
File: Dokapon Gaiden - Honoo no Audition (Japan)
No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 8A3C4A376A93555454421B6B660FE8EF9190B270
File/ROM CRC32: A1684B6C

------------------------------- THE GAME -------------------------------
4 players (Human or CPUs) take turns going around a board.
The goal is to have the most gold at the end.
You get gold from different sources: random events, fighting monsters,
fighting other players (you take half of the gold of defeated opponents)
or simply completing a lap around the board.

While keeping gold is important as it is your final score, it can be
used during the game to upgrade your gear and your stats to help you
fight better.

--------------------------- THE TRANSLATION ----------------------------
Find more information (missing translations, bugs, tools)
about the translation project here :
https://github.com/Krokodyl/dokapon-gaiden

Feel free to contribute and improve/fix any issues.


                                                           Cheers,
                                                           Krokodyl
########################################################################