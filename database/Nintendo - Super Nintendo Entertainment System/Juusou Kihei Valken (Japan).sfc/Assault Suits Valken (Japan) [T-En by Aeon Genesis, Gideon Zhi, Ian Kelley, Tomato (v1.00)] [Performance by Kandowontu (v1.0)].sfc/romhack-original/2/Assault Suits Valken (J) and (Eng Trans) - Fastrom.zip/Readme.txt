This is FASTROM for Assault Suits Valken (J) and the English translation by Aeon Genesis

CRC32 of original rom is A5F63557 (since there is no no-intro rom)
CRC32 of the Aeon Genesis translated rom **UNHEADERED** is 123285E1

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5