# Opera Page
from PyQt5 import QtCore
from PyQt5 import QtWidgets
import os.path

class operaPage(QtWidgets.QWizardPage):
        def __init__(self):
              super().__init__()