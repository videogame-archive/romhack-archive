JUTEI SENKI
ENGLISH TRANSLATION V1.00
Copyright 2003 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Jutei Senki
2.Patch History
3.Patch Credits and Contributors
4.Known Issues With the Patch
5.Application Instructions

-------------------
1.About Jutei Senki
-------------------
Jutei Senki is a fairly long and difficult strategy game,
produced by Tam Tam and published by Enix. I suck at it.
Your mileage may vary. It's kinda fun, though.

---------------
2.Patch History
---------------
Damned if I know when I started this thing. The earliest file
I have sitting on any of my computers is a zip of some stuff
Jair did, and it's dated February 20, 2001. Draw your own
conclusions. Really, there isn't anything in this game that
necessitated such a long time between the beginning of the
hacking process and the actual release at least insofar as
the bulk of the stuff to be translated is concerned, but there
-were- lots of technical issues that had to either be overcome
or at least worked around. That has been done, mostly in the past
month or so, and now Jutei Senki is in your hands. Have fun!

April 3, 2003 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE JUTEI SENKI TEAM

Gideon Zhi - Project leader, romhacker
Shih Tzu - Translation of introduction, Techniques screens
Jair - Translation of tutorial missions, various lists
Datenshi - Translation of scenario titles
Bug Catcher - Translation of the ending

-----------------------------
4.Known Issues with the Patch
-----------------------------
-There are no known issues with the patch.

This patch has not been officially tested.

I've chea... er, played through every mission, but that was
before rigging up the ending and tutorial screens, so if
something's broken, let me know on my forum, The Pantheon.
(http://donut.parodius.com/agtp).
--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "jutei.smc" make sure the patch
is "jutei.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
a header. If you right-click the ROM and select Properties, it
should read "1.50 MB (1,573,376 bytes)". SNESTool can add headers
for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
Your answers to the questions it prompts you with do not matter unless
you plan on using a copier to play the game.

Please note that there are two patches: one for the interleaved version
of the game I first turned up, and one for the non-interleaved version
of the game. Try jutei.ips first (this goes to the non-interleaved ROM)
and if that doesn't work, try jutei-i.ips instead. If you're DOS-savvy,
the SMC.COM program will tell you whether or not your ROM is interleaved.