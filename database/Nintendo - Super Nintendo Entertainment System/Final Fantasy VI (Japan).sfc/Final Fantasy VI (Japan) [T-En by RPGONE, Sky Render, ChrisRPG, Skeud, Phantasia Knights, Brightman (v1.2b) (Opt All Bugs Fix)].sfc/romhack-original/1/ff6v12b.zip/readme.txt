=================================================================================
         #######################                                             ####
     #############################                                     #########
   #################################                               ############ 
  #######     #######       ########   #########        ######    ############ 
 #######     #######      #########   ###########    ##########      ########
#######     #####################     #####  ####  #####   ####     ########
           ###################       ##########  #####             ########
          #################         #####       #####   #######   ########
         #######   ########        #####        #####    ####    ########
        #######    ########      ########       ############    ########
       #######     ########     ########         ##########    ########
      #######      #########                                 ##########
     ###########   ##########################################################
    #############  ###########################################################
   ############### ############################################################
  ################  ############################################################
 #################    ###########################################################

    R   P   G   O   N   E      T   R   A   N   S   L   A   T   I   O   N   S
=================================================================================

                                   Presents

                       ================================
                       |                              |
                       |     Final Fantasy VI SFC     |
                       |  English Retranslation v1.2b |
                       |                              |
                       ================================

                            http://www.rpgone.net


 ==============================================================================
 |   This release is dedicated to the late Ronald Blayton, a dear friend of   |
 | ChrisRPG who provided him with a home, a PC, and much needed moral support |
 | throughout this and other translation projects. Without your support, this |
 |        project would never have reached this point. Thank you.             |
 ==============================================================================

=================================================================================

-------------------
 Table of Contents 
-------------------
I.     What's New
II     Patch Contents
III.   Project Introduction
IV.    A Brief Glimpse Behind the Scene
V.     About the Game
VI.    How to Start Playing
VII.   Playing the Game 
VIII.  Known Bugs
IX.    Credits
X.     Help Us
XI.    Disclaimer


-------------
I. What's New
-------------

v 1.2b (March 6, 2005) - Minor bug-fix release.

1) Changed the ROM name back to FINAL FANTASY 6, so it's compatible with the
newer ZSNES releases.



v 1.2a (February 25, 2005) - Bug-fix release.

1) Repaired a few errors in the text, and clarified a few hard-to-understand
lines of dialogue.



v 1.2 (September 26, 2004) - Major release.

The following things were changed in this patch:

1) The first 25% of the script was entirely retranslated from scratch.  It was
realized shortly after the 1.1 release that the original 25% was mostly a test
translation that was only marginally accurate.

2) Various code and file structure was optimized, and a new assembler was used
to build the final product.  Most of this is in preparation for the 2.0 process.
                                                                   --Sky Render


v 1.1 (May 15, 2004) - Bug-Fix release. Square bug fixes are now on a separate
patch.

The following things were changed in the patch:

1) Sword skills are now put in memory like they should when you start a new game. 
Unfortunately, the game only does this when you are starting a new game. SO any 
old save states will not work with this. If you don't want to start over, go 
into your abilities menu, then Cayene's sword skill menu and rename them to 
something else for now. I have verified they are being put into memory now and 
they weren't before. They always were translated but I forgot that the start of 
the game is what loads those names into memory and I forgot to include that with 
the first patch that went out. Anyway it works so you can rename them to whatever 
you want then use them in battle and they should appear just as they do in the 
skill menu since they use the same font in menu and battle routines.

2) I messed up magic list column alignment in one of the fixes. There are 3 
columns of spells, and if there were 3 spells on one line the 2nd 2 columns were 
being moved making spells appear run together. This has been fixed without 
breaking the fix that corrects the columns when there is only one spell on the 
line. This will work with older saves.

3) Item names were truncated to 9 letters once again after fixing the item name 
in the treasure chests etc. and only the first word appearing items in battle 
text. This is now fixed to let up to 20 letters display if something gets cutoff 
again let me know please this can be sed with old saves too.
                                                                   --ChrisRPG

4) Fixed two items being sold for the wrong price

5) Many typos and grammatical errors fixed

6) Magic-Based changed to Majick

7) Shogun changed to General
                                                                   --Sky Render


v 1.0 (May 1, 2004) - First release. See known bugs list below for bugs 
present in this patch.


-----------------
II. Patch Content
-----------------
The zip file you downloaded should content the following files:

* FF6V12.IPS - This is the main patch file that contains the translation. 
* README.TXT - This file.

The files below should be applied to the FF6 ROM after applying the main
patch, but are optional bug fixes:

* CAYENNE.IPS - This patch will fix the Psycho Cayenne (Cyan) bug. In the 
unpatched version, if Cayenne uses his second Sword Skill, gets turned 
into a Kappa, and is revived, he'll attack endlessly the next time anybody 
takes action. This bug causes glitches and freezes so applying this patch 
will fix this problem.
* EQUIP.IPS - This patch fixes the Equip bug, which causes the game to allow 
you to equip items at the wrong places.
* EVADE.IPS - This patch will fix the Evade bug. In the unpatched game, the 
game completely ignores the Evade stat and instead uses the Magic Evade
stat for physical attacks as well as magic attacks. Applying this patch 
will allow the game to use the Evade stat once again.
* RIPPLE.IPS - This patch will fix the Ripple bug. In the unpatched game,
the Ripple skill (which is an enemy skill/Memorized tech that the Leech
Frog and Black Force enemies as well as Stragos can use) exchanges all
status conditions, including Tina's Tranform status and Shadow's Interceptor
Guard. By applying this patch, only normal status ailments will be exchanged.
* VANISH_DEATH.IPS - This patch fixes the Vanish & Deasth bug. In the
unpatched game, when you cast Vanish and then Death on an enemy, it
automatically  kills them, even if they are immune to the death status. This
patch will fix this problem. 

* ALL.IPS - This patch fixes all the above bugs. 


-------------------------
III. Project Introduction
-------------------------

===============================================================================
From the Project Leader
===============================================================================

1) A Brief History of the Translation:

Final Fantasy VI has proven to be a very educational experience for me.
When I started the project, I had no real clear goal in mind; it was just
something to do, for the most part.  When I finally started taking the
effort seriously, I realized that there was more to this game than I had
originally thought, both in terms of story and challenge in translating.
What follows is a brief recount of the project's history.

The origins of this project lie in my original work with the FF3US ROM.  I
had decided, on a whim, to see if I could hack and improve FF3US.  This was
back around October, 1999.  My efforts, though misguided, got me wondering
if maybe it might be worth it to translate FF6.  I'd never done a game
translation before in my life, so the idea was pretty crazy.  I didn't even
know where to start.  Fortunately for me, this problem was solved when an
online friend of mine (who went by the alias Frioniel at the time) showed
me a table file he'd worked up for FF6.  I dumped the script for the game
almost immediately, and went to work on making more tables for dealing with
the game's menus.  This was around February of 2000.  My crazy idea was
suddenly not so crazy after all, and I made what has to be the worst "beta"
versions of the translation ever.  Still, in the process, I learned a lot
about ROMhacking and text locating, extracting, and reinserting.

Around late April of 2000, the ASM hacker for the French FF3US translation
(Skeud Skeud) offered to help me out.  I accepted his offer, he did quite a
few things that made the translation and reinsertion effort even more
possible.  Had he not vanished around June of 2002, the project would
likely have been released a year ago (albeit with nowhere near the quality
that the translation has now).  For a long time after Skeud's mysterious
disappearance, it looked like the project was doomed to forever be nothing
more than some clumsy "beta" releases, a few text files, and an insane
dream.  I even went so far as to basically label the project dead, since I
had little hope of finishing it without Skeud's help.  But then, somebody
stepped in and changed all that.

Phantasia Knights intervened.  On January 23rd of 2003, he sent me an
e-mail asking me about the project's status, and when I told him about the
lack of an ASM coder, he was the one who suggested I contact RPGOne, and
ChrisRPG.  Of course, I've always been hesitant when it comes to asking
others for help (especially when asking somebody as busy as ChrisRPG), but
Phantasia offered to help out, and I took him up on his offer.  After a
brief correspondence, Chris and I began communicating more directly, and he
agreed to help out.  Things were rocky at first (mostly because I have
trouble communicating, and Chris often assumed that my lack of response
meant I was upset with him), but in time, we came to understand each other,
and my dream for FF6 became our dream for FF6.  I joined RPGOne shortly
after we began work together, and have not regretted my decision to do so
(nor do I expect I ever will).  If not for one fan's help, this project
would not even exist now.  My thanks go out to you, Phantasia Knights.  You
are a great friend, and skilled at encouraging people to try things when
they're afraid to.  I hope you'll continue to help us take such plunges for
years to come.

From this point, the story of the translation is mostly Chris' story.  My
work had been more or less complete for about a year at that point, but we
still communicated on a regular basis, and worked out problems with various
early translations I had done.  Never before have I ever met anybody so
dedicated to their work, nor one so open-minded and willing to go above and
beyond the call of duty.  The translation, as it stands now, is far more
than it was when I originally finished it and had planned to release it,
because Chris was always willing to go further to change the game's code
itself to accomodate the extensive text.  Chris, your friendship and
understanding were, are, and always will be appreciated and reciprocated as
best as I am able.  For all that you have suffered through, you deserve at
least that much; indeed, you deserve far more.

2) Translation Notes:

One big translation problem I had was with the puzzle in Darryl's Tomb.
The original puzzle is a curious and very amusing bit that reads "rest in
peace" one way, and essentially says "rot and wither" the other way.  This
sort of puzzle is infinitely easier to express in Japanese, since the
language is much simpler when it comes to assembling words.  In English,
the task of translating it effectively proved impossible, so I ended up
instead expressing my thoughts on the matter as the solution to the puzzle
(and I'm sure players of FF3US will get a good chuckle out of it).

Most of the item names I tried to stick as close as possible to the
original Japanese version.  In the majority of cases, this was no problem
at all.  Some items had very complex names that sounded awkward when
directly translated, and as such, I simplified their names a bit, and
generally made them conform a bit closer to the more recent FF's released
in the US (though only in cases where the US versions had names that were
close to the Japanese version names).  Other items sounded much better when
left in Japanese, and thus, they stayed that way.  This mostly only applies
to Shadow's and Cayenne's weapons.

Monster names were more often than not very frustrating things to work
with, as a good deal of them refer to vague mythological creatures.  A few
I still am unsure of, and others I probably got the mythological creature
referred to wrong.  In the end, I hope that I got at least the greater part
of the monster names translated correctly.  I should extend many thanks to
Lord Skylark for his help on figuring out many of the more obscure names.

Character names were rarely a problem.  The main cast names are all listed
at the end of the game (though they messed up, and Stragos is called
Stragus during those; all official text refers to him as Stragos).   Some
names in the translation might provoke a few raised eyebrows.  One of these
is Cefca.  Strange though it may be, Cefca is the correct spelling for this
character's name.  The official works released for FF6 in Japan list his
name as such.  Another one is the town of Narche, which is pronounced
"narshay".  It's spelled the way it is because it was originally meant to
have a French feel to it.  Ghastra is just a clever play on the word
ghastly, from what I can tell, and is spelled that way for the same reason
that Cefca is spelled the way it is.

On the whole, the translation is prioritized first for accuracy, then for
readability.  Having both all the time is very difficult to manage, but I
hope I've at least come close to it.  As of this writing, the scripts have
all been revised three times, hopefully making them all the easier to
understand and providing a better flow of dialogue than the unrevised
translation did.

                                                       - Sky Render
                                                         February 29th, 2004

===============================================================================
From the Lead Programmer
===============================================================================

Final Fantasy and Dragon Quest are my favorite all time RPG series. I first
became interested in the project when I saw Sky Render's site a few years
back. But I saw he had someone working on hacking so I never bothered to
ask. Then I guess for whatever reason that person, Skued, couldn't work on
the game any longer and was missing in action so to speak. Phantasia
Knights, a huge fan of the game and the project, decided to ask me if I
would be interested, and he is responsible for bringing Sky Render's awesome
translation job and my hacking work together. That started us on our road to
friendship as well. I will always be grateful for Sky's patience,
understanding, passion for the original Final Fantasy VI, and compassion for
what I have gone through during this long period of time that we have been
working together on it. For him it was always a dream and I hope with my
help that has been realized somewhat.

All along the way I have had one challenge after another, and I've overcome
almost every one, both the project challenges and personal challenges. So 
this project will always hold a special place in my heart. This game has 
practically been taken apart and put back together in a way as to let Sky 
Render's translation of FF6 shine through. Yes, there are still some minor 
problems outlined in the current bugs or issues sections so please read them 
and don't report them to us. But overall this is one the projects I am most 
proud of in terms of programming in 65816 assembly. I am by no means perfect, 
but thanks to the help of many people in the scene and hiding around the 
edges of the scene, I have been able to do some nice things with the game. 
And other features are already being worked on for a future 2.0 version, like 
a variable width font in 8x8 text in menus, additions to the descriptions in 
the game that don't currently have them, and maybe even 8 letter names along 
with several other things. Some of the ground work for these have already 
been done. But we both feel the game is in the state of quality now that 
warranted a 1.0 release. We didn't want to torture you all for another few 
years after all. We hope you enjoy the time and effort we all have put 
into this game as much as we will, since I will now take the next few days 
to actually play it through rather than looking for bugs. Most bugs have 
been found and squashed already before a release as to avoid thirty v1.x 
releases. I even fixed a few of the bugs that Square sent out with the 
game. A separate patch is also available to take out the bug where you 
if you cast vanish then death on an enemy, they are killed regardless 
if they are supposed to or not. We didn't fix that Square bug in our main 
patch since so many people have become accustomed to it but it was 
actually a flaw in the programming. Thanks to the person who runs this site 
http://www.rpglegion.com/ff6/index.htm, I was able to find the problem code 
in FF6 very quickly based on their FF3 square bugs work.

I'd like to say thank you to Cynsob, Klarth, D, and Byuu for their awesome
tools that let me work on projects without having to worry about coding
tools to work with each one. Meaning more time actually spent on the game
since I don't know much of any other PC programming language. I want to
thank the best internet host around, Emuxhaven. Without him we wouldn't have 
had the server to rely on for backups, and our group office system which has 
made this project easier to deal with for team members sharing files. And 
I would like to thank a large group of people for supporting us with this 
project. A lot of people say it's a waste since there is already a "GOOD" 
English version of the game from Squaresoft called Final Fantasy 3. While 
it may be "GOOD" in someone's eye's, it isn't in someone else's eyes. The 
main reason I work on the projects that I do is because I like the game 
myself and want to play it in English with more of the meaning in it from 
the Japanese version, and with extras if they can be done. I do not choose 
projects simply because it hasn't been done yet in English. I also feel that 
there are others who may feel the same about that project and I share the 
results of my efforts with them. If you aren't excited about a retranslation 
of Final Fantasy VI then don't play it. It is that simple. But if you are, 
then please enjoy it.

                                                       - ChrisRPG
                                                         May 1st, 2004

===============================================================================


------------------------------------
IV. A Brief Glimpse Behind the Scene
------------------------------------
Phantasia Knights History Notes.  
Edited in part, and fact checked by Sky Render.

===============================================================================

First off note that I am not a very experienced writer, so I may be too wordy 
in places, or not enough in some places.  Regardless, writing this is something
I've wanted to do for some time now, and now everyone can finally find out what
went on behind the scenes.

I first became involved in this project during January of 2003.  While 
searching for FF VI fansites for something I can no longer remember exactly, I 
happened across Sky Render's Domain and a hack to repair some of FF VI US's 
censored, bullshitted, and otherwise massacared translation.  I played through 
FF VI using this patch and discovered that it was a lot more fun with some of 
the things changed the way they were.  Afterwards I checked out the page on the
re-translation and found out about the dissapearance of Sky Render's original 
ASM hacker, Skeud, which has been missing for the last few years.  I didn't 
think much of it at first until several months passed without a translation 
patch update, and nothing but sarcastic remarks from Sky (most of which were 
pretty funny I must admit ;) ).  I then emailed Sky on January 23, 2003 
(despite several statements, warnings, requests, threats of dismemberment etc 
on his page saying not to email him and that emails will be ignored), and made 
the following plea:  

"Is my crying to be silenced forever?  Am I to weep in solitude as my dreams of
a great rom translation are shattered again?  Will your Final Fantasy VI 
re-translation ever see the light of day before my April 20th birthday?  
Please!  Think of the fan-boys! :D

Narrarator: "When we last left our hero, he said he was waiting for Skeud to 
finish the ASM work and script relocation.  Is Skeud alive?  Is he well?  Or 
has he succumbed to the fate worse than death of abandonment?

To be concluded in our next exciting episode: Sky Render Replies Again! 
(Hopefully ;D )"

This has been a test of the Emergency Rant System.  Had this not been an actual
emergency, the author of the letter would have been sarcastic.  Thank you for 
listening, and goodnight.

Your Shameless FF VI Fan-boy,

Phantasia Knights"

Looking back, I realize that I was quite the shameless prick, and that I 
probably got on Sky's nerves quite a bit (although he says his attitude about 
the translation at the time may have had something to do with it.)  I also 
realize that, ironically, I was doing the very opposite of what I am now quite 
against (driving people nuts about patch releases). I guess it shows how much 
this project has changed me.  Today however, Sky and I can look back and 
realize the humorous side of this, and how ironic it is that ignoring a request
can change the course of a project for the better.

Although the original email is lost, I can remember Sky's reply clear as day, 
in which he replies that he wishes he could oblige, but that he no longer has a
hacker since he went missing.  He did say however, that if I could help in any 
way, or find someone to help, that he would be grateful. 

Damn did I ever find someone to help.

During the Summer of 2002 I found RPGOne and began posting under my old 
username of Lunarian Sword.  It was during the age of the Dragon Quest I & II 
translation.  Something about the way Chris dedicated himself to his work had 
piqued my interest, and I began hanging out with the amazing people of RPGOne 
quite a bit.  

After Sky's initial reply to my first letter, I told him about ChrisRPG and the
amazing work he was doing with the DQ I & II translation.

"While I do not know any ASM hackers personally,  I do have an idea that may 
appeal to you.  Currently the only real English ROM translation site (besides 
yours) that is still active is RPGONE Translations.  Fortunately for the both 
of us, it's a website that specializes in RPG ROM translations.  The webmaster 
there, ChrisRPG,  is a very kind guy and he is also a great ASM programmer who 
completed the great Dragon Quest I & II Remix translation.  You can contact him
using one of the three means located on the Contact Page.  

I hope I helped you in some way. Final Fantasy VI is my favorite game of all 
time, and just once I want to see the true bullshit-free version.  Please let 
me know if you could work something out.

Wishing you lots of luck,

Phantasia Knights"

Please keep in mind that this was at a time when most translation sites were in
hibernation, and it is not meant to sound insulting.

Sky replied and said that it was a great idea.  Now all we had to do was set up
a meeting with ChrisRPG.  I sent Chris my best formal style email, telling him
all about Sky's efforts, with links, emails, AIM names, and whatnot.  He said 
that he would be happy to help out, and the rest was history!  I joined RPGOne,
and as Sky puts it "PhantasiaKnights gained a level!  Changed class to 
Moderator!", setup Chris and Sky with each other, and they began secretly 
getting the project setup undercover.  First off, Chris redid all of the ASM 
code from scratch, deleting Skeud's work and starting over.  What followed was 
the next year and a half of hacking, expansion, and script reinsertion.  Sky 
Render and I both agreed that Chris's work and dedication were the most amazing
that we had ever seen.

A few months later, Chris and Sky finally agreed that enough work was done to 
reveal the project to the public, and Sky's merger with RPGOne was complete.  
Sky Render formally joined RPGOne's staff at that point, and Sky Render 
Translations was permanently dissolved.

The merger and the FF VI project met with tons of mixed emotions, and even more
confusion.  Some wondered why and how the merger happened.  Others, why FF VI 
was being retranslated in the first place.  Some unscruptulous people and 
websites even setout to try to sabotage RPGOne's reputation, including laughing
in their face for taking on the project, and claiming it was "unneccesary".  
The criticism got so bad at one point that sometimes it was almost unbearable.
Thankfully the members of the Emuxhaven Forums jumped in with great support and
enthusiasm for the project, and things proceeded on a happy note regardless of 
other people's opinions or the occasional disaster.

Finally, around February 7, 2004, a monumental moment occured.  FF VI was 
finally ready to go into Beta Testing.  This is probably the most humorous part
of the project, because as Sky Render puts it, "One can occasionally miss 
words, especially at 3AM.".  Not only words, but even individual word 
translations (as with the Beast Plains being called the Great Plains at first).
Many classic quotes resulted from these bloopers though, such as the now 
classic "Will you jump on teh craen?". Other classic moments during testing 
include:

* Orthros speaking the Kaiser Dragon's (a dummied out boss monster) dialogue 
during the battle at the Lethe River.
* The Chocobo Stable man talking to you when you open chests (this happened 
almost every time).
* Becoming filthy stinking rich for buying a Drill at Figaro Castle. 
* A scene in Figaro Castle, where it said "Now I can drink my wine in peace" 
when you entered the nap room.

Dialogue also prints WAY too fast in spots. But one by one Chris tackled these 
errors and bugs while Sky and I mainly focused on fixing text and consistency 
errors, as well as proof-reading the walkthrough for the game.  

These guys are truly the best of their kind, and it is, and will always be, a 
great honor to work with them on all future projects (the next of which will 
blow the minds of everyone who sees it, as it will once again be a classic game
which will combine Sky Render's phenomenal translation skills, with Chris's AAA
hacking).  What these guys do together is the stuff translation dreams are made
of, and they are like part of a family to me.

Viva RPGOne, and every time you play FF VI, ask yourself...

"Will you jump on teh craen?"

                                                      - Phantasia Knights
                                                        April 25, 2004

================================================================================


-----------------
V. About the Game
-----------------
Final Fantasy VI is famous enough to need no elaborate introduction. It is 
merely the 6th game in the famous RPG franchise, the last Final Fantasy game 
on the Super Nintendo console, the last traditional 2D RPG for this series...

And in this game, you play as up to 14 characters in a quest to defend the 
world from an Empire who wishes to revive magic and a crazed madman who 
wishes to destroy it all. This game introduced a few new concepts that were 
new to the Final Fantasy series, including the "Phantom Beast" system and the 
Accessories system. It was also a big step forward in graphics as well as in
storytelling. 

So not surprisingly, this game was translated and released in North America, 
in 1994 as "Final Fantasy III", which of course, is a result of Square 
skipping over three games. However, due to space and time constraints, as 
well as Nintendo's strict game censorship at the time, this release was by 
no means faithful to the original Japanese release. Features were taken out, 
dialogue was censored, graphics were edited. More details can be obtained from 
Sky Render's comprehensive list of changes made to "Final Fantasy III" on the 
RPGOne Website at http://www.rpgone.net/ff6/ff6_changes.txt. 

Hence the goal of this release: To demonstrate to the English speaking folks
how this translation should have been done. Hopefully the players will be able
to enjoy this game like its meant to be enjoyed.


------------------------
VI. How to Start Playing
------------------------
You will need to apply this patch onto a ROM image of Final Fantasy VI. Please 
do not ask us where to obtain this image, it can be done with a careful search 
of the Internet. However, it is required that this patch be applied to the 
ORIGINAL, unmodified rom. 

================================================================================
| IMPORTANT: This patch does NOT work on the Final Fantasy III English ROM. It |
| will only work on the ORIGINAL Final Fantasy VI JAPANESE ROM. So be careful  |
| which ROM you are applying this to.                                          |
================================================================================

To apply the image, you will need an IPS patching program. The easiest one to 
use would be IPSWin. You can get this and other programs from www.emuxhaven.net. 
Open this IPS program and apply the patch (FF6V11.IPS) to the original Final 
Fantasy VI ROM. If you choose to apply the bug-fix patches, do so after 
applying the main patch. After you patched the ROM, just start up your emulator, 
load up the ROM, and start playing! 


---------------------
VII. Playing the Game
---------------------
Final Fantasy VI controls:

D-Pad:   Move character (Field), Scroll between options (Battle, Menu)
X:       Menu (Field)
Y:       Cancel (Field, Battle, Menu)
A:       Confirm/Action/Examine (Field, Battle, Menu)
B:       Cancel (Field, Battle, Menu)
Select:  Hold to speed up scrolling (Menu)
Start:   Show/Hide Map (Worldmap), Pause (Battle)
L:       Switch between characters (Menu)
R:       Switch between characters (Menu)
L+R      Run (Battle)

Note: Control can be customized in the Options menu.

For more information on the game's systems, there are in-game tutorial
scattered through the storyline. Please use them well.

Please visit the FF6 Cyclopedia at http://www.figaroscholars.com/ and 
http://www.rpgone.net/ff6.htm for additional information on playing the 
game.


----------------
VIII. Known Bugs
----------------
Known issues and bugs that are caused by the patch:

* The MP Cost line from magic menus in battle appears in the slot menu for
Setzer in battle. We are working on trying to fix this for a follow up 
patch

* When using short command menus in battle, the Defend menu will overlap 
the HP numbers in the Status menu

---------------

Emulator Specific Problems.

* ZSNES has issues with not displaying cursors in menus in and out of
battle, this is a problem for all versions of FF6

* ZSNES WIP from Dec 2003 until current ones, graphics when walking around
in the outer world will glitch, this is a problem for all versions of FF6

* SNES9X will lock up in the ending credits

---------------

Known bugs that were left in the original game by Square and are not 
fixed. Most of these are either unrepairable, or would require too much 
time to fix:

* When a character in slot 1 is set to be controlled by Controller 2, the
game will not allow Controller 1 to advance messages in battle

* When a character in slot 1 is set to be controlled by Controller 2, the
game plays the Controller 1 turn sound when that character's turn comes
up during battle (instead of the Controller 2 turn sound)

* Controller 2 cannot board the airship or open the menu on the world map

* Controller 2 cannot go on-deck while flying the airship

* Controller 2 cannot do anything in towns and dungeons

* Controller 2 cannot do anything in the system menu

* Petrified characters will still cringe when hit by attacks

* When using Mug in conjunction with the Warrior's Proof accessory, you
will only actually steal the last item that you are told you stole, but the
game will not let you steal from any other enemies you successfully "stole"
from during the attack series; this also applies to the Thief's Knife when
attacking wih Warrior's Proof or jumping with the Flying Dragon Horn

* Attempting to Mug while equipped with Dice causes graphical glitches, and
often misses (Dice are not meant to be used as normal weapons)

* Using Jump can cause many bugs; certain attacks enemies can use can cause
you to be stuck as invisible and unable to act; if an enemy jumps, using a
Superball while there are no enemies on screen can cause this to happen to
them

* Casting Reraise on an enemy and then hitting them with Degen causes them
to no longer be visible or targettable; they can still take action, though;
casting Meltdown can fix this

* Having a character perform Jump while equipped with a Flying Dragon Horn
and the Kazekiri Blade can cause them to become invisible if Wind Slash
activates; they're still there and targettable by enemy attacks, though; if
they die, they won't be able to be ressurected, since your allies cannot
target them

* If you equip a shield that causes status conditions while in battle, you
will be immune to those status conditions as long as that shield is
equipped, but you will not be put under them (this mostly applies to the
Bloodstained Shield)

* Heal Rod targetting is backwards; it should target allies by default, and
enemies when Throwing it

* Joker Death can teach Stragos the Level 5 Death technique

* Bad Breath, though it causes Kappa status, does not actually change enemy
graphics to that of a Kappa

* Death Roulette is not random when cast via Mimic, nor is it random when
cast by a confused, charmed, or zombified character/monster

* If Slot triggers 3 BARs and Quetzali is summoned, the user of Slot will
take an extra step backwards after they land

* If Slot triggers 3 BARs and Phoenix is summoned, the user of Slot will
take a step forward for each character that blocks the spell with their
shield; this effect also happens when using Mimic after Phoenix is summoned
this way

* When using one of the three attack scroll skills (Katon, Suiton, Raijin)
via Rage, the user will not walk back to their normal position after using
it

* If a single attack's damage should exceed 65535 (you can't really check
this, as the game caps actual damage dealt at 9999), the attack will only
do the amount it should minus 65535

* Losing against a group of rat enemies in the Opera Theater during the
World of Ruin will send you back to the World of Balance; this is a game-
ruining bug

---------------

Please do not report any of these problems to us since we are aware of
them. 


-----------
IX. Credits
-----------
Project Leader            Sky Render

Lead Programmer           ChrisRPG

Translation               Sky Render

Programming/Hacking       ChrisRPG
                          Sky Render
                          Skeud Skeud

Script Editing            Sky Render
                          Phantasia Knights
                          Nathan Alden
                          Stian Mathisen
                          Frioniel
                          A-Ron
                          GMBFly98
                          Brian C.
                          Thundor
                          Kokiri Kid
                          Hexdump
                          David Saulesco
                          VampyreHunter "D"

Tools Programming         Cynsob        
                          Klarth
                          Byuu
                          D

Project Coordination      Phantasia Knights

Beta Test Coordination    Brightman

Testers                   OrdosAlpha
                          Iriliane
                          Shadowsithe
                          Zeke_D
                          MagusExtreme
                          Zarggg
                          liraman
                          Shinrin
                          Wielder of Crystalis
                          Mega_Mizzle_X
                          Abobo
                          Ajax
                          Tuxedo Jim
                          Phantasia Knights

Coding Reference
 (On Fixing Square Bugs)  Kris DeHart (http://www.rpglegion.com/ff6)


A Special Thanks To
Emuxhaven,  Brightman, Phantasia Knights, Cynsob, Klarth, D, Byuu, 
Ronald Blayton, Anoda, Gideon Zhi, Amitirius, and anyone who supports 
our projects and what we do.


----------
X. Help Us
----------
If you discover any problems within the patch, please do not hesitate to
contact Sky Render at torquemada_gi@hotmail.com or ChrisRPG at 
chrisrpg@mechanicomics.com. We want this release to be as
close to perfection as possible, so if there's any bug that we don't 
already know about (see above), then we'd like to know about it.

---

--------------
XI. Disclaimer
--------------
Final Fantasy VI is Copyright (c) Square Enix and all related images, names, 
and themes are trademarks of Square Enix.

RPGOne is in no way or form affiliated with Square Enix or any other video game 
companies. It shall not be held liable for any damages of any type arising out 
of or in any way connected with your use of the patches and utilities it 
releases, nor be involved in any legal procedures that result from this usage. 

This patch is FREEWARE. You may NOT distribute this patch with a rom image or 
applied to a rom image. 

We do not endorse game piracy. If you like the game, please support Square Enix
and buy it.

Visit RPGOne's webpage at http://www.rpgone.net for more information on the game
and on our other projects. We hope you enjoy this patch!
