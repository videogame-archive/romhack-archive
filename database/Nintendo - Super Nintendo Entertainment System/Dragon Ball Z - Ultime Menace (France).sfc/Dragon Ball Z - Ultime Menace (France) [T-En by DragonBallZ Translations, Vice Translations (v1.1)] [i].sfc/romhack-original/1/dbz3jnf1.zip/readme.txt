Dragon Ball Z: Shin Butoden 3 = Ultime Menace French to English Translation
Copyright 2000, DragonballZ Translations and Vice Translations
Original patch by Vincent, DragonballZ Translations
Project continued by Kitsune Sniper, Steven Csuth & Jason Rubin 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This patch is for the FRENCH ROM ONLY!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Recently, Vincent released this statement:


****************************************************************************************
This is the last patch. I will no longer be working on this game because 
in my opinion, it is crap. There is no story mode or any good about this game. 
Since I have all the Dbz game for playstation, I'd rather play my playstation game 
instead of a game that doesn't interest me. If anyone wants to continue the translation, 
feel free to do so. The table file is on my site if you want to translate it. 
Please do not bug me about how to patch.
****************************************************************************************

  I agree on the crap part, but I have a certain sentimentalism towards the game, 
since this was the first Dragon Ball game I ever played, and not emulated, but 
on my old SNES, using a friend's japanese pirate version. I barely could execute all the 
special moves, but I liked it because I beat the $#it out of my friends!

 If you wish to translate this into any other language, contact me.
I wanted to translate this game to spanish, but I'm getting fed up with it!
Besides, the word NETTOU is in the horizon... 

IF I FIND OUT THAT YOU USE MY PATCH IN A TRANSLATION WITHOUT
MY PERMISSION, SAY GOODBYE TO YOUR E-MAIL ACCOUNT, AND QUITE POSSIBLY,
YOUR REPUTATION!

One more thing. If you find my patch and decide to post it on your 
site, please contact me at my email address and send me your site's 
address. If possible, I'll add your site to my links section, and I'll 
notify you of any updates.

***************
Version History
***************
Version 1.1 = May 6, 2000, 4:19 PM [11,678 bytes]
... Now all the dialogue is finished. It turns out that I missed Chibi-Trunks'
victory dialogues... One of the translators, Jason Rubin, pointed this error out to me 
yesterday. Thanks! That's two I owe ya!

Version 1.0 = April 27, 2000, 11:24 PM [11,528 bytes]
All the dialogue is finished! All that's left are those damn menus!

Version .88 = April 27, 2000, 10:44 PM [10,838 bytes]
The dialogue for Future Trunks and No. 18 is in! Only Kaioshin's dialogue is left!
Come on, Kit! You can finish this tonight!

Version .75 = April 27, 2000, 6:04 PM *NOT RELEASED* [9614 bytes]
Boo and Dabula's dialogue is in! Only three more characters to go! 
This patch is getting very big!

Version .65 = April 27, 2000, 12:06 PM *NOT RELEASED* [8088 bytes]
Vegeta's, Gohan's, Chibi-Trunks' and Goten's entire dialogue has been inserted. I'm very bored... 
this game is getting very lame, fast... I've got to finish this soon...

Version .45 = April 25, 2000, 10:07 PM [5403 Bytes]
Goku's entire dialogue has been inserted! Wow. I hadn't noticed it, but the size of this
patch is three times as big as my original patch! Anyway, I'm off to bed. Later!

Version .40 = April 23, 2000, 10:28 PM *NOT RELEASED* [4752 Bytes]
All of the pre-fight dialogues are complete. I forgot to add some dialogue on the last patch.
Sorry, I was almost asleep. [Hey, it was 12:49 AM when I finished it! =/] I'm off to bed to get 
some Z's, tomorrow I have my first job interview!

Version .30 = April 23, 2000, 12:49 AM [3513 Bytes]
I've translated all of the Special Attack moves, including the Super Desperation Moves. 
I've scrapped the initial translation, and the pre-fight messages of the fighters against
anyone except themselves and their rivals are translated.

Version .21 = April 21, 2000 *NOT RELEASED*
I've translated the end of the Tournament and the credits. There wasn't too much to do
there, since the only things I changed were "Translator" and the character's names. I've
also changed the name of the highest difficulty from "SUPER" to "INSANE". It's a lot more
appropiate in my opinion!

Version .20 = April 19-20, 2000 [1892 Bytes]
A major breakthrough has happened in the menu translation and decoding!
I managed to find the codes for the menus, and a whole lotta fonts as well! 
Strangely, there's even some Kanji in there! I corrected the names for Goku[SANGOKU to GOKU], 
Gohan[SANGOHAN to GOHAN], Goten[SANGOTEN to GOTEN] and Boo[BOU to BOO]. I also translated 
some more menus and the difficulty indicator.

Version .15 = April 16, 2000 [1680 Bytes]
Kitsune Sniper decides to continue the translation. Many of the in-game menus 
are translated, and some moves under the "Command Help" section are renamed also, 
mostly Goku's moves. [Who spelled Masenko 'Masenco'?!]

Version .10 ?? 2000
The game is translated 10%. Vincent announces that he will not work on 
this anymore, due to reasons explained above.

***************
NOTES / Known issues
***************
  There are menus that I couldn't translate, because I couldn't find the letters that they
  use in them...

  Some of the dialogue has been edited for clarity and space limitations. 

 -Vegetas Big Bang Attack was originally translated as "Demon Flash". I kept this name 
  due to space limitations.

 -Vegeta's Final Flash was originally translated as "Vegeta Ray [Beam]".

 -... I forgot to send Steven the final attack names, as well as Future Trunks' moves.
  I based them off of Kyo Kusanagi's FAQ, which helped me a great deal! It's most likely 
  the best source of information on the japanese game. You can get it at www.gamefaqs.com.


***************
What's left
***************
Those damn menus!


***************
How to patch [by Vincent]
***************
First, get SNESTool12 [I've included it ~K]. Then put that in the same
folder with the rom and the patch. Double click on
SNESTool12. Press "u" to use the patch. Use the arrow
keys to move to the patch. Press "Enter" to select it.
Then use the arrow keys to move to the rom. Press
"Enter" to select. It should say "IPS patched ok."
near the bottom in the Info space. Then press "q" to
quit, and you have just patched a rom.


Please do not bother me on how to patch roms. Any questions regarding 
how to patch roms will be IGNORED [everything else is OK].


***************************
Other Stuff
***************************

If you like my patch, feel free to send praises, rolls of quarters, old
Depeche Mode singles, cassetes and CDs [bootlegs or original], etc. to kitsune@terra.com. 
Remember this: I don't speak a speck of french. I can, however, help out in any way
I can in any translation as a Beta Tester, script writer, and spanish translator. 
I can find bugs in anything you throw at me!



****************************
Ze credits - 
****************************
 Vincent - Original patch creator and game hacker.

 Steven Csuth & Jason Rubin - Main Translators
   These guys did a great job! Give 'em a hand! [No, wait! Don't cut it... 
   someone get them a band-aid...!]

 David "Kitsune Sniper" Silva Garc�a - Subsequent game hacking and script
   investigation, some dialogue and name interpretation, and the menu translation
   [only the easy ones =P].
   email: ->  <kitsune@terra.com> or <kitsune_sniper@yahoo.com>

 Kyo Kusanagi - He wrote the FAQ which helped me to understand the game a lot more.
   I know you don't approve emulation, but thanks anyway, Kyo!

 People who offered their help in the translation: Sadlifah and Daniel ESPIAU.


****************************
Greetings to: [In no part. order]
****************************
 Everyone above, Salvador "Chava" Ramirez, Gideon Zhi, satsu and the B.S.S. team, TNSe, wraith,
  and everyone at the Zophar's Domain Rom Hacking message board, for answering my questions
  with their discussions.



***
DISCLAIMER
***
DragonballZ Translations [and its affiliate, SniperSide Translations] translation
patches and are not official or supported by any video game company or any other 
entity associated with the "Dragonball Z" trademark or franchise [we wish!]. In no
event shall the persons or groups mentioned above be held liable or responsible for
any damages that may occur from direct, indirect, or consequential results of the
ability or disability to use or misuse any material they provide.

In other words, if something goes wrong, don't blame us!

Finally, I hereby prohibit Zophar's Domain and its staff from posting any of
my translation patches, future translation documents, or to even mention me 
in any way that is or is not emulation related. This is not done as
punishment towards the site for the actions its current maintainer,
SwampGas, had inflicted upon the rom translation community. That is forgiven.
However, I am asking nicely that these files not be posted at the site. If
you don't respect the wishes of the translators themselves, well, you have
no business mentioning me at all.

I can't and won't sue you if you post the files there; but if you do, well,
you're not complying with my wishes. And I don't think people may like that.


***********************
The Homepages
***********************
DragonballZ Translations
http://www.dbztranslation.f2s.com/

Vice Translations
http://vice.parodius.com

Thanks,
Kitsune Sniper, A.K.A. David Silva Garc�a, Mexicali, B.C., M�xico.


Later.