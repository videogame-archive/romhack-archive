                                       Magic Knight Rayearth
                                       English Retranslation
                                     v1.02 (October 20th, 2022)

====================================================================================================

- Magic Knight Rayearth (c) CLAMP, Kodansha Ltd., Yomiuri TV, Dentsu Inc., TMS
    Magic Knight Rayearth (1995 SFC video game) (c) TOMY, in addition to the previous
    holders. All rights reserved.

- No ownership is claimed by mziab over Magic Knight Rayearth or the franchise
   from which it originates. Commercial use of this patch, including but not limited to
   reproduction, sale, etc. is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   mziab is not liable for damage incurred to the end-user, their OS, or their
   hardware while using this patch.

- Apply this patch only to an unheadered "Magic Knight Rayearth (Japan).sfc" with the
   following specifications.
     Hashes: CRC32 - EDE4B627
               MD5 - C8FD6FB87F202DB2B3DBBCCFE1FDAA24
              SHA1 - B0BD7E46C98C1CCF042BE0EA3401445C461B76BD

- Send error reports to mziab either by posting in the project thread on
   ROMhacking.net, or via the site's PM feature.


   Table of Contents

To reach a given section, Ctrl+F the text fragments in brackets.


Preface ............. [RM01]
Changelog ........... [RM02]
Easy Mode ........... [RM03]
Credits ............. [RM04]

====================================================================================================

   [RM01] Preface
   
  mziab

This all started when I implemented a dialogue VWF and dual-line hack for the
Polish translation of Rayearth back in 2013 and thought to myself "gee,
wouldn't it be nice to port this over to the English patch". But this idea was
put on the backburner due to other projects and various circumstances.

Some years later, in 2022, after completing a few other SNES romhacking
projects, I remembered this idea, but decided to dive in deeper. After dumping
the Japanese menu and later dialogue, it became apparent that the text itself
needed improvement. Having worked on the Sailor Moon Another Story
relocalization, I thought the game could use a thorough retranslation and
since the script was small and simple enough, I took a stab at retranslating
it myself in July 2022.

The old script contained some obvious contextual errors. Several item, monster
and spell names were mistranslated, changed or abbreviated. And while the bare
meaning is mostly conveyed in the dialogue, it's not a very good read and
loses much of the charm and quirks of the original Japanese, making some of
the conversations and humor fall flat. While usable, the old translation is
not the best representation of the original. So I went over the entire script
with a fine-toothed comb, compared each line with the original and rewrote and
tweaked the script until I felt it was true to the original intent and
enjoyable to read. I go over my translation choices in more detail in the
liner notes included with this release, so please refer to it if you want to
know more.

What you have in front of you is the sum of two months of work plus code
changes carried over from my earlier translation project. Over 80% of the
dialogue has been retranslated or rewritten, along with over 40% of the menu
text. I do think this patch is worth playing for the variable-width font alone
and new English script should make it a fresh experience even if you know the
game by heart. Anyway, I hope this is as fun to play for you, as making this
was for me. Enjoy!


====================================================================================================

   [RM02] Changelog

v1.02 (October 20th, 2022)

- Fixed half a dozen typos and rephrased one line reported by Felipefpl

- Moved "Gold" in menus to the left to avoid a cosmetic glitch with 100k+ Gold

v1.01 (October 1st, 2022)

- Corrected a few typos, rephrased a few lines

v1.00 (September 1st, 2022)

- Implemented VWF for dialogue text

- Implemented dual-line hack for items, spells, equipment and monster names

- Retranslated and thoroughly rewrote the dialogue (80%+ changed)

- Retranslated item/spell names and descriptions (40%+ changed)

- Replaced menu font with a Chicago variant courtesy of FlamePurge

- Implemented proper plural verbs in monster attacks/appears messages

- Translated title screen credits

- Made status ailment names consistent with menu descriptions

====================================================================================================

   [RM03] Easy Mode

This release also includes an optional patch to reduce the grind, similarly to
what Grind-Be-Gone did for Sailor Moon Another Story. It halves the random
encounter rate, while doubling the EXP and Gold drops. The patch should work
with any version of the game, but was only tested with the English one.

====================================================================================================

   [RM04] Credits

- mziab: Tools, reprogramming, graphical editing, translation

- blip: Text insertion tools (re-used from the Polish translation project)

- ffgriever: Kanji ID, translation support and consultation

- FlamePurge: Font editing, localization consultation

Special thanks to RPGe/LNF Translations for their translation patch,
which enabled fans to play the game in English way back in 1999!
