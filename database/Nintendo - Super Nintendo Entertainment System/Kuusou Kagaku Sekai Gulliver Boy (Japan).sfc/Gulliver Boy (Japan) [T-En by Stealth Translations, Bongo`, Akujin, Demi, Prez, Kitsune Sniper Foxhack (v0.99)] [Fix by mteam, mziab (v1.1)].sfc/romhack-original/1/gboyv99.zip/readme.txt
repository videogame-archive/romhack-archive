(c) 1996 Gulliver Boy Translation
(c) 2001 Stealth Translations


----------- Version 0.99 released May 26th, 2001 4:10 P.M eastern time -----------
Bug Fix:
 Thanks to Kitsune Sniper, Zatos and Myself I found and fixed a bug that
 displayed the end part of Gulliver's name backwards. And I also forgot
 to change "Edokkou" to "Edokko". That has been fixed. As for the bug 
 that Snes9x produces while trying to display my Title hack, I can't
 trace that routine using Windows. So I don't know what the problem
 may be. It seems to work fine in Zsnes. Just for safety, I added a vram
 clear routine to TRY and remove any garbage left on a reset or whatever.
 But it still seems to be buggy in snes9x. That's it for now.


----------- Version 0.99 released May 24th, 2001 2:05 A.M eastern time -----------

Hacking:
 Main and Only hacker, Bongo`

Translator:
 Akujin, Thanks a million!

Artist:
 Demi - Thanks for the title Drawing. I tried converting it the best I could.
 Prez - Most, if not all of the Start menu graphic work.

Script revision:
 Kitsune Sniper - Thanks buddy. Sorry for acting an ass at times.


Beta tester(s):
 Kitsune Sniper
 Gideon Zhi
 Zatos


Thanks go out to Deltaflame for giving me this project.


--------------------------- Notes ---------------------------------

*NOTE*
	 Due to the structure of the hacked data in this ROM, 
 I doubt this game will work after being copied for use on a
 real Snes. Who knows, I may be wrong. But I'm pretty sure that
 it shouldn't work. You never know.

   Well, all I can say is, patch the game, play the
 game, Try to enjoy the game. And if any bugs, errors
   or whatever are found, please let me know at
	     Stealthtrans@hotmail.com

 I beta tested the game one last time to fix some bugs
 and then I reinserted the repaired text. I don't know
 if there are any new bugs there. It's late, I'm tired
  and all I want to do is sleep. You can give me feed
         back as well. That would be nice. 
     Until next release or project, good night!


---------------------------  EOF  ---------------------------------