This is for the Flying Hero - Bugyuru no Daibouken (J) - enjoy!

CRC of original ROM: 1A19FC3A

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

ANONYMOUS
RC_Meatpuppet
SAM M.
mobilevil
June M.

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5