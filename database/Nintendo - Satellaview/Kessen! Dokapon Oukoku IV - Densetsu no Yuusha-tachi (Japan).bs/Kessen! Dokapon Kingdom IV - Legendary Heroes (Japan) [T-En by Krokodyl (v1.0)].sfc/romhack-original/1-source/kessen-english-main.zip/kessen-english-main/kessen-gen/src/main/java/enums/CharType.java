package enums;

public enum CharType {

    SINGLE,
    DOUBLE_STRAIGHT,
    MODE_F0,
    MODE_F1,
    MODE_FB,
    MODE_FD,
    MODE_BF

}
