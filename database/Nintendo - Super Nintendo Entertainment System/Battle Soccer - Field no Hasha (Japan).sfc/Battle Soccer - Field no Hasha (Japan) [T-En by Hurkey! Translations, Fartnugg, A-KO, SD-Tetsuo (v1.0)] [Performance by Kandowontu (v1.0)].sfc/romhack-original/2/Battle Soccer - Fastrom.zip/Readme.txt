This is FASTROM for Battle Soccer (J) and works perfectly fine with the english translation patch (be wary of the RHDN patch, it doesn't patch properly to the no-intro set)

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5