Rockman7 EP

*web
http://borokobo.web.fc2.com/
(Neo Borokuzu Koubou/Neo Scrap Workshop)

*about patching
 Please use ips to no-header / no-interleave file.(2,097,152 bytes)

*minimum playing guide
 - For some reason, I'm not recommend using password. To suspend game, use the savestate instead.
 - Hold X + D-pad[neutral/8 directions] to switch weapons. [Megabuster/8 weapons]
 - Hold A + D-pad[neutral/4 directions] to switch weapons. [adapter/others]
 - You can use 3 friends from the beginning.
   Rush generates invincible field. It's high cost to fire Megabuster with Rush-field.
   Their energies are recharged at gameover or some rare situation.
 - You have some equipments from the beginning, and you can use "EXIT" (almost) anytime.
 - There are lots of strange features in this game.

*translating
 There is no English version.
 If you are interested in translating, please read the text "translating/translating.txt".

*for achievement maniac
 The text "forAchievementManiac.txt" may help you.
