
			Restored content 	
Battle2 and Singing Mountain music tracks added 

Octorider, Johnny and Frog King enemies can now be fought

A few restored lines from the pre-release re-added 	

Added unused guns for Lucca with unique projectiles. 

Destroyed dome and coliseum map tiles added. 

Magus' keep now fully visible on the world map. Cut Zeal dungeon re-added 

A few DS or Japanese uncensored equipment and Tech names restored 		 
              



                    Changes to linearity 
Crono is an optional character for most of the game now. 

Porre Ferry goes to Choras allowing it to be explored from the beggining. 

The first trip to 65,000000 b.c can be done anytime after arriving at the End of Time. 

Magus can be recruited or fought or avoided altogether on the cape anytime after the ocean palace, 
making him available for the Blackbird. 

The powered up pendant carries over allowing early Epoch in NG+ 

Ozzie's fort can be done any time after Magus' castle. 

Spekkio is optional allowing for no magic runs. Must now complete both sides of the factory 

Can now leave the Black Omen between the fight with Zeal and the fight with Lavos 




                          Nu content 	 
MSU-1 music fully integrated (still requires the tracks) 

The two other islands in Zeal are now fully explorable 

1999 is now fully accesible 

Full new dungeon in 2300ad 

Chrono's mom has a bedroom 

Choras has a small ferry station. 

Reptite Village in 65000000Bc 

Optional battle with the 'Prophet' in the second visit to Zeal 

More scenes with the whole party. 

Frog will be in his human form in cutscenes if Magus is beaten, hopefully a fully playable Glenn 
will be available soon. 

All items now have descriptions. 

You can now save Zeal by beating Lavos in the Ocean Palace. 		
                 



                    Rebalance or Gameplay changes
All Rock triple techs learned permanantly by events and no longer require an accessory slot. 

Spekkio changes forms when beaten not dependant on player level. 

Charm less effective, Twin Charm more effective Filling house whith cats much less grindy 

Levels gained quicker overall but stat gains spread out to level ** instead of 50, making the game more challenging 
but with better progression. 

Marle and Lucca have much better Hit growth allowing them to use physical attacks more effectivly. 

Haste, Protect and Magic Wall now target whole party. 

No enemies Charm Megaelixers, few enemies drop items. 

All single tech heals have reduced power. Lightning 2 and Life are swapped to make Chrono consistent with the others 

Required TP is adjusted to keep the characters learning at the same rate 

fair prizes carry over. 

All character gain 100% experience. 		

                    


                         Optional Patches 
Luccabeta changes Luccas outfit.

Menu music allows currect music to play in the party change menu.

Magus Cape turns Magus' cape red like in the animated cutscenes 

"Marle" just changes her palette slightly, (done by request). 

Autorun makes run the default, hold B to walk 

Balanced difficulty reduces money by half, makes some enemies 
a little stronger, reduces the power of Ultimate techs. cant purchase more than 10 items. can only swap 
characters at save points. 

          

                    Condensed 1999 walkthrough 

The Epoch can be used in 1999 after bringing the Life Sparkle found in Lab 64 to Mr Bangor.

The more of the character sidequests that are done the more of 1999 is available. 

Talk to Gob after the Sunstone quest with Lucca in the party. 

The chip items found around 1999 are used to boost stats at the arris dome, however before its available you 
must do a series of quests first. To begin do the Rainbow Shell quest then go to the Giant's Claw area 
from the teleporter in 1999 and beat the Dactyl, then go back to the Reptite village and recruit the Reptites 
(certain parties are more persuasive) 

The drone can be purchased in the pawn shop in Truce (West City) its the purple orb on the counter. 

The speed shoes are won from the arcade in Medina. 

The black box in Medina is available after the 2300 Geno 
Dome is cleared. After the Black box is activated a character will give you a quest, go to Proto Dome 1999 
with Robo in the lead and talk to Atropos, then go to the bar in Choras. Once this quest is complete 
revisit the black box in Medina and the Geno dome in 2300.