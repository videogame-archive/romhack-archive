08/01/2003

TERMINUS TRADUCTION presents

BS CHRONO TRIGGER MUSIC LIBRARY, English Version

----------------------------------------------------------------
***********************Table of Contents************************
----------------------------------------------------------------

1.	THE STORY OF CHRONO TRIGGER MUSIC LIBRARY
2.      ARCHIVE'S CONTENTS
3.      RELEASES
4.	WHAT'S DONE
5.	STAFF
6.      CONTACTS
7.	LEGAL STUFF

----------------------------------------------------------------
1.  THE STORY OF CHRONO TRIGGER MUSIC LIBRARY
----------------------------------------------------------------

This ROM is one of those published with the Satellaview
Broadcasting System.

It contains all the music from the game Chrono Trigger, along
with two previously unreleased themes, composed by Yasunori
Mitsuda and Nobuo Uematsu.

Here's a patch translating the songs' titles to English.

----------------------------------------------------------------
2.  ARCHIVE'S CONTENTS
----------------------------------------------------------------

The ZIP file should contain :

bsctml.ips - The patch
ReadMe.txt - The file you're reading

----------------------------------------------------------------
3.  RELEASES
----------------------------------------------------------------

1.00e - 08/01/2003

This patch, with everything in English.


1.00 - 12/25/2002

The first two patches, one in French, and the other with English
titles for the songs and a French menu.

----------------------------------------------------------------
4.  WHAT'S DONE
----------------------------------------------------------------

Font with VWF added and translation of the songs' titles.
There's not anything left in Japanese.

----------------------------------------------------------------
5.  STAFF
----------------------------------------------------------------

   Neo Mithrandil   : Hacker


Thanks to Copernic who has created the font used in this patch
for his French translation of Chrono Trigger (though, you won't
see it, since the characters he's added don't appear in this
version of the patch).

----------------------------------------------------------------
6.  CONTACTS
----------------------------------------------------------------

For any remark about this translation of BS Chrono Trigger Music
Library.

Neo Mithrandil - neo.mithrandil@laposte.net

You want to learn more about or translation group, download
our patches or get information about our projects.

Website - http://terminus.romhack.net	(In French)

----------------------------------------------------------------
7.  LEGAL STUFF
----------------------------------------------------------------

This translation patch for BS Chrono Trigger Music Library isn't
supported by Squaresoft.

This patch is free and can be distributed freely as long as it
isn't modified, applied to or distributed with a rom, and the
original archive isn't modified too.

You may use this patch at your own risk. None of the people
cited in this documentation will be held responsible for any
damage resulting of its use.

----------------------------------------------------------------

Thank you for reading this file and enjoy the patch !

Neo Mithrandil