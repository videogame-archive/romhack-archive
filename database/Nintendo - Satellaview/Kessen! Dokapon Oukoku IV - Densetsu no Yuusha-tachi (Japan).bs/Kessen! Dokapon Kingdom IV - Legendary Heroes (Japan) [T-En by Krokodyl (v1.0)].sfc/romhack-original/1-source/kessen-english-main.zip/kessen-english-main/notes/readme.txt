########################################################################################

This is the English translation for Kessen! Dokapon Oukoku IV - Densetsu no Yuusha-tachi
released in 1993 for the Super Famicom.

Current version : 1.0.

It applies to the following ROM :
File: Kessen! Dokapon Oukoku IV - Densetsu no Yuusha-tachi (Japan)
No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 45C4DE22174F01135628D8B61EFF0DE672BC7D30
File/ROM CRC32: 9BA1F895

------------------------------- THE GAME -------------------------------

The Japanese title roughly translates to
"Decisive Battle! Dokapon Kingdoms IV: Legendary Heroes".
This is the very first game in the Dokapon game series.
(the IV in the title refers to the possibility of supporting up to 4 players)

It is a mix of an RPG and a multiplayer board game.
Players move their heroes around the board, gaining levels and finding equipment,
and eventually saving a kingdom from encroaching monsters.
The goal is to be the richest player by the end of the game.

--------------------------- THE TRANSLATION ----------------------------
Find more information about the translation and the game :
https://github.com/Krokodyl/kessen-english

Feel free to contribute and improve/fix any issues.


                                                           Cheers,
                                                           Krokodyl
########################################################################################