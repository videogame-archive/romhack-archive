
#ifndef _DISCARD_H
#define _DISCARD_H

int discard_unused_sections(void);
int discard_iteration(void);
int discard_drop_labels(void);

#endif
