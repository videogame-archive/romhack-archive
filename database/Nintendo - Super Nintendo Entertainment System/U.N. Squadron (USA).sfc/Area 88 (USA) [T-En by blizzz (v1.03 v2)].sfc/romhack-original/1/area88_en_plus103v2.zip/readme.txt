==================================
 Area 88 EN+ (for U.N. Squadron)
   Author:     blizzz
   Version:    1.03 (v2)
   Date:       30 August 2021
==================================


Introduction
------------------------------------------------------------------------
Area 88 EN+ is a retranslation of U.N. Squadron that keeps the original
Japanese name of the game. In addition to the new translation and title
screen logo, this hack rebalances the mission rewards to encourage the
use of the mid tier fighters, the F-14D Tomcat and A-10A Thunderbolt II,
which most players skipped before. Both are fun planes that lead to
different strategies in the mid game levels.

Additionally, this patch unlocks the hidden gamer difficulty option and
changes the firing mode to full auto fire.

The patch has been verified on console.


Instructions
------------------------------------------------------------------------
-- Base game:
U.N. Squadron (USA).sfc - NoIntro (unheadered)
Size: 1048576, CRC32: 231F0F67
Apply area88_enplus_103.bps to the USA version of U.N. Squadron with
your patching tool of choice, for example Flips or the RHDN web patcher.
https://www.romhacking.net/patch/

-- FastROM hack by Vitor Vilela
Download: https://github.com/VitorVilela7/fastrom/releases/tag/v1.40
First apply un-squadron.bps from Vitor Vilela's FastROM project to the
USA version of U.N. Squadron. The CRC32 checksum should be 231F0F67
after patching.
Next apply area88_enplus_103_for_fastrom.bps to the patched rom.

-- MSU-1 Hack by PepilloPeV
First apply uns-msu1[NtscEng].bps to the USA version of
U.N. Squadron. The CRC32 checksum should be FE390648 after patching.
Next apply area88_enplus_103_for_msu1.bps to the patched rom.
(Note: The MSU-1 and FastROM hacks are not compatible with each other,
because they add custom code to the same rom location starting at
$00:FCE9)

-- Japanese plus version (untranslated)
Area 88 (Japan).sfc - NoIntro (unheadered)
Size: 1048576, CRC32: 06388F71
Apply area88_jpplus_103.bps to the Japan version of Area 88.
This patch only contains the reward and pricing changes, gamer mode and
full auto fire. The text is not translated.


Story
------------------------------------------------------------------------
UN Squadron was originally called Area 88 and is based on a manga by the
same name. That's why the symbols on the map show an 88. The manga,
which was written and drawn by Kaoru Shintani, follows the story of
Shin Kazama, an ace fighting student from Tokyo, who was tricked by a
jealous childhood friend into a 3-year contract with a mercenary
fighting squadron at Area 88 in the war-torn desert nation known as the 
Kingdom of Asran. Together with his comrades from the Foreign Legion, 
Shin is forced to fight in a bloody civil war of succession. His goal is
to survive the 3 years, raise $1.5 million to buy out his contract,
or die trying.
In the game, Area 88 is under attack by the weapons dealer organization
Project 4, which allied themselves with the Asran Rebels.


NoGrind changes
------------------------------------------------------------------------
Mission Reward Changes

Orig. >  New money reward       Score       Level Boss (unlock order)
 50k >  50k  +  0k   + 0%  |  10k > 10k  |  Missile Tank (I)
 70k >  75k  +  5k   + 7%  |  20k > 20k  |  Stealth Bomber (II)
 80k >  90k  + 10k   +13%  |  30k > 30k  |  Land Carrier (II)
 90k > 100k  + 10k   +11%  |  50k > 30k  |  Submarine (III.2)
 60k >  85k  + 25k   +42%  |  30k > 40k  |  Wolfpack (III.1)
100k > 125k  + 25k   +25%  |  40k > 50k  |  Forest Fortress (II)
100k > 150k  + 50k   +50%  |  40k > 60k  |  Battleship (II)
150k > 250k  +100k   +67%  |  50k > 60k  |  Giant Plane (IV)
200k > 300k  +100k   +50%  |  60k > 70k  |  Ceiling Machine (IV)
 20k >  25k  +  5k   +25%  |   5k >  2k  |  Convoy

Total reward increase: +325k
Score rewards for later levels have been adjusted to reflect the missing
score you'd get from playing the convoy mission.

Airplane prices
F-20  $250,000 > $180,000
F-14D $300,000 > $230,000
A-10A $350,000 > $250,000
YF-23 $500,000 > $400,000
F-200 $1,000,000


Credits
------------------------------------------------------------------------
Blizzz: hacking, translation, graphics
Natori Youkai: translation help


Version History
------------------------------------------------------------------------
1.03 - 30 August 2021
- changed some texts and minor changes to font
- removed name from title screen
- lowered plane prices slightly

1.02 - 01 February 2021
- compatible with msu1 version (and fastrom version)
- removed timeout during pilot selection
- fixed grey pixel in unicorn animation on titlescreen
- gamer difficulty selection now works in both directions
- rom no longer has to be expanded

1.01 - 25 January 2021
- fixed some typos

1.0 - 25 January 2021
- retranslation of briefings and shop menus
- some small changes

Beta1 rev2 - 21 January 2021
- further adjustments to rewards

Beta1 - 19 January 2021
- adjustments to prices and rewards
- new title screen
- retranslation of the intro and post mission messages
- minor text changes overall

v0.1 - 11 January 2021
- Initial release
- Increase mission rewards, decrease plane prices
- Unlock Gamer difficulty level
- Unlock full auto fire


Contact
------------------------------------------------------------------------
RHDN Forums:
https://www.romhacking.net/forum/index.php?action=profile;u=71746

Twitter: @blizzzilla
