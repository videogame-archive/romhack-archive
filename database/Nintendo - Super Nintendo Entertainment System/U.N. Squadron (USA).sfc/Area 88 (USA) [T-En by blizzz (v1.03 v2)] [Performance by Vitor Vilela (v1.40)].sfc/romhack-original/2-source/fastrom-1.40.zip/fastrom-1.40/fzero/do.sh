rm fzero.sfc; cp fzero_base.sfc fzero.sfc && asar -Dstrict=1 main.asm fzero.sfc
