AZELISTIC TRANSLATIONS PRESENTS:

Kunio's Dodgeball (Super Famicom) by Technos Japan
Translation Patch 1.0
Language: Japanese -> English
Created by Azel

Version 1.0: fixes three little script errors, fully translates
             the elusive debug menu -> thus making this a truly
             100% finished translation. Released on 07/17/2004
Version 0.99-2: fixes some player names, released on 07/09/2004
Version 0.99: 100% translated, released on 06/22/2004

	�,.��=椺��`� �`�����=-CONTENTS-=椺��`� �`�����=��.,�

1. About the game
2. Controls
3. Project History
4. Translation Notes
5. Credits
6. Special Thanks/Acknowledgements
7. Contact Information
8. Tools used
9. Known Issues/Patching Instructions
X. Legal Notice


     �,.��=椺��`� �`�����=-About the game-=椺��`� �`�����=��.,�

Kunio's Dodgeball is the second to last dodgeball game that was
released by Technos Japan, the legendary video game company that
basically *invented* dodgeball video games with their NES game called
'Nekketsu Koukou Dodgeball-bu'. (The last one being 'Super Dodgeball'
for the Neo Geo, if you're interested.)

But what the heck IS a dodgeball game anyway, you might wonder. Well,
I don't know about you, but back in my days, we used to play dodgeball
at SCHOOL sometimes. Come to think of it, you probably do remember
dodgeball from your own schooldays as well - why else would you have
downloaded a translation patch for a dodgeball game? Though chances
are that you've played one or the other Kunio-kun game before, most
likely 'Super Dodgeball' for the NES. Which is the US version of the
aforementioned 'Nekketsu Koukou Dodgeball-bu' and a true classic. And
also the one game I think to be the very best multiplayer game for NES.
If you've ever played it, you know what I mean.

...what? You neither remember dodgeball from your schooldays nor do you
know 'Super Dodgeball'? Incredible. Hmm, seems like I need to explain
the rules to you, eh? Luckily this isn't all that tough as dodgeball is
a rather simple game. Two teams of seven players compete against each
other. These seven players are seperated into two fractions: 4 infield
players which surprisingly play INSIDE of the main field and 3 outfield
players which basically are standing outside of the enemy's field and
can never ENTER the main field, only hope that either the ball leaves
the field so they can pick it up or the ball gets passed to them by one
of their infield teammates. Goal of the game is to "kill" all enemy
infield players. How do you do that? Easy. Every player has got a
specific amount of HP and every time they get *hit* by a ball, this
amount is depleted. (The exact amount is calculated by way of a rather
complicated formula which includes attack strength of the player who
attacked, defense power of the player that was hit, speed of the ball,
type of shot ect. .) Once one team has disposed all enemy infielders,
that team has won the game. Not all that complex but cool nonetheless.

In this game you've got three main play modes. Of course there's the
standard Versus Mode in which you simply play one normal game for which
you can choose from all available teams. Then there's the Bean Ball
Mode. This one can best be described by the word "mayhem". It's a lot
like a normal game but ALL players can move freely around the field.
No restrictions infield/outfield. Makes for a quite action-filled
gameplay in which your catching and stealing skills are crucial for
success. To compensate for the rather large divergence from the
standard gameplay, you only get to control four players in all. Finally
there's the Tournament Mode. In this mode your custom-made team is on
its way to world championship. The goal of this mode is quickly
explained: just defeat each of the enemy teams once and you're champ.
This isn't all that quick and easy though as of course there're teams
which are stronger than others. And the difference is quite large like
between Level 8 and Level 30.

Yep, you read that right. This game features quite some elements you
know from roleplaying games. Most notably perhaps the fact that all
players have got a "Level" denoting their current overall ability. As
seems quite logical, the players also get experience points for the
actions they take in a game and eventually gain a level. Which raises
all the player's stats by a certain amount which differentiates from
player to player. Then there are items you can equip. Also like in RPGs
these raise a specific stat by a specific amount. Surely you need money
to buy these items then? That's right, and guess what? You actually
EARN the money through the games you play. The better you play and the
more spectacular or overwhelming your gameplay, the more money you get.
And finally there are different special shots which can be customized
by you. Don't like the fact that a certain special shot is activated
only by dive jumping on the default setting? Just change it to being
activated by dashing then. But now for the most interesting part of
this game...

You can create your very own team and players! (Actually, you even
*need* to create your own team if you were to play the Tournament Mode,
but anyway.) You can set the color of the clothes they wear, give them
a cool name, completely customize who plays and how they play. And -
which is a rather advanced feature for a game made in 1993, in my
opinion - you can trade, buy and scout players too! Meaning you really
can create a team only consisting of players YOU like. Though I'd
really suggest you keep Kunio in your team. He's cool and after all,
the game IS named after him, right? But let's get to the controls and
finish this (probably already too long) sections about gameplay.

        �,.��=椺��`� �`�����=-Controls-=椺��`� �`�����=��.,�

|~~~~~|
|Main |
 ~~~~~

Dash: Tap the D-Pad twice (any direction) [Yes, you can even run UP and
                                           DOWN. Useless, but you can
                                           do it anyway.]

Jump: Y+B
High Jump: Dash and then Y+B
Long Jump: Dash and then Dash again (a bit hard to pull off)
Diving Jump: Dash and then L+Y+B (a lot like the header special shot in
                                  the Kunio-kun soccer games)


|~~~~~~~~~~|
|Attacking |
 ~~~~~~~~~~

Shot: Y
Dash Shot: Dash and then Y
Jump Shot: Jump and then Y
Special Jump Shot: Y+B and then L+Y

Normal Pass: B
Outfield Pass (to end of field): Forward + B
Outfield Pass (to upper edge of field): Up + B
Outfield Pass (to lower edge of field): Down + B
Rear Pass: Back+B
Infield Pass (forward): L+Forward + B
Infield Pass (up): L+Up + B
Infield Pass (down): L+Down + B
Infield Pass (back): L+Back + B (about the same as the "Rear Pass")


|~~~~~~~~~~|
|Defending |
 ~~~~~~~~~~

Catch: Y
Block: L+Y

Kneeling Dodge: B
Covering Dodge: Forward+B
Sidewards Dodge: Up+B
Stupid-looking Sidewards Dodge: Down+B
Backwards Fall Dodge: Back+B
Hole Up "Dodge": L+B


|~~~~~~~~~~~~~~~~~~~~|
|Movement Directions |
 ~~~~~~~~~~~~~~~~~~~~

Long Jump Man: Forward+A
High Jump Man: Up+A
Diving Jump Man: Down+A
Post Man: Back+A
Approach Man: L+A
Cross Man: L+Forward + A
Line Dash Man: L+Up + A
Joint Man: L+Down + A (never got this one to work...)
Key Man: L+Back+ A


|~~~~~~~~~~~~~~~~~~~|
|Formation Commands |
 ~~~~~~~~~~~~~~~~~~~

Front Man: Forward+X
Top Man: Up+X
Bottom Man: Down+X
Rear Man: Back+X
Side Man: L+X
Ahead Man: L+Forward + X
Wing Man: L+Up + X (never got this one to work either...)
Distance Man: L+Down + X
Behind Man: L+Back + X

     �,.��=椺��`� �`�����=-Project History-=椺��`� �`�����=��.,�

...a long time ago, when I first found out about this game, I thought:
"Damn, why didn't they bring it at least to the US?" (Note that I'm
from Europe.)

Some time later, when I first had played it, I thought:
"Damn, this game just plain rocks. It kicks 'Super Dodgeball' in the
ass and is the best multiplayer game EVER." Of course I had some
problems with the fact that the game was completely in Japanese and I
was a) too young to understand much and b) got a bit frustrated after.

I left the game alone for a *long* time until about the spring/summer
of 2003. I had just gotten a bit involved into this rom translation
thing and was thinking of games that would deserve a translation. Not
to your surprise Kunio's Dodgeball was one of the very first games that
popped up in my mind. Now it's quite a long way from the initial plan
of translating a game up to the release of a finished 100% translation
patch. It seemed even longer to me who did hardly know any Japanese at
all back then. And the technical issues were simply overwhelming for
someone who hardly had figured out pointers back then. And so, once
more I strayed from the translation and got busy with other things.

It should be noted though that I neither wanted to give up the project
nor thought that I wouldn't be able to finish it. Granted, my Japanese
was nothing to write home about and at that time I could NOT handle the
technical issues, but I was surely determined to translate my favorite
Kunio-kun game into English.

In the following months I worked on several translations into German -
translations of English games as well as translations of Japanese games
 -, all of which were of a high quality, if I may say so myself. In
doing these translations I honed my skills, my technical skills as well
as my skill in the Japanese language. And not to a small degree did I
get better. What seemed impossible one year ago is now mostly nothing
more than a matter of TIME. After I had actually finished my first
really large translations into German (one of them was a RPG, so don't
bother questioning what I call "large") several weeks ago and in the
process gotten quite accustomed to things like MTE, expanding menues
and reprogramming some things (although I surely wouldn't say that I'm
one l33t ASM guy, mind you), I figured I was about ready to tackle my
first big English translation project.

As I wasn't that convinced of my capability in Japanese yet, I decided
not to start with Kunio's Dodgeball, but with "Winning Shot" - which is
one cool golf game for the PC Engine. I made incredibly quick progress
and soon had finished what I thought to be all text the game had to
offer. Then I finished the Tournament Mode for the first time and found
out that there's A HELL more text I hadn't even found in the rom yet.
And for a simple sports game there were remarkably many kanji in it.
Ack.

Not really surprising I soon switched to Kunio's Dodgeball as my main
project. On the one hand, I knew from the other Kunio-kun games I had
played before that this game would NOT surprise me with some extra text
block and on the other hand, as I now knew, most of the text was rather
basic Japanese and words Japanese kids probably learn in elementary
school already.

So I went to work and after a few days was finished with all that
menu stuff. Now that wasn't all that much farther than |pkiss had come
with his translation patch (well, from a technical point of view anyway
as I had of course TRANSLATED a hell more stuff than the Evolutions
patch did) and so now began the fun part. There were two major things
left: graphical stuff and the more complex things.

In the assumption that I'd probably be able to finish it quicker I
began the graphical hacking. And how wrong I was... Okay, I could do
the ending screen and the edit of the intro logo rather fast - but the
TITLE SCREEN drove me crazy. Honestly, I surely spent more time on this
one item than on all menu stuff before together. *sigh* The size of the
letters was rather awkward to start with and I'm "not that adept" at
graphics hacking as well, to say the least. I ended up doing a screen,
thinking it looked ugly, deleting it, doing a new screen, thinking it
looked ugly, deleting this one as well - and so on. I spent a whole
Sunday doing this damned title screen and it was late at night when I
FINALLY did something I found somewhat acceptable. It was somewhat of
a reinterpretation of the original 'Super Dodgeball' logo. So if you
think some letter looks weird (the "G" comes into mind), don't mourn -
it's not my fault, Technos did it that weird way first. The "Ball" part
of the screen was done from scratch by me and I think it looks really
cool for something I did from scratch. I mean, it looks even better
than the "Dodge" part which I merely had to reinterpret. I wasn't quite
finished with the screen just yet though... But to make a long story
short, I ended up doing miscellaneous edits here and there and the
"final" title screen wasn't ready until one week after I had done the
first draft. Yeah, "able to finish it quicker", sure.

After this feat was achieved, I only had to take care of the one major
technical issue of this game: the names. You see, player names, team
names, strategy names, formation names - heck, ALL names in this game -
don't use the same font as the main text. Well, this isn't exactly 
true. It DOES use the same font. But it also does some rather complex
thing and switches beginning/end byte and the very contents of the font
table. I had anticipated something like this, but only running
LordTech's modified SNES9x made it absolutely clear to me.

Now I was faced with a problem. How should I deal with this difficult
situation? I could have done some incredibly complex like trying to use
DMA transfer. But as I don't exactly got this figured out by now, I
decided to stick with a rather simple plan. Until...

I got this excellent idea. If the game cheats and uses more than five
characters (which is the maximum as you can easily see in-game), why
shouldn't I be able to? I only needed to figure out what and how to do
it. If you read this readme carefully, you might still remember that
the game uses a special way of text aligning that makes the Handakuon
(the thing that looks like this= �) and Dakuon (like this: '') "stick"
to the letter directly before it. Now if I could do something similar
to this and make the game display TWO characters in one "slot"? That
would be about perfect.

However, due to some restrictions font-wise I could not just reprogram
the font table and/or the table containing the entries of the font
table (yep, the game uses two completely different things for this).
This would just make the letter I put in instead of the original Dakuon
or Handakuon stick to the letter in front of it - and in exactly the
same way as those ABOVE the letter. Meaning it looked like o� only with
a letter instead of a "2". This kinda sucked and I could not find a way
to reprogram this rather crappy routine. I'll explain why in another
document. For now, here's how I finished the thing. I decided to stick
to a more oldschool way of displaying more characters and used one
technique commonly known as "squished tiles". It wasn't all that simple
though as I STILL had to modify the font routine a bit. But read on...

Shortly after I found a way and also got it to work. I replaced the
original font with my custom font and modified the way the game reads
it in a bit, and voil�, there you have a fully translated game
featuring names longer than 5 characters - but not taking up more than
five characters when being displayed. Yay. I dubbed this whole thing
"DLE" or "Dual Letter Encoding" as this is what it does: showing two
letters in the space/place of one.

This thing is probably the single most complex thing I've dealt with so
far. And as such I'm very satisfied with the result. It might look a
bit "scrambled" with some names but after all it's better than having
to call "Sonokawa" "Sonno" or something like that, right? And thus ends
this project history with the release of the 100% translation patch for
Kunio's Dodgeball. Enjoy it and be sure to let me know if you like it.
Oh, and if you actually read all the text in this section: Thanks for
listening.

(Additionally, there is something else that might better the quality
of the patch even more. This thing is a variable width font (VWF). If
I understand the way a VWF works right, it might be even better suited
for the displaying of names that are "too long" than my "DLE" approach.
Very unfortunately, I don't know much about VWFs yet and have about no
idea how to make or implement one. But I'll be on the lookout and if I
ever figure it out, I'll be sure to redo the names in Kunio's Dodgeball
using a VWF. Till then, sayounara.)

    �,.��=椺��`� �`�����=-Translation Notes-=椺��`� �`�����=��.,�

Not that much to say here, really. For the most part, this translation
stays true to the original. Of course, some modifications had to be
made. It's about impossible to translate a Japanese sentence meaning
"If you'd please select the enemy team you wish to compete against next"
*LITERALLY*. It just has to be shortened to something more readable
like "Select next opponent". Especially as we westerners simply are not
used to having such complex sentences in SPORTS games. And when did you
last read some polite phrase with "please" in a video game? I in fact
NEVER did apart from role-playing games. Anyway, what I wanted to say:
It would have been possible for me to expand the menu sentences to two
lines if I had wanted to, but I didn't do it because I really don't
think ANYBODY would like to have such monster sentences as the one in
the example above.

Apart from that, there's one one other translation issue: the names.
It's UTTERLY impossible to transcribe a name that uses up to SEVEN
letters in Japanese (Dakuon and Handakuon automatically get "attached"
to the respective letter in front of them) into a Roman name that can
use a maximum of FIVE letters. You just ()()�()/=)" can't write out
something like, let me think, "De La Torre" (te+dakuon+ra+to+ru+re).
Due to the DLE encoding I added to the rom, I *was* able to use more
than five letters, but especially those filled with Dakuten or
Handakuten couldn't be translated one to one as my DLE were somewhat
limited due to technical restraints. Perfect Example for this is the
aforementioned "De La Torre" who became "Torres". Wherever I had to
shorten or change names, I was most careful to use a name that could
be a native name of the nation in question. (Though sometimes I just
had to guess. Who the hell knows about native names in Kenya?)

Conclusion: Really nothing to worry about translation-wise. Though I'd
like to encourage anyone who thinks one or the other player name sounds
awkward to eMail me about it. Would be really cool if you also could
suggest a better sounding name in such a case.

         �,.��=椺��`� �`�����=-Credits-=椺��`� �`�����=��.,�

All Translations
				---Azel

All General Romhacking
				---Azel

Reprogramming, Menu Expansion
                                ---Azel

Some minor ASM modifications
                                ---Azel

Or, in other words:


Everything
                                ---Azel

      �,.��=椺��`� �`�����=-Special Thanks-=椺��`� �`�����=��.,�

DarkZero			-for helping me out with this *one*
				 sentence I couldn't translate all by
				 myself. Doumo arigatou.

Johnny Undaunted aka Godai-kun  -for writing the FAQ on 'Kunio's
                                 Dodgeball' which helped me immensely
                                 back when I barely knew Japanese at
                                 all. Long ago, I also considered
                                 asking him to be the translator of
                                 this game, but seeing that my own
                                 Japanese was more than sufficient to
                                 translate the game all alone when I
                                 actually GOT to translating it, that
                                 plan was given up. Still there
                                 probably are some references to his
                                 FAQ as I've gotten quite used to some
                                 of his terms over time. So I guess a
                                 tiny translation credit goes to him as
                                 well.

RomHackers Inc.                  -I've heard that they were the first
                                 to use those cool-looking ASCII header
                                 thingies I also use, so I guess it's
                                 better to thank them for creating it.
                                 Looks really cool, doesn't it?

    �,.��=椺��`� �`�����=-Acknowledgements-=椺��`� �`�����=��.,�

I'll try to keep this somewhat short, but as this is the very first
translation patch I ever published, I think it to be appropriate to
acknowledge all individuals or groups that had anything at all to do
with me getting interested in rom translations or helped me in one or
the other way. Don't worry though, I'll only do this once, here in this
very readme file. Later readmes will have more reasonably long text
files accompanying them. But back to topic. Note that there's
absolutely no special order in which the names are arranged. *Really*.

Demi                            -for everything he has done. Though I'm
                                especially grateful for the translation
                                of Radical Dreamers which is and will
                                always be one of my absolute favorite
                                games.

DarkForce                       -for his incredible technical knowledge
                                which allowed such high quality
                                translations as those of Final Fantasy
                                IV and Tales of Phantasia.

Tomato                          -for some magnificent translations. He
                                and his excellent abilities will surely
                                be missed.

akujin                          -yet another translator I can only
                                humbly look up to. Many a terrific
                                script was written by him.

Spinner 8                       -who cares if ZD sometimes is a bit
                                quicker with news about translations?
                                Nothing could ever compete with Spinner
                                and his great style of writing which
                                in my opinion is one of the things that
                                makes the Whirlpool the cool site that
                                it is.

InVerse                         -for his work at romhacking.com and the
                                many tutorials he has written. Back
                                when I found out about them, there
                                wasn't that much left I could still
                                learn from them, but his work is
                                appreciated nonetheless. Not to
                                mention all those cool translations he
                                made.

Gideon Zhi and AGTP             -there surely are few translation
                                groups that are as active AND deliver
                                such high quality translations as AGTP
                                does. Special thanks for Live A Live
                                and the joint effort of all people
                                involved.

Kitsune Sniper                  -not only has he released several cool
                                translations, he also is the one person
                                who added this patch to the Whirlpool.
                                Thanks, man.

toma/The Spoony Bard            -for several somewhat crazy, but cool
                                translations. Oh yeah, and for this
                                "font package" thingie I recently
                                discovered.
                                
SnowBro                         -for Hexposure and Tile Layer Pro which
                                are my two favorite romhacking tools.
                                This XORcyst thing looks also quite
                                interesting.

glenn rosenthal                 -for JWPCE, my personal preference in
                                Japanese word processors. Ain't bad as
                                well that it comes packed with a
                                Japanese dictionary. Really handy and
                                a lot quicker than looking up a word in
                                a printed dictionary.

Court Jester Z                  -for TaBuLar, the ultimate table tool.

Jay                             -for Romanji Search which just rocks.
                                And for TMOD2 which in my opinion is
                                the runner-up to Tile Layer Pro when it
                                comes to tile editors.

[J3d!]                          -for SearchR2 and all things he and
                                Dejap accomplished.

FuSoYa                          -for Lunar IPS as well as for Lunar
                                Expand and Lunar Expand. Damn, these
                                are powerful programs.

Magnus Runesson                 -for SMC-Ripper, which is not just very
                                functional but also looks *nice*. ;)

Bongo`                          -for Direct Hex 32. It's incredible how
                                many features he stuffed into this tiny
                                program.

snailrush                       -for PSicture. FINALLY a really decent
                                PlayStation graphics tool.

Linkin Park, Nightwish,         -for giving me countless amounts of
X-Japan, Silbermond,            inspiration, motivation and relaxation
Evanescence and the             during the work on this and many other
whole Final Fantasy VII         projects. Music definitely is one of
soundtrack                      the most valuable things in life.
                        
All emulator programmers        -'cause without them, rom translations
                                wouldn't even be able to exist.

All websites such as            -for not only being functional, but
the Whirlpool, rpgd or          also providing interesting facts and
romhacking.com                  things.

And finally:
Everyone who has ever           -well, for obvious reasons, I'd say.
contributed anything to
this whole rom translation
and romhacking thing, be it
patches, documents, web sites
or just plain encouragement
for others.

Hope that wasn't all too long ... ^^;

   �,.��=椺��`� �`�����=-Contact Information-=椺��`� �`�����=��.,�

...anybody who wants to praise my excellent work, comment on something
or even...criticise (*gasp*) anything, may do so by sending me an eMail
to my adress

Azel(at)otakumail(dot)com

...and don't even think about asking me for roms. I've got this nifty
SPAM filter and also, you REALLY wouldn't want me to be angry with you,
do you? Because in reply I might send you this incredibly *evil* virus
which automatically deletes all files on your hard disk ending with
.smc, .nes, .smd and so on... Not to mention it turns your brand new
Pentium V back into a lowly 286 PC. Hehe.
[Whoops, forgot the <sarcasm>-Tags yet again.]

But if you've got anything useful to contribute, feel free to eMail me.
It's always nice to know there are people who actually benefit from
your work. And maybe even appreciate it. Well, maybe...

Oh yeah, and if you've got the time, take a look at the official
Azelistic homepage located at

www.azelistic.net.tc

It will be updated - more like completely overhauled - pretty soon as
well.

       �,.��=椺��`� �`�����=-Tools used-=椺��`� �`�����=��.,�

-Hexposure 0.44b by Snowbro
My favourite hex editor. It's quite old and dos-only - but hey, I like
it anyway.

-ZSNES 1.36 by zsKnight, _Demo_, und pagefault
Do I even need to tell you something about THIS?

-Tile Layer Pro 1.1 by Snowbro
Fantastic tile editor. I still suck at doing graphics stuff, but thanks
to TLP my "art" doesn't look all that unpretty, right?

-Tabular 1.0 by Court Jester Z
Ah, creating tables cannot get any more comfortable than it is using
Tabular. Just one mouse click and poof, magically the whole alphabet is
inserted. And not just Roman letters (upper-case and lower-case) and 
numbers from 0 to 9 - also Romaji, Hiragana and Katakana. A really
excellent program.

-rsearch v1.0 beta by Jay
This neat program (which actually is called "Romanji Search") is a very
useful relative searcher. Quite as the name implies, it doesn't help
you to find "normal" letters, but rather parses romaji strings. As such
it is nearly perfect suited for helping one to find out the font table
of a Japanese game. Plus, it can be quite heavily customized (e.g. how
the Dakuten and Handakuten are supposed to be stored). I could praise
rsearch even more, but for the sake of functionality of this readme, I
will stop right here. Just get it, alright? ;)

-Modified SNES9x 1.37 by LordTech
I used it to definitely figure out that problem with the "second" font.
This program put in five words: "ASM" + "Tracer" + "Realtime" + "Log" =
"Yay."

-inSNESt v1.0 by RiGaMoRTiS PRoDuCTioNZ
A really useful all-around utility for SNES and SFC roms. Used to edit
the header and fix the checksum.

-Lunar IPS 1.00 by FuSoYa
This is what I call the best IPS program available today. As you might
have fathomed I used it to create the IPS. [D'oh.]

       �,.��=椺��`� �`�����=-Known issues-=椺��`� �`�����=��.,�

There are no real issues, but I need to warn you not to use savestates
and/or old saveram if you want to play this translated version. Due to
the fact that the game loads its "name font" directly from RAM and I
changed that font and the way it works, you CAN NOT load a game in
which the old font is still loaded into RAM as this will either majorly
screw up all names and display a mix of gibberish and both Roman and
Japanese letters or change nothing name-related at all. As savestates
ALWAYS contain the RAM and the saveram of course also contains vital
data such as names, you probably shouldn't use old data at all. I'm
really sorry about this but there was no way to work around this. But
hey, I also had a kick-ass team which I can't use any more, so...

   �,.��=椺��`� �`�����=-Patching Instructions-=椺��`� �`�����=��.,�

Just get the "good" rom that is usually called

Kunio Kun no Dodge Ball Zenin Syugo (J)

and use Lunar IPS, which can be found in the tools section of
www.azelistic.net.tc or simply at www.romhacking.com .
Using Lunar IPS, you simply click on "Apply Patch", then first select
the patch and finally the rom. It's simple, huh?

       �,.��=椺��`� �`�����=-Legal Notice-=椺��`� �`�����=��.,�

Kunio Kun no Dodgeball Zenin Syugo as well as all related images, names
and themes are trademarks of Technos Japan. [Which doesn't matter much
today anyhow as Technos went bankrupt a few years ago.]

Azelistic Translations is in no way affiliated with Technos Japan or
any other video game company.
Azelistic Translations claims no responsibility of any sort for any
kind of damage connected to the use of this patch or caused through
the use of the patch itself.

It is NOT allowed to distribute this patch together with or applied to
a rom.
But this readme file has to ALWAYS be part of the distribution archive.

   	�,.��=椺��`� �`�����=-Last Words-=椺��`� �`�����=��.,�

Yay, it is actually and finally DONE. Every single bit of text in
this game has been translated. Seeing as how I wrote every single
word of this translation - well, apart from that one DarkZero helped
me with - and how long this readme already is and that it's gotten
quite late at night yet again and I need to get up early tomorrow
morning, I guess I'll leave with what's here now.

The only thing that might still be done is the implementation of a
VWF, but don't expect this to happen anytime soon. Perhaps it will
not happen anytime ever, but as I said before, if I ever learn how
to deal with such a VWF, first thing I'll do is implement one in
this very game here. Aside from that, this translation is now
officially FINISHED. But let me conclude everything in a manner
worthy of this project.

All in all, this translation has turned out to be really good and I
wouldn't wanna miss the time in which I worked on it. Finally there's
a decent English version of the best dodgeball game ever. And to think
that I was the one who created it...

Ah, I'm getting sentimental, so I'd rather stop here and end this
readme with something intellectual:

What if you slept?
And what if, in your sleep, you dreamed?
And what if, in your dream, you went to heaven
and there plucked a strange and beautiful flower?
And what if, when you awoke, you had the flower in your hand?
Ah, what then?
(Samuel Taylor Coleridge)

-----------------------------------------------------------------------
� 2004 by Azel. All rights reserved.