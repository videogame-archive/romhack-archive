
---------------------------------------------------------------------------------------------------------

	Brave New World - Alternate Translation Patches
	-----------------------------------------------

These are optional dialogue patches that can be patched on top of (not in lieu of) Brave New World if so
desired. They can be freely applied to/removed from existing save files without needing to start over.

�Espanol Nuevo Mundo! and Italiano Nuovo Mondo are full Spanish and Italian translations, respectively.
If you are using the new game plus patch from the Unlockme, then apply the appropriate "ngplus" patch on
top of both it and the base translation patch thusly: BNW -> NG+ -> Translation -> Translation (NG+)

	(NOTE: �Espanol Nuevo Mundo! is not quite ready and will be released in about a week or so)

Clean New World censors all instances of adult/mature language in the hack, which should not be taken to
mean that Brave New World is otherwise full of such content. While early versions of Brave New World did
contain an admittedly gratuitous amount of foul language, we voluntarily dialed it down after analyzing
the script in its entirety (bearing in mind that it had been written in piecemeal fashion over a large
period of time) and agreeing with the negative reception that it had received. Released alongside that
revision was Clean New World, created not as a jab at our detractors but rather for an actual child as a
personal "thank you" to one of our earliest and most supportive fans.

The fan translation, also known as "Vanilla New World", was written in direct response to the frequent
request for a version of Brave New World with no dialogue edits. I declined to create it myself due to
both a lack of interest as well as the fact that it would be impossible given Brave New World's numerous
mechanical changes, but offered my full support to anyone who wished to take up the project themselves.
This patch thus does not restore the game's original script as the name would imply, but rather rewrites
every line that might be even remotely construed as referential in an extremely bland style reminiscent
of (and often indistinguishable from) the original Woolsey translation.

	-----------------------------------------------------------------------------------------

					CREDIT:

			      �Espanol Nuevo Mundo! - Umaro, Gens
			      Italiano Nuovo Mondo - Gens, Ryo_Hazuki
			      Vanilla New World - Deschain

---------------------------------------------------------------------------------------------------------

	I'm afraid that's all we know, gentlemen.