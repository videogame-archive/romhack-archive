
int get_next_token(char *in, char *out, int *pos);
int get_next_number(char *in, int *out, int *pos);
