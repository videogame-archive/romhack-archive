ROCKMAN & FORTE
ENGLISH TRANSLATION V1.00
Copyright 2002 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Rockman & Forte
2.Patch History
3.Patch Credits and Contributors
4.Known Issues With the Patch
5.Application Instructions

-----------------------
1.About Rockman & Forte
-----------------------
Rockman & Forte is, at least as of this writing, the
last "traditional" Megaman game (i.e. not a Megaman X
title, not a Battle Network title, etc.) Released for
the Super Famicom in 1999, well after the Super NES had
unfortunately passed on in the US, it has never seen an
official release in English. A few fan translation
efforts sprang up in the early years of romhacking, but
neither was exactly satisfactory - a number of graphics
remained untranslated in both patches, and the database
of 100 CDs, each of which featured sometimes-comical
information about old bosses and characters from other
Megaman titles, remained untouched. Until now!

You will notice that there are two patches contained in
this zip file: RMF-E.IPS and MMB-E.IPS. The RMF-E patch
uses the Japanese naming conventions (Rockman, Forte,
and so on) while the MMB-E patch uses the US naming
conventions (Megaman, Bass, etc.) Use whichever you're
more comfortable with, the text in each is exactly the
same.

---------------
2.Patch History
---------------
The Rockman and Forte project started on October 4, 2002.
Or close to there, anyway. The script dump was easy, an
ASM hack to eliminate the double-spacing that the Japanese
script used took all of ten minutes, the 16-bit dialogue
pointers were expanded to 24-bit in about an hour to allow
for as much text as I wanted, and a compression bypass
for the various graphics was rigged up quickly enough.

The script was handed to AndrewT, who did about 20 of the
database entries and disappeared. The script was then handed
to Ian Kelley, who did the entire thing in five days. Whee!
A few textual edits to make it sound less blocky and we were
good to go. Most of the time was spent waiting for satsu to
insert the graphics (which he -still- hasn't done all of, meh.)

There was much clawing and gnashing of teeth at the Stage Clear
and Game Over screens! Well, not really, but I just -had- to use
the "much gnashing of teeth" phrase. I should try to fit that
into one of my patches sometime! They were still a bit of a pain
though. Bloody sprite text!

December 18, 2002 - Initial version 1.00 Release
---------------
3.Patch Credits
---------------
THE ROCKMAN & FORTE TEAM

Main Team:
Gideon Zhi - Project leader, romhacker
Ian Kelley - Translation
satsu - Graphic hacking
Demi - Graphic design

Special Thanks go to AndrewT for his early effort with the script.

-----------------------------
4.Known Issues with the Patch
-----------------------------
-The title screens aren't 100% perfect. There's a little
discoloration around the corners due to lack of colors in the
palettes. If we can find a blank palette somewhere, this may get
fixed, but I wouldn't hold your breath. They're quite passable
though.

-The miniature title logos, after you select your character,
remain untouched. They're editable, but satsu hasn't had the
time to insert 'em yet. They're on-screen for all of five seconds
each time you start a game though, so it's a minor issue that I
believed should not have held up the patch.

-When browsing the CD database, you may notice some... shall
we say... unresponsiveness with the controller when ToadMan
is highlighted. This is unavoidable, unfortunately. Capcom did
a piss-poor job of coding that menu; it's quite possibly the
most inefficient heap of dung I've ever had the misfortune to
deal with. If you're interested in a technical explanation of
the problem, I'll be glad to answer you on my board, but that
aside, this is not something I can fix. Again though, it's a
very minor issue.

These patches have not been officially tested, although I did
go through each yesterday and double-checked each of the dialogue
sequences and the CD database, so it -should- be okay. If you
find a problem, though, please leave a screenshot in The Pantheon,
my forum (http://donut.parodius.com/agtp) along with an indication
of which patch you're playing (the RMF version or the MMB version.)
--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "rockman.swc" make sure the patch
is "rockman.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM DOES HAVE
a header. If you right-click the ROM and select Properties, it
should read "4.00 MB 4,194,816 bytes)". SNESTool can add any headers
for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
Please note that the questions it prompts you for apply to copier-users
only; if you are playing the game in an emulator, your answers do not
matter. All that matters is that the header is -there-. SNESTool will
tell you "Header add to file(s) done." and you'll be all set.