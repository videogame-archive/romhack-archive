#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys, os
sys.path.insert(0, "{}/../../common".format(os.path.dirname(os.path.realpath(__file__))))
from py_lib import codegen, codegen as cg, util, rom_reader
from py_lib import sfw, vwf, kerning, lzn
