package enums;

public enum PointerRangeType {
    
    NORMAL,
    COUNTER,
    MENU,
    FIXED_LENGTH
    
}
