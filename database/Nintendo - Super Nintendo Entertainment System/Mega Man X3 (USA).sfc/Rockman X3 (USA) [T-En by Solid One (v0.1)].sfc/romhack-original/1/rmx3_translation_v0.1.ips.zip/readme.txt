== ROCKMAN X3 - TRANSLATION ==

As the name suggests, this is a patch that "kinda" translates Rock Man X3 to english. However, unlike Her-Saki's Rock Man X translations that are indeed based on japanese versions, I'm doing everything on an expanded USA rom (thanks to Justin3009), with all texts moved to the end of the game, so I could do all needed script changes in the game.

The main idea of this project is to get Hondoori's translation for X3 and convert it into a playable ROM containing the translation, with the japanese terminology as well. Most dialogues were changed according to its translation, having only a few differences. It's an acknowledgment I'm giving to him for providing all Rock Man translations for the community.

Although I've already made all script changes and done most ingame testing, it's still marked as beta. Further tests need to be made before finally submitting it. Besides, a new VWF font will be added (courtesy of DarkSamus993), which will require more script changes. But besides that, everything should be working fine on the beta patch provided for now.

What's been changed:
- Title Screen restored to japanese version ("Rock Man" title screen by DarkSamus993);
- Mavericks renamed to their japanese names (thanks to DarkSamus993);
- Weapon names restored (Acid Burst -> Acid Rush, Gravity Well -> Bug Hole);
- All terminology restored to japanese (Reploid -> Repliroid, Maverick -> Irregular, etc);
- Entire COA localization changed with Hondoori's translation.

Change log
v0.1
- Initial beta release.

Format: ips

Target: "Mega Man X3 (USA)" NO-INTRO
CRC32: FA0FE671
SHA-1: B226F7EC59283B05C1E276E2F433893F45027CAC

Credits
Solid One: Hacking and in-game testing;
Hondoori: Original japanese translation;
Justin3009: Rom expansion for better dealing with game scripts;
DarkSamus993: Hacking related to the title screen restorement and Maverick name changes.
