CYBORG 009
ENGLISH TRANSLATION V1.00
Copyright 2004 Aeon Genesis
http://agtp.romhack.net
In Association with J2E Translations
http://www.j2e.org [Currently Down]

ToC

1.  About Cyborg 009
2.  Patch History
3.  Patch Credits and Contributors
4.  Known Issues
5.  Application Instructions

------------------
1.About Cyborg 009
------------------
Cyborg 009 is a game based on an old anime (the new
one had not been made when this game was released.)
Must've been a pretty popular anime to get a game made
about it 20 or 30 years later! The game is just so-so,
though -- play control kinda stinks, which can really
ruin it for a platformer.

---------------
2.Patch History
---------------
I was approached by Dark Force (of DeJap Translations)
one afternoon, and he'd said that he had a short-but-
probably-simple project that he'd gotten from J2E's
AnusP while he was still away somewhere in eastern Asia
and didn't have any real computer to do work on to speak
of. He gave me a table and some preliminary script dumps,
and after I produced more scripts in the space of a few
hours, he just gave the whole thing to me. After much
procrastination and lack-of-time-due-to-school, this is
the result of my work and Chip's work.

January 7, 2004 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE CYBORG 009 TEAM
Main Team:
Gideon Zhi - Project leader, Romhacker
AnusP - Initial project work; introduction and title screen

Translation:
Mariko Sadakane
Eiko Ishakawa
Reiko
Chip

Chip would like to greatly thank the other three translators; without
them, the translation would not have turned out so well.

Special Thanks:
Dark Force
Shih Tzu
satsu

--------------
4.Known Issues
--------------
--Please note that savestates do not function properly.
--Please also note that layering doesn't work entirely properly in ZSNES;
  a spotlight surrounding your character that should be visible isn't
  during missions where there are dark areas. For these segments,
  please either use SNES9X or take Francoise with you on the mission.

Otherwise,there are no known issues.

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "cyborg009.smc" make sure the patch
is "cyborg009.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
A HEADER!. If you right-click the ROM and select Properties, it
should read "Size: 1.00 MB (1,048,576 bytes)". SNESTool can remove
your headers for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
The answers to the questions it asks you do not matter unless you're
using a copier to play the game.

An easy way to tell if the game has a header or not is that if you do
the above and the game does not run, it probably has a header. Use
SNESTool to remove it. And don't whine about SNESTool not working in
Windows XP, it works fine for me and I'm running on XP Pro.