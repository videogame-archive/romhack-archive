Dragon Quest I+II Title Screen Fix v1.0
Programmed by mziab, http://mziab.grajpopolsku.pl
Released September 10th, 2012

This patch fixes the broken title screen in the DQ1 part of the
English translation by RPGOne, which could be experienced when
running the game on real hardware and accurate emulators.

Usage:
The patch should be applied to a rom pre-patched with the RPGOne English translation
version 2.0, WITHOUT a header (2,097,152 bytes). The archive contains BPS patches
for both the DW and DQ flavors of the translation, as well as an IPS patch which
fits both.

Disclaimer:
No bugs were revealed during my testing of the patch. However, if you happen to
notice any defects introduced by it, be sure to contact me per e-mail (mziab@o2.pl)
and I'll see what I can do.
