                                            Cyber Knight
                                           Addendum Patch
                                      v1.00 (November 23rd, 2022)

====================================================================================================

- Cyber Knight (c) Group SNE, Tonkin House. All rights reserved.

- No ownership is claimed by mziab over Cyber Knight. Commercial use of this patch, including
   but not limited to reproduction, sale, etc. is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   mziab is not liable for damage incurred to the end-user, their OS, or their
   hardware while using this patch.

- Apply this patch only to an unheadered Cyber Knight ROM pre-patched with the
   English translation v1.01 by Aeon Genesis with the following specifications.
     Hashes: CRC32 - EFA08411
               MD5 - 4DB4F8EDB9E66AF471D1AF2E1D3DB1C2
              SHA1 - E9C04204E82C395AAA2F6D512D80AF59EEC7FDA6

- Send error reports to mziab either by posting in the project thread on
   ROMhacking.net, or via the site's PM feature.


   Table of Contents

To reach a given section, Ctrl+F the text fragments in brackets.


Preface ............. [RM01]
Changelog ........... [RM02]
Text Changes ........ [RM03]
Easy Mode ........... [RM04]
Credits ............. [RM05]

====================================================================================================

   [RM01] Preface
   
  mziab

The purpose of this patch is to fix all known technical issues with the English translation by Aeon
Genesis and improve the presentation a bit. This is NOT a retranslation/rewrite or a complete
technical revamp, just some extra polish for a translation I thoroughly enjoyed. Most of the fixes
are carried over from the Polish translation I've released back in 2007, plus some more recent
additions, including the translated opening credits (for which I wrote a separate decompressor and
compressor!) and retranslated enemy names (with plenty obscure mythological references). And, as is
tradition at this point, I've also included an optional patch for reducing the grind. Enjoy!

====================================================================================================

   [RM02] Changelog

v1.00 (November 23rd, 2022)

- Translated the opening credits (using the Cyber Knight 2 font) and adjusted their display time

- Fixes all known text overflows and typos in the dialogue

- Retranslated a couple dialogue strings to make them closer to the original

- Retranslated enemy names to restore mythological references

- Renamed Captain Donyprof to the intended Dneprov (a real-life sci-fi writer)

- Expanded the options in the name entry screen (no more "Nxt" and "Bac")

- Fixed the alignment of the player name and Power stat in the Set Abilities screen

- Expanded the lab, bridge and medical bay menus, so that options fit in one line

- Full character names are displayed where possible (no more "Klei" and "Shin")

- Improved the character status screen:

    - Renamed IQ stat to Int

    - Renamed Quik to Speed

    - Expanded skill names

    - Expanded character classes (no more "Scientis" and "Commandr")

    - Moved some stats around for a more symmetrical look

- Fixed part of Nehjena's name which mistakenly appeared in the middle of Shine's stats

- Expanded the Short Jump Menu, so that planet and system names display in full

- Expanded the Long Jump menu, so that "Worldring" displays in full

- Fixed some enemy names appearing blank in battle messages (e.g. Arachnsaur)

- Fixed truncated names in Neoparts analysis messages

- Expanded the Neoparts menu in the lab, so that enemy names aren't truncated

- Fixed the broken description for Gamma Laser in Arms menu

- Expanded some location names

- Cosmetic fixes to various other menus

====================================================================================================

    [RM03] Text Changes

Most enemy names in Cyber Knight are in fact references to mythological creatures, some more obscure
than others. In case you're using an old walkthrough, here is a list of old and new names for
reference:

Blopp       Blob
Catoblepa   Catoblepas
Chaugner    Chaugnar
Chupon      Typhon
Clulahorn   Clurichaun
Dymozaurus  Dymosaurus
Fargolta    Fear Gorta
Farjalg     Far Darrig
Fifinela    Fifinella
Gandalva    Gandharva
Ganosaur    Gatanothoa
Guncanner   Gancanagh
Jabbawock   Jabberwock
Jugganaut   Jagannatha
LiananSea   Leananshee
Mellow      Merrow
NightGant   Nightgaunt
R. Raver    R. Laborer
Replahorn   Leprechaun
Sea Orc     Sheoques
Seamonk     Sea Monk
Selki       Selkie
Siliconny   Silicony
Spangle     Spandule
Tashblom    Tatzelwurm
Yuwocky     Youwarkee
Zaradan     Zaratan

As for the dialogue, only a handful of lines have been tweak. As stated before, this was never
intended to be a full-blown retranslation or rewrite.  The dialogue changes are just what caught my
eye while tinkering with the game, the most notable among which are:
- changing the spelling of Captain Donyprof's name to Dneprov (a real-life sci-fi writer)
- renaming the G-Wave Corresponder to G-Wave Communicator to make it in line with its menu name

====================================================================================================

   [RM04] Easy Mode

This release also includes an optional patch to reduce the grind.  It halves the random encounter
rate, while doubling the EXP. The patch should work with any version of the game, but was only
tested with the English one. Also, please keep in mind that fewer battles mean less opportunity to
get new Neoparts.

====================================================================================================

   [RM05] Credits

- mziab: Tools, reprogramming

- Rankin: Testing

Special thanks to Aeon Genesis for translating this little gem back in 2001!
