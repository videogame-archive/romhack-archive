Donkey Kong Country 2 - Diddy's Kong Quest MSU-1
Version 1.0
by Mattrizzle

This hack enables the MSU-1 chip audio capabilities to Donkey Kong Country 2.

Follow the instructions bellow to set up the patch. 

Do note that only higan requires BML manifest files, if using standalone bsnes emulators, be aware that
XML files are outdated, and no longer serves any purpose.

Fortunaly, latest bsnes-plus builds dropped this requirement, check the Recommended Tools section for it!

Concerning performance issues, if you're having difficulty using higan, try the nSide fork by hex_usr,
it offers the Balanced profile to suppress a few accuracy demands to speed up the emulator frame-rate.

For compability with old higan manifest versions (v092-v095), see Recommended Tools section.

Music Pack:
https://drive.google.com/drive/folders/12n2W0Tgrv61qVE6mDH_REOPOiR72yT1u?usp=sharing

===================
= ROM Information =
===================

There are 2 versions of the patch, one for DKC2 v1.0 and another for DKC2 v1.1 (courtesy of Conn), differences
between these revisions are only relevant to the speedrunning community, so don't worry, whichever you get in
hands, just make sure to apply the correct version (FLIPS will tell you if you're patching the wrong one).

|-----------------------|--------------------------------------------------------------------------------------|
|Name, Size (v1.0)	| Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr).sfc | 4194304 Bytes	       |
|-----------------------|--------------------------------------------------------------------------------------|
|SHA-256 		| 35421a9af9dd011b40b91f792192af9f99c93201d8d394026bdfb42cbf2d8633		       |
|-----------------------|--------------------------------------------------------------------------------------|
|-----------------------|--------------------------------------------------------------------------------------|
|Name, Size (v1.1)	| Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr) (Rev 1).sfc | 4194304 Bytes |
|-----------------------|--------------------------------------------------------------------------------------|
|SHA-256 		| b79c2bb86f6fc76e1fc61c62fc16d51c664c381e58bc2933be643bbc4d8b610c		       |
|-----------------------|--------------------------------------------------------------------------------------|

===============
= Preparation =
===============

1. Copy the complete gamepak folder "Donkey Kong Country 2 - Diddy's Kong Quest v1.x (MSU-1).sfc" to your HDD

2. Have a fresh headerless US version of DKC2 and copy it inside the gamepak folder (beware your ROM revision)

3. Use flips.exe (see below "Recommended Tools") to apply dkc2_msu1.bps on your DKC2 ROM. The patched ROM must be named: dkc2_msu1.sfc

(4. Additionally, naming your fresh headerless ROM exactly as the patch (dkc2_msu1.sfc) will make emulators apply the patch automatically for you)

5. Unzip the .pcm pack inside the gamepak folder ("Donkey Kong Country 2 - Diddy's Kong Quest v1.x (MSU-1).sfc" IS a folder, don't mistake it)

==================
= Using on higan =
==================

6. Move the gamepak folder to your Super Famicom games location (see Advanced tab on higan to see where it is)

7. Load the Super Famicom game on higan (Library -> Nintendo -> Super Famicom)

=================================
= Using on bsnes/SD2SNES/Snes9x =
=================================

6. Launch the folder using bsnes or load "dkc2_msu1.sfc" through SD2SNES/Snes9x

===========
= Credits =
===========

* Mattrizzle - ASM hacking and coding;
* Conn - Patch compability with v1.1 revision;
* emuandco, NTI Productions - Music pack and edition.

=====================
= Recommended Tools =
=====================

Patching: Floating IPS
http://www.smwcentral.net/?p=section&a=details&id=10347

Emulators: higan, nSide
https://byuu.org/emulation/higan/
https://github.com/hex-usr/nSide/releases

Debugging: bsnes-plus
http://www.emucr.com/search/label/bsnes-plus?&max-results=16

Manifest Conversion: Olympian Magic
https://board.byuu.org/viewtopic.php?f=4&t=1977