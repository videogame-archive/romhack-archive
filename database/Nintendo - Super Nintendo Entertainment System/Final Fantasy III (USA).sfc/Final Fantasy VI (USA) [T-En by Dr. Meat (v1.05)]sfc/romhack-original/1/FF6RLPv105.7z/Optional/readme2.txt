Esper Balance Patch
by your pal Alex (@drmeat64 on Twitter)
___________________

Apply this patch to the same ROM you applied the main patch to.
Apply it AFTER you have already applied the main FF6 RLP patch.
Once again it comes in headered and unheadered flavors.
Please refer to the main readme.txt for patching instructions!


What This Does
___________________

When you level up with an Esper equipped in FFVI, you get a stat boost as shown
on the Esper equip/info screen. However the way these bonuses are distributed
across the game's Espers seems arbitrary and unbalanced.

This patch reassigns these level bonuses. Espers now all have a bonus, but the
distribution of "good" bonuses (such as +2 stat increases) are weighted toward
the Espers acquired in the final half of the game. You won't be able to train
Strength and Magic up quite as hard in the first half but you will always be
getting some kind of small bonus.

Espers also now have bonuses which are related to the kind of Esper they are,
which was not always the case in the original game. You will also no longer
lose out permanently on Speed +1.... you might lose something else that is
useful, though. You will probably be slightly more weak overall in terms of 
Strength and Magic, but your HP and MP should end up a bit higher.

I think this simple gameplay change makes FFVI a slightly more interesting
experience, small though the changes may be. Hope you enjoy this little tweak!







Below are the actual changes to Espers, which I moved down in the document in
case you don't care to be "spoiled" or something.











The Changes
___________________

These are the specific changes to the Espers.

ESPER			ORIGINAL BONUS		NEW BONUS

Ramuh			Stamina +1			Stamina +1
Kirin			-					MP +10%
Siren			HP +10%				HP +10%
Cait Sith		Magic +1			Magic +1
Ifrit			Strength +1			Strength +1
Shiva			-					MP +10%
Unicorn			-					HP +10%
Maduin			Magic +1			Magic +1
Catoblepas		HP +10%				HP +10%
Phantom			MP +10%				MP +10%
Carbuncle		-					HP +10%
Bismarck		Strength +2			Strength +1
Golem			Stamina +2			Stamina +1
Zona Seeker		Magic +2			Magic +1
Seraph			-					MP +10%

Quetzalli		-					HP +30%
Fenrir			MP +30%				MP +30%
Valigarmanda	Magic +2			Magic +2
Midgardsormr	HP +30%				HP +30%
Lakshmi			Stamina +2			MP +30%
Alexander		-					Strength +2
Phoenix			-					Magic +2
Ragnarok		-					Stamina +2
Odin			Speed +1			Strength +2
Bahamut			HP +50%				HP +50%
Crusader		MP +50%				MP +50%
Raiden			Strength +2			Speed +1