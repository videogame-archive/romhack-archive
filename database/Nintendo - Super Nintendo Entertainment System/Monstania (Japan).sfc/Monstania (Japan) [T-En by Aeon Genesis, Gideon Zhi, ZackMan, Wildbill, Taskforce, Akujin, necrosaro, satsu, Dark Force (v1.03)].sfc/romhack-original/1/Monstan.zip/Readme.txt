PROJECT MONSTANIA
ENGLISH TRANSLATION V1.03
Copyright 2000-2001 by Aeon Genesis and CTC
http://agtp.romhack.net
http://ctc.weyland-yutani.net
http://www.ctc-lennus.org

ToC

1.About Monstania
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions
6.Mini-FAQ

-----------------
1.About Monstania
-----------------
Monstania is a strategy-RPG whose combat system plays much like old BBS
door games like Rogue, Moria, or Nethack (www.nethack.org). It was
published in 1996 by Pack-In-Video. It is also a fairly short game,
weighing in at about 6 hours if you take your time. That says little
about the size of the script, which at current time stands at about
90 kilobytes of pure text. And that's just the dialogue!

---------------
2.Patch History
---------------
Project Monstania started in May of 2000, and progressed quickly
towards the final goal. There were slow points during which we didn't
have the kanji for the project and didn't have a really good inserter
for the project. Once those two hurdles were overcome, we worked hard
towards a finished project.

November 8th, 2000 - Initial v1.00 release.

November 10th, 2000 - v1.01 release.
- Minor grammar error fixed.
- Some window errors fixed.
- A few minor changes to the readme.

November 11th, 2000 - v1.02 release.
- A couple of double words fixed.
- Some graphical icky thingies fixed.
- Hopefully the final version >_< I hate having to release bugfixes :(

May 28th, 2001 - v1.03 release.
- Changed patch to support the new, 2.5 megabyte/20 megabit dump.
- Fixed romname.

---------------
3.Patch Credits
---------------
Gideon Zhi - Project leader, lead romhacker
ZackMan - Translator
Wildbill - Scriptwriter
Taskforce - Insertion Utility coder
akujin - Kanji, decipherer of the "slanguage".
Necrosaro - assembly-level aid
satsu - kanji into table for j-text-support-deprived-at-the-time me.
Dark Force - Provided my font :)
Neil_ - Found an original cart and dumped a properly-sized ROM.

--------------
4.Known Issues
--------------
-There's a problem with the delete function on the name screen. KLin
tried to give Barambat the name "Bildo" but it wouldn't fit. So he hit
the backspace button a bunch of times and it ended up displaying as
"bildaaaat". o_O

-There's a problem with the controls locking up during the very very
last mission. It's passable, though, and it doesn't always happen...

-After dying, there's apparently some glitches if you try to "Reload"
from an empty save slot o_O

-Some copier users have experienced graphical glitches on the highways.

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "monstan.smc" make sure the patch
is "monstan.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM!

----------
6.Mini-FAQ
----------

Here's an excerpt from a FAQ I started writing and probably will never
finish. It'll walk you through the first three or four battles in the
game, then you're on your own. Good luck!

--------------
Game Mechanics
--------------
Note that I'm using the default configuration... the other one
(Move Press Mode or something) just sucks. So here's how to play.

UP-Arrow: Walk forward.
LEFT/RIGHT: Turn 90 degrees.
DOWN-Arrow: Walk backwards.
A-Button: Attack/accept.
B-Button: Cancel.
Y-Button: Stand still.
X-Button: Skills menu.
L/R-Button: Change character.

In combat, you can recharge your AP by standing still or letting your
partner move. Special skills drain your AP. Attacking, moving, using
a skill, and standing still use up a turn. That about covers it, I
think.

---------------------
Chapter 1
Forest Meeting
  Objective: Elminiate the Kobolds!
---------------------
TIPS
--Use your special skills.
--Pay attention to the messages that appear!

How to Win

This is a really easy fight. If you can't kill two Kobolds, you REALLY
need help. So walk forward until you're next to the rock on the left,
and wait until the kobold is a chess Knight's fork away from you,
between you and Tia. Then move forward a square, and start hacking
away. Worst comes to worst, you'll be at about 10 health after it dies.
Keep in mind that this is absolute worst case! When it dies, another
one shows up. At this point, go ahead and use your Recover skill (it
costs 5 points.) Then wait until the kobold is within the range of
Fron's sword, and start hacking away again. Congrats, you just won the
first chapter. If you consulted this FAQ because you "just couldn't
win!" then I suggest putting Monstania away and digging out Final
Fantasy: Mystic Quest. At your level, it should take you about 40
hours. Now go play FF2 and 3, a little bit of Ogre Battle, Final
Fantasy Tactics, and Tactics Ogre (maybe even Kartia) and THEN maybe
you'll see how easy Monstania really is. (In other words, seek
professional help, immediately!)

WINNINGS:
Fron gains a level and learns Sonic Boom.

-------------------------------
Chapter 2
Highway
  Objective: Clear those slimes
  out of the roadway!
-------------------------------
TIPS
--Tia's bow attack is long range.
--You get 2 moves for the slimes' 1.

How to Win

Simple, really. Use Tia's bow attack. If the slimes get too close (in
other words, if there's one square between you and a slime, and it
didn't move last turn) then move away from it. Take your time, peg 'em
from a distance, and you should do fine. This goes for the huge slime
boss thing, too. See if you can get him to run around in circles in a
corner, it's fun! :)

-----------------------------
Chapter 3
Riddle of the Stone Tiles
  Solve the stone tile riddle
  and open the cave!
-----------------------------
PUZZLE TIPS
--You need both Fron and Tia to finish the puzzle.

How to Solve the Puzzle:
Place Fron on the -> most square, and Tia on the <- most square.
Then have Tia examine the door.

BATTLE TIPS
--Protect Tia!!
--Try to find a spot where you only have to fight one Kobold at a time.

How to Win
Once the battle starts, move Fron two spaces towards the kobolds.
Then just wait. You should be able to take them out one at a time,
barring a large number of misses, etc. Heal when you need to. If you
miss too many times, you may get tripleteamed. If that happens, you'll
probably lose, and will have to retry the whole thing. No biggie. Once
Tia opens the door, move to the square in front of the door to end
the battle.