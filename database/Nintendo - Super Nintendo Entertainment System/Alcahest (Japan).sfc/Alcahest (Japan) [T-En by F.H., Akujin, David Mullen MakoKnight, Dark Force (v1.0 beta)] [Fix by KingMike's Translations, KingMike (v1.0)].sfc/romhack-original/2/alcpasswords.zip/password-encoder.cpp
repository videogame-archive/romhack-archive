#include <iostream>
#include <cstring>
#include <cstdlib>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

FILE* PasswordKey;
FILE* ROM;

struct RepeatStrings
{
	char text[32];
	unsigned long int StringPointer, StringOffset;
};

int main(int argc, char** argv) {
	unsigned long int FirstPartPointers = 0x61322, FirstPartText = 0x112960;
	unsigned long int SecondPartPointers = 0x614BB, SecondPartText = 0x112B60;
	unsigned long int LastPartPointers = 0x61521, LastPartText = 0x112C60;
	unsigned long int InputAddress = 0, InputSize;
	unsigned char PasswordID = 0;
	char ROMFilename[100];
	char PasswordFilename[100]="pass-trans.sjs";
	char InputString[16];
	unsigned short int readword;
	unsigned char StringIndex, readbyte;
	printf("Alcahest Password encoder\nInput Alcahest ROM file name:");
	int x=0;
    readbyte=0;
    while(readbyte!='\n')
    {
        readbyte=std::cin.get();
        ROMFilename[x++]=readbyte;
    }
    ROMFilename[x-1]='\0';
    printf("Enter password list filename:");
    x=0;
    readbyte=0;
    while(readbyte!='\n')
    {
        readbyte=std::cin.get();
        PasswordFilename[x++]=readbyte;
    }
    PasswordFilename[x-1]='\0';
    if(ROMFilename==NULL)
    {
        printf("Couldn't fild the file %s\n",ROMFilename);
        system("PAUSE");
        return EXIT_FAILURE;
    }
    PasswordKey=fopen(PasswordFilename,"rb+");
    if(PasswordKey==NULL)
    {
        printf("Couldn't fild the file %s\n",PasswordFilename);
        system("PAUSE");
        return EXIT_FAILURE;
    }
	RepeatStrings Repeats[40];
	unsigned char NumberOfRepeats=0;
	char SearchingMidString, StringFound;
	ROM=fopen(ROMFilename,"rb+");
	fseek(PasswordKey,0,SEEK_END); InputSize=ftell(PasswordKey);
	printf("Output size is %04X",InputSize);
	while(InputAddress<InputSize)
	{
		fseek(PasswordKey,InputAddress,SEEK_SET); readword = fgetc(PasswordKey); InputAddress++;
		if(readword>=0x80)	//Shift-JIS character, skip to end of line
		{
			readword=(readword*0x100)+fgetc(PasswordKey);
			while(readword!=0x0D && readword!=0x0A && InputAddress<InputSize)
			{
				InputAddress++;		//confirmed ShiftJIS
				readword=fgetc(PasswordKey);
				if(readword>=0x80)
				{
					readword=(readword*0x100)+fgetc(PasswordKey);
					InputAddress++;
				}
			
			}
			while(readword==0x0D || readword==0x0A)
			{
				readword=fgetc(PasswordKey); InputAddress++;
			}
		}
		else
		{
			//get the first part of the password
			StringIndex = 0;
			while(readword!='|' && InputAddress<InputSize)
			{
				InputString[StringIndex]=readword; StringIndex++; InputAddress++;
				readword=fgetc(PasswordKey);
			}
			InputString[StringIndex]='\0';
			fseek(ROM,FirstPartText,SEEK_SET); fprintf(ROM,"%s",InputString); fputc((char)0,ROM);
			fseek(ROM,FirstPartPointers,SEEK_SET); fputc((unsigned char)(FirstPartText&0xFF),ROM); fputc((unsigned char)((FirstPartText>>8)|0x80),ROM); FirstPartPointers+=2;
			FirstPartText+=(strlen(InputString)+1);
			if(PasswordID>6)
			{
				SearchingMidString = 1;
				//first 3 stages don't have a middle part of the password
				while(SearchingMidString==1)
				{
					fseek(PasswordKey,InputAddress,SEEK_SET); readword = fgetc(PasswordKey); InputAddress++;
					StringIndex=0;
					while(readword!='|' && readword!='/' && InputAddress<InputSize)
					{
						InputString[StringIndex]=readword; StringIndex++; InputAddress++;
						readword=fgetc(PasswordKey);
					}
					InputString[StringIndex]='\0';
					StringFound=0;
					for(int x=0; x<NumberOfRepeats; x++)
					{
						if(strcmp(InputString,Repeats[x].text)==0)
						{
							StringFound=1;
						}
					}
					if(StringFound==0)	//new mid string
					{
						strcpy(Repeats[NumberOfRepeats].text,InputString);
						NumberOfRepeats++;
					}
					if(readword=='|')
					   SearchingMidString=0;
				}
				
			}
			//now do the last part of the password
			StringIndex=0;
			fseek(PasswordKey,InputAddress,SEEK_SET);
			readword=fgetc(PasswordKey);
			while(readword!=0x0D && readword!=0x0A && InputAddress<InputSize)
			{
				InputString[StringIndex]=readword; InputAddress++; StringIndex++;
				readword=fgetc(PasswordKey);
			}
			InputString[StringIndex]='\0';
			fseek(ROM,LastPartText,SEEK_SET); fprintf(ROM,"%s",InputString); fputc((char)0,ROM);
			fseek(ROM,LastPartPointers,SEEK_SET); fputc((unsigned char)(LastPartText&0xFF),ROM); fputc((unsigned char)((LastPartText>>8)|0x80),ROM); LastPartPointers+=2;
			LastPartText+=(strlen(InputString)+1);
			if(InputAddress<InputSize)
			{
				while((readword==0x0D || readword==0x0A) && InputAddress<InputSize)
				{
					readword=fgetc(PasswordKey); InputAddress++;
				}
			}
			PasswordID++;
		}
	}
	for(int x=0;x<NumberOfRepeats;x++)
	{
		fseek(ROM,SecondPartText,SEEK_SET); fprintf(ROM,"%s",Repeats[x].text); fputc((char)0,ROM);
		fseek(ROM,SecondPartPointers,SEEK_SET); fputc((unsigned char)(SecondPartText&0xFF),ROM); fputc((unsigned char)((SecondPartText>>8)|0x80),ROM); SecondPartPointers+=2;
		SecondPartText+=(strlen(InputString)+1);
	}
	system("PAUSE");
	return 0;
}
