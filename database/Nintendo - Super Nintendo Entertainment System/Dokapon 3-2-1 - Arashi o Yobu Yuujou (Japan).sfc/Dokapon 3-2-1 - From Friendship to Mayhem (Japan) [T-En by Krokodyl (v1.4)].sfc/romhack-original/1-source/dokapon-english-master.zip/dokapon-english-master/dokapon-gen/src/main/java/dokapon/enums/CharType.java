package dokapon.enums;

public enum CharType {

    SINGLE,
    DOUBLE_STRAIGHT,
    DOUBLE_SLANTED,
    NO_SPRITE

}
