

  WHAT THIS IS
______________________________________________________________________

This is a bugfix collection for
Star Fox 2 English translation v1.0 by Aeon Genesis (AGTP).

These bugfixes are (c) 2008-2010 by ManuL�we.

http://www.manuloewe.de/kayeneng.htm
______________________________________________________________________


  DISCLAIMER
______________________________________________________________________

All trademarks mentioned in this readme file are the property of their
respective owners.

This software is freeware. It is provided "as is" and without express
or implied warranty of any kind. ManuL�we will not be held liable or
responsible for any losses, damages, injuries, and/or legal
consequences due to the misuse and/or illegal use of any of the files
contained within this archive. 

The following files are contained within this archive:

  agtp_starfox2v1.0_debriefing_by_manuloewe.ips
  agtp_starfox2v1.0_menufix_by_manuloewe.ips
  agtp_starfox2v1.0_staffroll_by_manuloewe.ips
  sf2_bugfixes_readme.txt

The archive may be distributed freely under the circumstance that no
file(s) is/are added or removed.

ManuL�we is not affiliated in any way with Aeon Genesis (AGTP) or Nin-
tendo.
______________________________________________________________________


  INTRODUCTION
______________________________________________________________________

If you don't know Star Fox 2, read Evan Gowan's excellent article on
this fantastic, although never released, Super Nintendo game:
http://www.snescentral.com/article.php?id=0077

All of my patches are intended to be used in conjunction with AGTP's
English v1.0 translation of the game (released on October 17th, 2004).
Go here if you don't already have it:
http://agtp.romhack.net/project.php?id=starfox2

Pre-patch your ROM with the translation and make sure it works. Then,
you're all set to apply one or more of my bugfix patches. Be sure to
check out the information further below about the bugs present in the
translation and the fixes I provide. Have fun! :-)

Oh yeah, the order in which you apply any two or more of my patches
shouldn't really matter because they all affect distinct regions of
the ROM. Only thing you have to make sure is that your translated ROM
does NOT have a header.
______________________________________________________________________


  1. DEBRIEFING FIX (applies to: "debug" & "final" versions)
______________________________________________________________________

agtp_starfox2v1.0_debriefing_by_manuloewe.ips will correct the
spelling of one of the graphical text strings on the records screen
(from "DEBREIFING" to "DEBRIEFING").

You can use this patch with the "debug" and/or with the "final" ver-
sion of AGTP's patches as both are affected.
______________________________________________________________________


  2. MENU FIX (applies to: "final" version only)
______________________________________________________________________

agtp_starfox2v1.0_menufix_by_manuloewe.ips will correct a bug in the
main menu. Note that this bug only affects the "final" version of
AGTP's translation!

To see the bug in effect, start the "final" version of the translated
game, go to the main menu, select "MISSION" and press B. When the
difficulty selection menu appears, press Y. You will be taken back to
the main menu. Now, press Up or Down on the Control pad several times.
You'll be able to blindly select the test, training, and config menu
items, which shouldn't actually be available in the "final" version of
the translation.

Make sure ONLY to use this patch with the "final" version of AGTP's
patches. If used with the "debug" version, it'll no longer let you
select the test, training, and config options in the main menu!
______________________________________________________________________


  3. STAFF ROLL FIX (applies to: "debug" & "final" versions)
______________________________________________________________________

agtp_starfox2v1.0_staffroll_by_manuloewe.ips will correct the color of
the very first line of the staff roll sequence. It says, "EXECUTING
SECURITY CROSS CHECK." In the "debug" version of the translation, the
line is actually visible (albeit in the wrong color), but in the
"final" version, it was accidentally blacked out completely, resul-
ting in no more than a green cursor flickering across the bottom of
an otherwise black screen. This patch restores the color the line is
displayed in to its original shade of light gray.

You can use this patch with the "debug" and/or with the "final" ver-
sion of AGTP's patches as both are affected.
______________________________________________________________________


  HOW TO USE IPS FILES
______________________________________________________________________

Read your emulator's manual to check whether it supports real-time
patching. Or, find and download Lunar IPS by FuSoYa. It's pretty self-
explanatory and easy to use.
______________________________________________________________________


  QUESTIONS, COMMENTS ...
______________________________________________________________________

... will be ignored. (Sorry.)
______________________________________________________________________


  THANKS
______________________________________________________________________

- d4s and Gideon Zhi for their marvellous work on a marvellous game.
- Matthew Callis for the Star Fox 2 Font Tools.
- FuSoYa for Lunar Compress.
______________________________________________________________________
