KYUUYAKU MEGAMI TENSEI II - CATHEDRAL OF DARKNESS 0.4

This is a modification made for the Megami Tensei II half of Kyuuyaku Megami Tensei. It drastically changes the results of double fusions, allowing the player to fuse EVIL demons which are normally not available. The majority of demons in the game are EVIL, and most GOOD demons can still be obtained, so the player has more options than before.

To match these changes, some pieces of text have been changed, particularly the fusion expert in the hotel in Haneda, who also provides one of the more obscure and helpful recipes added by this hack.

The fusion routine in KMT2 is very short and simple, so I was unable to get everything I wanted -- in particular, fusing Elements is somewhat challenging and Tyrants, which are too high level to ever fuse, sometimes show up in the results. Overall, though, the player ends up with more arms. Think of this as a fusion scramble hack, if that helps.

Note that you will need the demons Element Gnome and Element Undine to continue the game during its second half. Fuse them if you can; they should still be possible to obtain by fusing together multiple Genma with triple fusion.

INSTALLATION: This is a simple .ips patch generated with RHDN's creator mode tools. It should be easy to apply. It is designed for the English language patched version of the game.