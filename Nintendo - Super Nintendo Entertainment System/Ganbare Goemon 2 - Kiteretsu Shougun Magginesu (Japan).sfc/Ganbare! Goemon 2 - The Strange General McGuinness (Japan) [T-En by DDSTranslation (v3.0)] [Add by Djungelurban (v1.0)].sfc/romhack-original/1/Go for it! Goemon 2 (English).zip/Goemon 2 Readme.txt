Go for it!

Goemon 2:
The Strange General McGuinness

Translation Patch (Version Three)


Version Three
  - Minor edit to a boss dialogue.

Version Two
  - Fixed the pixelated clouds in Area 6's town when exiting the Gambling Den.
  - Sped up the text display speeds and synced mouth movement to it.
  - Tuned a couple of the timings of the cutscenes.
  - Fixed bug for Virtual Console players when displaying the high scores for Wage Winners.
  - Updated some NPC dialogues.

-----------------------
  GENERAL INFORMATION
-----------------------

This patch is for Goemon 2 on the Super Famicom.
The text has been translated from Japanese into American English.

Two patching formats are provided, so you can use either .bps or .ips.
(Do not apply both patches.)


-----------
  CREDITS
-----------


Hacking and testing:
DDSTranslation

Translation:
Tom

Graphics:
FlashPV