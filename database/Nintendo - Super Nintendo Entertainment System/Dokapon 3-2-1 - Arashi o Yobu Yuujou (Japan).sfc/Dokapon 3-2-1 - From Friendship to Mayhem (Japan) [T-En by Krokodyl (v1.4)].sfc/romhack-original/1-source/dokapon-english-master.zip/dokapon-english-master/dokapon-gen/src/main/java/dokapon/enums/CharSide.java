package dokapon.enums;

public enum CharSide {

    ONE,
    TWO
}
