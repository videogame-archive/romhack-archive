STARFOX 2
ENGLISH TRANSLATION V1.00
Copyright 2004 Aeon Genesis
http://agtp.romhack.net
aeongen@gmail.com

ToC

0.Game Issues
1.About Starfox 2
2.Patch History
3.Patch Credits and Contributors
4.About the Two Patches
5.Known Issues
6.Application Instructions
7.Troubleshooting

-------------
0.Game Issues
-------------
*IMPORTANT*
1) As of this writing (3:30 PM EST October 17) I don't think ZSNES
supports Starfox 2. I'm not sure SNES9X does either. I know it works
in SNES9X 1.41-1, though, so you may have to use that for now.
Although I'm aware of work on a new WIP at this moment, and it
will hopefully be out in the next few days, if not the next few
hours. Keep an eye out.

2) There are five or six different roms floating around. This will
work on the "best" rom, which isn't in goodsnes, and the two roms
that goodsnes lists as "Beta TD" and "J o1". Neither should have a
header -- if the you patch the game and it crashes (and it didn't
crash unpatched), use SNESTool or something similar to remove the
header.

-----------
1.Starfox 2
-----------
Ah, the prototype to end all prototypes. No, Star Fox 2 was never
officially released. I will not go into how the game found its way
onto the internet, as that is not my place. I will say that it's a
helluvalotta fun! At the beginning, you're presented with a map of
the Lylat system, with a few different things happening on it
depending on which difficulty level you select. As soon as you
move your chosen pilots to a different place on the map, things
start happening and will continue to happen until you either
A) change pilots by pressing select, or B) complete a level.
Things will even continue to happen while you're battling through
a battleship, planet, missile salvo, boss, or fighter squadron.
Don't let things get too close to Corneria, though -- if the planet
takes too much damage, it's game over!

Another really cool thing that the game does is add incentives for
playing the higher difficulty levels. The normal mode seems kind of
cool at first, but it gets old pretty quickly. Kick the difficulty
up to "Hard" and you have more planets to rescue, more battleships
to destroy, more enemies and bosses flying around the map. And by
the way, the battleship and planet levels' layouts have changed!
It's really something else. The same things happen when you kick
it up to "Expert" -- even more new and changed things.

If that weren't enough, there are huge General Pepper coins strewn
throughout each difficulty level. Each one only appears once -- after
you pick it up, it will not appear in future playthroughs. I'm
unsure of the function of these, other than to fully heal you when
you find one, but I've yet to find them all.

---------------
2.Patch History
---------------
I don't even remember how long this thing took. It was full of stalls
and standstills as various bits of the game were picked apart, piece
by piece, but thanks to the hacking prowess of myself and d4s, the
compression knowledge of Fusoya, and satsu's translation skills, the
final product looks very, very nice.

October 17, 2004 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE STARFOX 2 TEAM
Main Team:
Gideon Zhi - Project leader, Romhacker
d4s - Romhacker, German version
Fusoya - Compression guru
satsu - Script translation

Special thanks to...
...the unnamed person who helped with the font
...Kitsune Sniper for help with a couple of graphics

-----------------------
4.About the Two Patches
-----------------------
Bundled in this zip are two different patches: "sf2-e-debug.ips" and
"sf2-e-final.ips".

--The "debug" patch simply applies the English translation to the
  game and performs no further modifications.
--The "final" patch attempts to remove, to the best of my ability,
  bugs, non-functional options, and debug features from the game
  to simulate what it would look like at a public consumer release
  stage.

What the "Final" patch does:
--Removes "Test", "Training", and "Config" from the title menu
--Removes the frame counter from the upper-left corner of the screen
--Enables damage to Corneria
--Removes the sprite data counter from lower-right of the map screen
--Removes cheat functions built into the debug version
--Fixes a bug if you try to transform into Walker mode in space missions

Also, a few other changes inclusive to both patches:
--The title screen was altered with a new, flashier title logo.
--All instances "Andorf" were changed to "Andross" in keeping with the US
  releases of the series
--All instances of "Algy" were changed to "Andrew" in keeping with the US
  releases of the series

--------------
5.Known Issues
--------------
--There are no known issues, barring the stuff mentioned in Section 0.
  Do read it.

If you find any, please post about them on The Pantheon
(http://donut.parodius.com/agtp)

--------------------------
6.Application Instructions
--------------------------
(Copied from Section 0)
There are five or six different roms floating around. This will
work on the "best" rom, which isn't in goodsnes, and the two roms
that goodsnes lists as "Beta TD" and "J o1". Neither should have a
header -- if the you patch the game and it crashes (and it didn't
crash unpatched), use SNESTool or something similar to remove the
header.

I'm not going to give quick rom info or correct sizes for this
release because of size discrepancies between multiple versions of
the game. Bah.

Otherwise, you can A) toss the patch wherever your emulator stores
save games and in the directory where your rom is, ensuring that
both ROM and patch share the same name (in other words, "starfox.smc"
and "starfox.ips" for example.)

-----------------
7.Troubleshooting
-----------------
--If the game does not run at all, read the above section on
  application instructions and Section 0.
  Make sure your ROM is not read-only.
  Also make sure that if you previously hard-patched the ROM and
  the game crashes as described, you will need to re-apply the
  patch a clean, Japanese original ROM.
