-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Chrono Trigger (SNES) � Re-Retranslation Patch
Current Version:  1.01
Author:  Doctor L (http:// doctorl.vox.com)
E-Mail:  doctorl.support@gmail.com
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CONTENTS
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
I.   Version History
II.  Introduction
III. Notes
IV.  Installation
V.   Support
VI.  Credits
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
I. VERSION HISTORY
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Version 1.01:	2008-03-29
   -Reformatted various text found in the Middle Ages
   -Changed "Bento Box" to "Lunch Box"
   -Changed "R'bowShard" to "PrismShard"
   -Changed "H. Dry Meat" to "Hot Jerky"
   -Changed "KlrIcePick" to "Hurricane" (actual item is Killer Hurricane)
   -Changed "Soysaw Edge" tp "Soy Edge"
   -Changed "SoyswEdge 2" to "Soy Edge +"
   -Changed "DespairScyth" to "GrimReaper"
   -Changed "BrknSword" to "RustyBlade"
   -Changed "BrknHilt" to "SplitHilt"
   -Changed "TrcraPlate" to "Dino Plate"
   -Changed "EternlSuit" to "Aeon Suit"
   -Changed "StrdstCape" to "ZodiacCape"
   -Changed "DespMantle" to "GrimMantle"
   -Changed "TrceraHelm" to "Dino Helm"
   -Changed "EternlHelm" to "Aeon Helm"
   -Changed "DspairHelm" to "Grim Helm"

Version 1.00:	2008-03-28
   -First Release

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
II. INTRODUCTION
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

So, you�re probably wondering why a great game that already had a decent 
translation and a recently released retranslation from fans would need another 
fan translation.  Normally, I�d be wondering the same thing.  However, here we 
are.

Late in January of 2008, I had a desire to play Chrono Trigger again after having
not played for at least 7 years.  When I discovered that KWhazit, ZeaLitY, and 
company had finished a new English retranslation, I immediately applied it to the 
game and started playing.  

No, discredit to them, but I felt much of the text was incoherent and/or awkward.  
I soon discovered I was not the only one who felt this way.  Therefore, instead 
of complaining, I decided to take action.  I acquired all the necessary tools to 
begin doing my re-retranslation.  For the next 3 months, I went to work.

I want to make it clear that, despite not enjoying their version, I would not 
have been able to do this without Chrono Compendium�s retranslation forerunners 
like ZeaLitY and KWhazit.  The resources they provided pointed me in the right 
direction to complete this. 
 
In the end, here are the fruits of my labor.  I aimed not so much for a literal 
translation, but localization, clear and easily understood text, and the inclusion 
of any missing elements left out from the US version due to Nintendo�s censorship 
policy from back in the day.

Hopefully, you�ll find it to be an enjoyable experience.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
III. NOTES
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
I will not provide you or tell you where to get an illegal ROM image of Chrono 
Trigger.  Don�t ask.  You are expected to provide your own legit copy.

Regarding the change of the element icon �Lightning� to �Sky� and then to 
�Heaven� in my version:  I have strong reasoning for doing this.  I will explain.  
The Japanese character used for Crono's element can be rendered as Sky or Heaven 
in English.  ZeaLitY decided on Sky.  However, here are my reasons for choosing 
Heaven:

1. Crono�s final tech�s, Shining (Luminaire in original English version), 
description reads literally from Japanese, �Ultimate holy magic on all enemies.�  
Any version of heaven across all cultures in a spiritual, metaphysical, or magical 
sense is associated with being holy.
2. If the element truly was supposed to be Sky, why would the localization team 
change it to Lightning?  Such changes were generally only done for three reasons: 
The original meaning held religious context (as heaven does), cultural difference 
no one here would readily understand, or was of an adult nature.

I based my ROM edit off of a copy of Chrono Trigger patched with Chrono 
Compendium�s retranslation patch.  So, their CronoNick fix and the ending artwork 
are both still in-tact.  I take no credit for these whatsoever and you have them 
to thank.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
IV. INSTALLATION
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

1. Create a ROM image from a North American copy of Chrono Trigger and place it 
on your computer.  I will not tell you how to do this.  Google is your friend.

2. Make a copy of your ROM image.  Rename it to something different from your 
original for ease of identification.  May I suggest ChronoTriggerPatched.smc?

3. Open the patch according to what type of ROM image you made.  If you know for 
certain what unheadered means and it applies to your ROM, choose 
CTR-Unheadered.ips.  If you are unsure or know it is headered, choose 
CTR-Headered.ips.

4. You will be asked to locate the ROM you want to patch.  Locate the copy you 
made and apply the patch to it.

5. You should now be able to play it on most any emulator.  I prefer ZSNES, but 
the choice is yours.

You can also rename the patch to the name of your ROM and run it in ZSNES, and
the emulator will automatically apply it. They must be in the same folder or
specified in the Paths options.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
V. SUPPORT
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

E-Mail: doctorl.support@gmail.com

Perfection is an ongoing struggle.  If you find any text related error, make 
certain you are using the latest version of the patch.  If you are, please feel 
free to email me letting me know about it.  Please follow these guidelines in 
doing so:

1. Quote the text and tell me what you feel is wrong with it.
2. Who said it?
3. Where did they say it?  Be as specific as possible.

I can�t promise I�ll get back to you about it right away, but I will make an 
effort to do so.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
VI. CREDITS
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Squaresoft/Square Enix for creating the game and giving me a reason to do this.

Ted Woolsey for providing the original, entertaining English translation.

KWhazit for the English retranslation script.

ZeaLitY for playing a large part in creating the original retranslation patch.

Geiger for creating Temporal Flux and giving the community an easier means of 
finishing translation projects such as this.
http://geigercount.net/crypt/

JLukas and Geiger for creating the CronoNick fix for the original retranslation 
and for providing us with the ending art.

justin3009 for helping a very frustrated me with inserting Crono�s �Heaven� 
element icon into the game.  He will go on to be a great king that will rule 
the land with his generous iron fist of awesome.

Any other person from the Chrono Compedium who in any way contributed to the 
release of this patch in any shape or form.
http://www.chronocompendium.com