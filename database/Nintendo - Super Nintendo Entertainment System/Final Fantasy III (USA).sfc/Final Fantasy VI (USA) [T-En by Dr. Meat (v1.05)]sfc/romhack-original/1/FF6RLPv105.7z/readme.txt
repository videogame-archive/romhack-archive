Title: Final Fantasy VI Relocalization Project
Author: Dr. Meat (Alex)
Version: 1.05

_______________________________________________________________________________


Apply this patch to a SNES Final Fantasy III 1.0 ROM with the following
attributes:

Either UNHEADERED or HEADERED
CRC32 Checksum: A27F1C7A
MD5 Checksum: E986575B98300F721CE27C180264D890

The patch is in .ips format, so you need a program like Lunar IPS to do the
patching for you.

If you still aren't sure if your ROM has a header or not, NSRT can detect that
for you.

If you are updating from a previous version of the patch, you must apply the
new patch to an unmodified FF3 US 1.0 ROM. Your save will still work.

If your ROM does not have a header (filesize is 3072 KB),
apply FF6RLPv1.05-noheader.ips.

If your ROM has a header (filesize is 3073 KB),
apply FF6RLPv1.05-header.ips.

_______________________________________________________________________________


About the project:

The Final Fantasy VI Relocalization Project is an attempt to "relocalize" the
Super Nintendo game Final Fantasy VI in a way that the original localization
team might have done, if they had more time and ROM space to do so.

This patch changes many, many things in the game - most notably the game's
dialog scripts, as well as monster, item, and spell names, in order to be a
(hopefully) more accurately translated experience with more nuance.

More information can be found here:
https://sites.google.com/site/ff6relocalized/

Many patches by authors other than myself were used in this project. A complete
list of credits can be found here:
https://sites.google.com/site/ff6relocalized/credits

_______________________________________________________________________________


Contact me:

If you find any problems with it, or just want to say hi, feel free to contact
me via Twitter.

ESPECIALLY get in touch with me if you are the author of a hack I've used in
the patch and either feel I've credited your work incorrectly, forgotten to
credit your work, or do not want your work included in my patch. I'll fix
things as quick as I can.

Twitter: @drmeat64

_______________________________________________________________________________


Changelog:

v1.05
-Fixed a bug that could garble map graphics in the second half of the game.
-Fixed a couple typos and grammatical errors folks pointed out recently.
-Reverted all changes to espers with the exception of Ramuh's 5x Thundara rate.
 That was a gameplay change that, in all honestly, I had forgotten was even
 implemented and which I had failed to document. It is also just outside the
 scope of the hack.

v1.042
-Fixed a showstopping bug I accidentally left in 1.041 when attempting to fix
 some other showstopping bugs from 1.04. D'oh.

v1.041
-Fixed some softlocks I made accidentally in 1.04. Oops!

v1.04
-Fixed some instances where abilties displayed the wrong name when used in
 battle.
-A ton of typo and grammar fixes!

v1.03
-Uncensored the final battle backgrounds! The game's graphics should be 100%
 censorship-free now!
-Celes has a pretty ribbon tent like Terra now.
-Adjusted MP growth curve to match FF6J.
-More script revisions, mostly typos and style fixes.

v1.02
-Added Novalia Spirit's Magic Menu sort fix patch, so the battle magic menu
 sorts better with gaps between spells.
-Made finger positioning a bit more standardized in menus.
-More script revisions! Fixed some bits where text would run off-screen in big
 and small battle dialogs.

v1.01
-Fixed intro "attract mode" script not advancing properly.
-Properly centered all opera text, as well as a few character intro narration
 thingies.
-More script revisions, mostly typos and style fixes.

v1.00
Initial release
