package lz.entities;

public enum NodeType {

    UNTREATED,
    REPEAT,
    DATA
}
