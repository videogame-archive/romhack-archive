I recommend using the Automatic Dash patch from below:
https://www.romhacking.net/hacks/3746/

BUGFIXES

The .zip file contains an optional patch containing various bugfixes sourced from slickproductions.org, as well as those
included in noisecross' FF5e text editor. This should be patched OVER the main patch.
They are as follows:

 - Caught monster display
 - Catch bug fix
 - Kiss of Blessing bug fix
 - Power Drink bug fix
 - Observe bug fix
 - Bartz's blue mage sprite fix
 - Berserk chicken knife fix
 - Two Galufs fix
 - Faster common death animation
 - Fractional M parameter knife fix (http://slickproductions.org/slickwiki/index.php/FF5_Patch:Fractional_M)
 - Walk through walls fix
 - Landing fix

See http://slickproductions.org/slickwiki/index.php/Final_Fantasy_V_Hacking#Patches for more information.

Also included is an optional patch that makes Galuf's hair consistently ginger. Again, this should be patched OVER the main
patch.

CHANGELOG

v1.16 - Added kouga47's fix for a dialogue bug

v1.15 - Mithril Drgn -> MythrilDrgn, MgicShell -> Mag.Shell, fixed a misplaced ! mark.

v1.14 - Attempted to tidy up the crystal prophecy a bit. Stalker is now Wendigo.

v1.13(a) - Changed some abbreviations + formatting and fixed some oversights (fixed a small oversight)

v1.12 - Edited fonts to make them cleaner and easier to read, a few other minor changes

v1.11 - Updated a few monster names, fixed oversights, restored original japanese item/spell icons (except harp icon)

v1.1 - As many spell names as possible have been updated, meaning the numbered spell system has finally been replaced with
the -ra -ga system.

v1.07 - Added optional bugfixes.

v1.06 - Changed Image to Blink.

v1.05 - As of this version, the zip file contains two patches - one with a shadowed menu font, one without.

v1.04 - Updated the dialogue font for consistency with the FF4 font, fixed oversights

v1.035 - Fixed a small oversight.

v1.03 - Changed the menu font to the FF4 font, changed the esper Shoat to Catoblepas (Catobl), fixed a small oversight.

v1.02 - Changes to spell and monster names

v1.01 - Fixed some minor text issues