SHIN NEKKETSU KOUHA - KUNIO-TACHI NO BANKA
ENGLISH TRANSLATION V1.00
Copyright 2002 by Aeon Genesis
http://agtp.romhack.net

ToC

1.  About Kunio-tachi no Banka
2.  Patch History
3.  Patch Credits and Contributors
4.  Known Issues With the Patch
4.1 Stuff Deliberately Left Undone
5.  Application Instructions

----------------------------
1.About Kunio-tachi no Banka
----------------------------
Banka is a beatemup for the Super Famicom/Super NES
console. It is a distant cousin to the game known in
the US as River City Ransom; in fact, it is a direct
sequel to Nekketsu Kouha - Kunio-kun ("Renegade" in
the States) which eventually spawned RCR. Since it is
not directly related to RCR, it does not have the RPG
elements you might expect it to have; nonetheless, it
is a decidedly above-average beatemup. It's quite long,
as well, and has a very large script in comparison to
other games in the genre.

---------------
2.Patch History
---------------
The project started on June 7th, 2002 out of the need
for a new beatemup game to play with my friends. I hoped
to get the script translated fairly quickly, but it
chewed up and spat out two translators before I finally
found a third who stuck with it about three or four weeks
prior to this writing. Kudos go out to Datenshi for not
giving up!

September 20, 2002 - Initial version 1.00 Release

---------------
4.Patch Credits
---------------
THE BANKA TEAM
Main Team:
Gideon Zhi - Project leader, romhacker
Datenshi - Text Translation

Special Thanks
Datenshi would like to thank the following people for their help
with various bits of the script:

akujin
celes
Eien Ni Hen
Ian Kelley
Loek
MO mSprout
Shih Tzu
Waffles

-----------------------------
4.Known Issues with the Patch
-----------------------------
There are no known issues.
Please report any bugs, spelling errors, and such
on The Pantheon (http://donut.parodius.com/agtp)
Screenshots are preferred, as are savestates.

----------------------------------
4.1 Stuff Deliberately Left Undone
----------------------------------
1) The end credits.
They scroll side-to-side. No WAY am I touching that.

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "banka.smc" make sure the patch
is "banka.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM DOES HAVE
a header. If you right-click the ROM and select Properties, it
should read "Size: 2.00MB (2,097,664 bytes)". SNESTool will remove all
of your headers for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.