------------------------------------------------------------------------------
 Space Knight Tekkaman Blade Patch                                version 1.0
 Written by Derrick Sobodash & byuu                            Copyright 2004
 Released on October 4, 2004                   http://www.cinnamonpirate.com/
------------------------------------------------------------------------------

 INFORMATION

 In 1998 when I was losing my internet connection, I decided to work on
 translating Tekkaman Blade while it was gone. When I was a kid, the show was
 one of my favourite cartoons, so I really wanted to see the game done. I
 printed out the script in NJStar and translated it on paper. Unfortunately,
 I had problems with the timed text and gave up. The script went in my drawer
 until 2002.

 In 2002, I dug it back out and tried to hack the game again... and failed.
 Instead, I put my translation together as a FAQ on the game and published it
 on GameFAQs. Gideon Zhi talked about hacking the game but never did... so it
 continued to sit there.

 In 2004, byuu asked me to do some Dai Kaijuu Monogatari battle icons for him
 the way I did icons for Magna Carta (with the help of TeknoZX). In exchange,
 he agreed to hack Tekkaman Blade for me -- something I'm sure he now regrets.
 I made him do way too much work on this game.

 I know this isn't the greatest game to grace the SNES, however, it's still
 far from the worst game to get translated. byuu and I put a lot of effort
 into improving the game and adding more story information. The game
 originally lacked any story at all. I wrote all the prologues to help move
 unfamiliar players through the plot of Tekkaman Blade, and overall, I think
 it was very successful.

 Technically, byuu worked out code for 256 color graphic display where
 previously our best had been 16. He also added multiple font systems and got
 around the compressed font used in the credits. Glow shadows were added to
 everything to make it easier to read than in the Japanese game (which used a
 borderless, white font).

 Don't bitch about the title screen being in Japanese. We intentionally left
 it that way. The Tekkaman Blade logo is rather famous, and no English
 rendering would ever have quite the same feel. Moreover, this patch is
 targeted to Tekkaman Blade fans, all of who would be familiar with the logo
 and have more warm. fuzzy feelings seeing it than a crappily drawn English
 one.

 I'm really glad to finally see the game finished after all these years, and
 right in time for the 10th anniversary of when the show stopped airing.

------------------------------------------------------------------------------

 STORY

 United Century 192

 Humans are on the brink of extinction...

 The Orbital Ring System, a gigantic space station built by humans for
 deep-space exploration, has been taken over by the mysterious life forms,
 "Radam."

 Mankind's connection to space has been cut off, trapping them on Earth at
 the mercy of Radam attacks from the Orbital Ring System.

 The Earth is scorched, cities have been destroyed, and humanity is falling
 into ruin.

 An amnesic young man, brought in by the Space Knights and dubbed "D-BOY," is
 Earth's last hope.

 With his crystal, he's able to turn into Tekkaman Blade, the only human
 capable of fighting the Radam aliens.

 He is humanity's last hope.
 
------------------------------------------------------------------------------

 CONTROLS

 Flight Stages:
   D-PAD - Move up, down, left or right.
   Y     - Throws Blade's... blade across the screen, it boomerang's back
           using an invisible cable.
   B     - Slashes with Blade's weapon. Tap twice for an overhead slash.
   X     - Uses the Voltekker attack to destroy everything on screen. The
           Voltekker takes one yellow dot. You can acquire another one by
           collecting a red crystal.
   START - Pauses the game.

 Boss Stages (and Versus Mode):
   D-PAD - Moves left or right, jumps or crouches.
   Y     - Thrust (becomes Kick if weapon is knocked away).
   B     - Slash (becomes Punch if weapon is knocked away).
   Y + B - Dash attack (knock-down).
   X + A - Fires a laser. Only works while you have a weapon.
   START - Pauses the game.

 Power-Ups:
   Green Crystal - Restores health. The lower your health, the more it
                   restores.
   Red Crystal   - Adds a yellow mark to your power bar. For each yellow
                   circle you can use the Voltekker attack once.
   Blue Crystal  - Makes Blade transform into his Flash Interval battle
                   mode for 5 seconds. During this mode, any enemy he
                   touches will die -- even bosses.

------------------------------------------------------------------------------

