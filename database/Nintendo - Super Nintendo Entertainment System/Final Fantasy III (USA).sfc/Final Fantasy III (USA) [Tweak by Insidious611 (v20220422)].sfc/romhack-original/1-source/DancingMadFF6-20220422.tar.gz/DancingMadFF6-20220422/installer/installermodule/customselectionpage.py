# Custom Track Selection Page

from PyQt5 import QtWidgets

class customselectionPage(QtWidgets.QWizardPage):
        def __init__(self):
              super().__init__()
