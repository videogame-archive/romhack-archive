Jikkyo Power Pro Wresling English translation

-------------------------
1. About this translation
-------------------------

This translation along with many other wrestling translations, were originally hosted on two sites (www.firewrestling.com and the author�s official homepage.) When both sites went offline, they took the files with them. Thankfully, using the archive.org search engine, this file along with many of the other translations were salvaged.

The following info is from the archived website

----------
2. History
----------

This is an unusual game. Jikkyo is one of the games that is mediocre in most aspects, but is outstanding in a few. However, those few count for a lot. Jikkyo has a high degree of graphic definition (it looks more realistic than most other games on the SNES) which acts as a double-edged sword. It makes the screenshots look incredible and actually does add to the realism of the game, but it prevents any matches where more than two people are active. In other words, no Battle Royals and no realistic tag matches. It does have tag matches, but the partners that are out of the ring are frozen. This is because the processor could not handle doing AI for more than two people and refreshing the graphics on time. To see this effect in action, play WCW Nitro on PSX and watch what happens to the game when a run-in occurs.

However, the basic matches are not really the point of interest in Jikkyo. Jikkyo contains a career mode called Max Voltage where you start as a rookie wrestler and work your way up through different federations, choosing when to train and how. As far as I know, no other game has ever tried to make a career mode of this type. Due solely to the presence of this mode, I decided to try to translate Jikkyo. Once again, Sydra agreed to help with the translation (which is obvious since I'm writing this entry) and I set to trying to figure out how to put the text in.

Well, this game is a nightmare. Translating this game is a truly masochistic experience. Unlike BPW and SFPWXP, labels sizes cannot be changed, which is requiring some really creative abbreviations on my part. So far, I've been able to insert moves names into Max Voltage and wreslter names (Sydra and others informed me that translating names is unreliable at best, not to mention time consuming- so I just made up some based on the characters' portraits). I have also put in most of the menus options that are commonly known. If anyone knows the meaning of other stuff that is still not done or, by some bizarre twist of luck, can read Japanese, please email me. This game is too big for any one person to try to translate. Due to an oversight when originally writing this page, I left out the fact that most of the information for the translation, up to this point at least, has come from Kactus Ken's Jikkyo FAQ. Sorry. Anyway, here's the goods. 

-----------
3. Patching
-----------

Simply patch the ROM using your favourate patching program

----------------
4. Training note
----------------
In the game, you periodically get status messages that inform you of the current training status. Unfortunately, these messages were far too short to put in decent translations. After examining them, most labels are the same and basically are uninteresting characterizations of distinct levels of the attributed (for example, the mediocre state's message for all attributes is something along the line of "You have more --- than some others" while the best message is "Superb ---"). So, in short, I've had to replace these phrases with a simple letter coding system based on grades given in American schools (this is similar to how SFPW6MS rates the effectiveness of moves in the edit menu). Superb => A; Good => B; Mediocre => C; Poor => D; Very Bad => F. In addition, the fourth statistic, weight, is not on a similar scale since you are aspiring to stay in the middle of the range rather than get to the top. So, for weight, we have Morbidly Obese => +3; Overweight => +2; Slightly Overweight => +1; Ideal => 0; Slightly Underweight => -1; Underweight => -2; Dangerously Underweight => -3. Also, when these stats change, a similar message is given, but rather than a ranking, a +/-/0 is given to denote an increase in rank, decrease, or insignificant change. This system should also make it a bit more straight-forward to train since it states exactly what is happening without disguising it with rhetoric. 

------
5. Q&A
------
Q: Are you planning to translate the Max Voltage section?
A: I'm working on that currently. A few translators have come and gone, but the fellow I'm working with right now is looking promising.

Q: Is there a way to enter my name in English?
A: Unfortunately, no. Unlike other games like BPW and SFPWXP, Jikkyo does not even provide a complete character set of English characters. The game, luckily, used enough English and Roman characters in its Japanese version to require every uppercase letter except for a Q. Also, unlike the other games, Jikkyo does not use a character format that can be editted by any of the utilities that I know of, so you cannot "hack" in a character set (as I did with BPW). Sorry, you'll just have to make due with Japanese.

Q: How long til you finish translating Max Voltage?
A: Impossible to say. I'm pretty sure that it will take quite a while, so don't hold your breath.

----------
6. Credits
----------
Phil - Hacker
Keishou Omomuroni - Translation
Squireforhire - Finding the lost files
snesmaster40 - Repatch and FAQ