Gulliver Boy: Hardware Compatibility Fix v1.1
Programmed by mziab, http://mziab.grajpopolsku.pl
Released April 2nd, 2014

This patch fixes the broken dialogue text and garbled splash screen in the
English patch by Dynamic Designs, both of which could be experienced when
running the game on real hardware and accurate emulators.

Changelog:
v1.1, April 2nd, 2014
- Added a more complete fix for the splash screen (thanks to TheShadowRunner
  for testing on sd2snes).

v1.0, September 10th, 2012
- First public release.

Usage:
The patch should be applied to a rom pre-patched with the D-D English translation
version 0.99, WITHOUT a header (1,572,864 bytes). For the sake of convenience, the
archive includes the patch in both IPS and BPS formats.

Please note that there are TWO versions of the v0.99 patch in circulation:
an older one (dated May 24th, 2001) and a newer one (dated May 26th, 2001).
This fix is meant for the newer release, which is fortunately the one
available at RHDN. For the record, the only notable difference between both
versions is one minor tilemap fix.

Disclaimer:
No bugs were revealed during my testing of the patch. However, if you happen to
notice any defects introduced by it, be sure to contact me per e-mail (mziab@o2.pl)
and I'll see what I can do.
