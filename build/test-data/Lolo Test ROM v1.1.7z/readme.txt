Lolo Test ROM v1.1 by HACKERMANS

This is a hack for Kirby Test ROM that replaces Kirby with Lolo.

==CHANGELOG==

v1.1 - 2023-04-25
- Fixed graphical bug.

v1.0 - 2023-04-24
- First release.
