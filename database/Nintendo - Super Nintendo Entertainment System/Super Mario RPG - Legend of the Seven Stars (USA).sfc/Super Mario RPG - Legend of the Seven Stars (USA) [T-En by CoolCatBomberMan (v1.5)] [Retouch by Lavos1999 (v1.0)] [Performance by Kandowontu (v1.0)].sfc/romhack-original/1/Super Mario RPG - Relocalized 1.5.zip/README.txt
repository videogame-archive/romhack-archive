 _______________________________________
/					\
|      Super Mario RPG: Relocalized	|
|	   by CoolCatBomberMan		|
\_______________________________________/
This patch is the result of an entire year's worth of reviewing and rewriting the entirety of Super Mario RPG's script in order to achieve an overall more accurate translation of the Japanese script. Every item, attack, monster and dialog box has been compared to its Japanese equivalent, and while not every aspect of Ted Woolsey's script has been excised, the author estimates only about 10% of the game's text has been left totally untouched. Even in situations where the official translation was deemed adequate, it was not uncommon for grammatical or formatting-based edits to occur. The result is a translation that attempts to reflect how the official translation would have looked if Woolsey's script was reviewed and revised by an editor back in 1996. Changes include:

*Enemy and character names changed to reflect pre-established localizations. (This includes changing Princess Toadstool to Princess Peach, as Yoshi's Safari, which referred to her as such, released in 1993.
*Item names changed to reflect either a more accurate translation, consistency with Paper Mario and/or consistency with official artwork.
*Location names changed reflect a more accurate translation, with one exception, which instead reflects consistency with Paper Mario.
*In-game dialog heavily reviewed and rewritten, using Japanese dialog translated by hand using online dictionaries, Tomato's livestream and website, and occasional feedback from nejimakipiyo.

This hack was made possible by giangurgolo & Omega’s Lazy Shell editor. No header required for patching.


--Instructions--
Use Floating IPS to apply the patch to your HEADERLESS ROM.



CHANGELOG
1.0 - Initial release
1.1 - Formatting fixes at Chicken Knife's request
1.2 - Split hack into "Xeno Version" and "Geno Version"
1.3 - Fixed oversight in "Geno Version" where Geno was still referred to as Xeno
1.4 - Fixed text overflow in Special Attack descriptions
1.5 - Fixed oversight in "Geno Clone's" name, "Xeno Version" discontinued



LIST OF NAME CHANGES
(Old Name===========New Name)

LOCATIONS
Mario's Pad=========Mario's House
Vista Hill==========Vantage Hill
Mushroom Way========Mushroad
Mushroom Kingdom====Mushroom Castle
Kero Sewers=========Croakstool Canal
Midas River=========Wine River
Tadpole Pond========Ribbit Lake
Rose Way============Croase
Forest Maze=========Wiggler Forest
Pipe Vault==========Pipe Dungeon
Yo'ster Isle========Yoshi's Isle
Moleville===========Ducati
Booster Pass========Burr Valley
Booster Tower=======Bookie Tower
Booster Hill========Bookie Hill
Star Hill===========Shooting Star Summit
Seaside Town========Ripple Town
Land's End==========Country Road
Monstro Town========Monstown
Grate Guy's Casino==Clown Casino
Nimbus Land=========Marshmallow Land

CHARACTERS
Princess Toadstool==Princess Peach
Chancellor==========Minister
Raz=================Mush
Raini===============Nancy
Gaz=================Toydo
Jagger==============Koopyang
Magikoopa===========Kamek
Goomba==============Goombaris
Ma'Mole=============Ma'Boom
Pa'Mole=============Pa'Boom
Chef Torte==========Head Chef
Jinx================Jacky
King Nimbus=========King Marshmallow
Hinopio=============Pyroad
Dr. Topper==========Kaldi

ATTACKS/SPELLS
Backfire============Eruption
Big Bang============Self-Destruct
Blast===============Explosion
Blazer==============Death Killer
Blizzard============Cold Chill
Body Slam===========Tackle
Bolt================Lightning
Bombs Away==========Shock Bullet
Boulder=============Rock Rattling
Bowser Crush========Mecha Crush
Breaker Beam========Virtue Breaker
Carni-Kiss==========Bite
Chomp===============Monster Toss
Claw================Scratch
Crusher=============Jagged Boom
Dark Claw===========Undead Nail
Deathsickle=========Fear Sickle
Diamond Saw=========Diamond Cutter
Doom Reverb=========Restful Echo
Drain===============Fire Orb
Drain Beam==========Geyser
Echofinder==========Sonic Waves
Eerie Jig===========Weird Dance
Electroshock========Elekiter
Endobubble==========Dark Shivers
Fangs===============Fang
Fire Orb============Fireball
Fun & Run===========Dash
Funguspike==========Shroom Needle
G'night=============G'night Arrow
Geno Boost==========Geno Wave
Geno Whirl==========Geno Cutter
Get Tough!==========Iron Skin
Grinder=============Sharp Talon
Gunk Ball===========Muddy Water
Hammer Time=========Hammer Toss
HP Rain=============Recover Rain
Ink Blast===========Ink
Iron Maiden=========ROAR!!
Jinxed==============Jacky Rush
Last Shot!==========Sacrifice!
Light Beam==========Rainbow Bubble
Loco Express========Eruptrain
Lulla-Bye===========Sweet Song
Magnum==============Banzai
Mega Drain==========Lightsaber
Meteor Blast========Shiny Meteors
Meteor Swarm========Milky Meteors
Migraine============Vanish!
Mush Funk===========Mushroom Gas
Mute================Zip Your Lip
Petal Blast=========Petal Blizzard
Pierce==============Precise Aim
Poison Gas==========Smoggy Gas
Psych Bomb==========Psycho Bomb
Psyche!=============Smash!
Psycho Plasm========Terror Cell
Psychopath==========Mind Reader
Quicksilver=========Iron Fist
S'crow Funk=========S'crow Smog
Sand Storm==========Sandstorm
Shaker==============Back Blade
Shocker=============Thunderclap
Shredder============Tear Off
Silver Bullet=======Doom Fist
Sledge==============Mega Hammer
Sleep-Sauce=========Sleep Water
Sleepy Time=========Go to Sleep
Snowy===============Heavy Snow
Solidify============Freeze Solid
Somnus Waltz========Drowsy Dance
Spore Chimes========Mushroom Bell
Sporocyst===========Shroom Spore
Spritz Bomb=========Bomb Roll
Static E!===========ESD Phenomenon
Super Flame=========Super Fire
Terrapunch==========Beat Attack
Therapy=============Pain Relief
Thornet=============Poison Needle
Triple Kick=========Triangle Kick
Ultra Flame=========Ultra Fire
Va Va Voom==========Big Eruption
Valor Up============Guts Up
Venom Drool=========Poison Water
Vigor up!===========Spirit Up
Viro Plasm==========Toxic Cell
Water Blast=========Steam Blast
Wild Card===========Quads
Willy Wisp==========Will-o'-Wisp

ITEMS/EQUIPMENT
Able Juice==========Refresh Juice
Amulet==============Bookie Charm
Antidote Pin========Sterile Pin
Attack Scarf========Jumper Scarf
B'tub Ring==========Love Ring
Beetle Box==========Insect Cage
Big Boo Flag========Boo Charm
Bracer==============Defense Up
Chomp Shell=========Chomp Husk
Coin Trick==========Coin Charm
Courage Shell=======Secure Shell
Cricket Pie=========Cricket Rusk
Crystalline=========Defense All
Cymbals=============Cymbal
Wilt Shroom=========Dried Shroom
Dry Bones Flag======Dry Bones Charm
Earlier Times=======Reset Charm
Elixir==============Leg Croix
Energizer===========Power Up
Exp. Booster========Exp. Charm
Feather=============Dodo Feather
Fire Bomb===========Blaze Bomb
Flower Box==========Flower Gift
Flower Jar==========Flower Set
Flower Tab==========Flower Pill
Freshen Up==========Refresh All
Froggie Drink=======Tabpole
Froggie Stick=======Ribbit Staff
Fuzzy Cape==========Fluffy Cape
Fuzzy Dress=========Fluffy Dress
Fuzzy Pants=========Fluffy Pants
Fuzzy Shirt=========Fluffy Shirt
Greaper Flag========Ghost Guy Charm
NokNok Shell========Koopa Shell
Heal Shell==========Heel Shell
Hurly Gloves========Toss Glove
Jinx Belt===========Jacky Belt
Jump Shoes==========Shield Shoes
Kerokero Cola=======Croaka-Cola
Lamb's Lure=========Sheep's Lure
Lazy Shell==========Dive Shell
Masher==============Fickle Hammer
Mega Cape===========Perfect Cape
Mega Glove==========Mega Punch
Mega Pants==========Perfect Pants
Mega Shirt==========Perfect Shirt
Megalixir===========Finta
Moldy Mush==========Moldy Shroom
Muku Cookie=========Chub Cookie
Nautica Dress=======Sailor Dress
Pick Me Up==========Revive Drink
Polka Dress=========Love Dress
Power Blast=========Power All
Pure Water==========Holy Water
Quartz Charm========Crystal Charm
Rare Scarf==========Defend Scarf
Red Essence=========Red Extract
Ribbit Stick========Croak Staff
Room Key============Mine Key
Rotten Mush=========Rotten Shroom
Safety Badge========Relief Pin
Scrooge Ring========FP Charm
See Ya==============Escape Charm
Shed Key============Warehouse Key
Sheep Attack========Sheep's Urge
Sleepy Bomb=========Sleep Bomb
Spiked Link=========Spiny Chomp
Mid Mushroom========Super Shroom
Super Suit==========Super Jumper
Thick Pants=========Tight Pants
Thick Shirt=========Tight Shirt
Toadstool's ???=====Peach's ???
Troopa Pin==========Para Medal
Troopa Shell========Para Shell
Max Mushroom========Ultra Shroom
Wake Up Pin=========Alert Pin
War Fan=============Folding Fan
Whomp Glove=========Stretch Punch
Work Pants==========Dirty Pants
Yoshi-Ade===========Yoshi Extract

ENEMIES
Terrapin============Koopa Trooper
Kinklink============Chompelier
Sky Troopa==========Paratroopa
Spikey==============Spiny Trooper
K-9=================Hyenine
Frogog==============Richard
Shyster=============Shyper
Mack================Swordor
Rat Funk============Squeaky
Goby================Cheep Cheep
The Big Boo=========Boo
Hobgoblin===========Pierre
Pandorite===========Whatisit
Belome==============Ton~gue
Starslap============Upstart
Snapdragon==========Eve
Arachne=============Lack Widow
Crook===============Bagit
Amanita=============Poppin
Buzzer==============8-Beet
Octolot=============Octorot
Guerilla============Don King Kong
Bowyer==============Bowpa
Sparky==============Lava Bubble
Shy Ranger==========Army Guy
Magmite=============Magma Beetle
Enigma==============Bathog
Punchinello=========Pepput
Microbomb===========Petit Bomb
Mezzo Bomb==========Big Bomb
Spikester===========Burr Trooper
Carroboscis=========Carroline
Artichoker==========Sprinturf
Spookum=============Snifit
Rob-omb=============Hi-Bomb
Remo Con============Woodbot
Jester==============Doubt
Fireball============Blue Bubble
Blaster=============Kablam
Orb User============Popo
Chomp===============Chain Chomp
Snifit==============Booker
Booster=============Bookie
Knife Guy===========Clown Bro Sr.
Grate Guy===========Clown Bro Jr.
Torte===============Koopa Chef
Bundt===============Strawberry
Gecko===============Leon
Pulsar==============Rupee
Mukumuku============Chubflub
Mastadoom===========Wight Mammoth
Zeostar=============Dastardly
Mr. Kipper==========Bweep Bweep
Bloober=============Blooper
Leuko===============Jelelly
Crusty==============Craab
Greaper=============Ghost Guy
Alley Rat===========Squeaker
Reacher=============Gravey
Tentacles===========Squid Leg
King Calamari=======Pot Blooper
Straw Head==========Edward
Gorgon==============Bathoghog
Hidon===============Whatsinit
Goombette===========Mini Goomba
Yaridovich==========Spearovich
Chow================Dryenine
Shogun==============Ant Warrior
Geckit==============Vermileon
Spinthra============Branch Widow
Stinger=============8-Beet Red
Fink Flower=========Flower Lip
Kriffid=============Rustling Aloe
Chewy===============Green Piranha
Ribbite=============Richard II
Shy Away============Beezo
Formless============Unknown
Mokura==============Smoggy
Toadstool 2=========Peach Clone
Culex===============Crystaller
Chomp Chomp=========Whomp Chomp
Box Boy=============Whatsinside
Fautso==============Smoker
Smilax==============Bud
Megasmilax==========Piranha Queen
Heavy Troopa========Dive Troopa
Sling Shy===========Hi-Shy Guy
Pinwheel============Hectobar
Muckle==============Hi-Jelelly
Orbison=============Roro
Shaman==============Spell
Jawful==============Demigla
Shelly==============Odd Shell
Eggbert=============Uneggspected
Valentina===========Margarita
Magmus==============Megma Beetle
Oerlikon============Urchin Trooper
Armored Ant=========Ant Hero
Pyrosphere==========Lava Bobble
Chained Kong========Barrel Kong
Vomer===============Dry Bones Z
Corkpedite==========Tantrum
Stumpet=============Erupture
Czar Dragon=========Kaiser Dragon
Helio===============Volcanic Bomb
Zombone=============Zombie Dragon
Axem Rangers========Axe Force
Terra Cotta=========Red Koopa Trooper
Gu Goomba===========Goomiracle
Star Cruster========Star Craab
Malakoopa===========Paratroopa Dash
Tub-o-Troopa========Sumo Troopa
Forkies=============Oyster
Glum Reaper=========Reaper Guy
Chester=============Whatsinthere
Bahamutt============Doshi
Magikoopa===========Kamek
Big Bertha==========Kablam mk. II
Exor================Calibur
Neosquid============Mouth
Ameboid=============Jelloeba
Count Down==========Moebius
Machine Made========Mass-produced
Jabit===============Jabber
Mad Mallet==========Clink
Pounder=============Clank
Poundette===========Clonk
Springer============Shypower
Puppox==============Cyprobot
Li'l Boo============Hi-Boo
Ninja===============Ninjaboy
Cloaker=============Dirt Link
Domino==============Metal Link
Mad Adder===========Mercury Link
Gunyolk=============Lasdun
Shyper==============Forged Shyper
Smithy==============King Smithy

--Credits--
CoolCatBomberMan: Script Editing/Revision
nejimakipiyo: Translation Consultation

--Special Thanks--
giangurgolo & Omega, for creating the Lazy Shell editor.
Tomato, for his very helpful livestream and website.