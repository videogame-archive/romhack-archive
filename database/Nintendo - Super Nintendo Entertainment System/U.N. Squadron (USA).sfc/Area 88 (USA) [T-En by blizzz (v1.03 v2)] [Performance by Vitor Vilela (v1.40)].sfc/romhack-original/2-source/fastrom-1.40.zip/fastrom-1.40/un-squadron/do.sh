rm squadron.sfc; cp squadron_base.sfc squadron.sfc && asar -Dstrict=1 main.asm squadron.sfc
