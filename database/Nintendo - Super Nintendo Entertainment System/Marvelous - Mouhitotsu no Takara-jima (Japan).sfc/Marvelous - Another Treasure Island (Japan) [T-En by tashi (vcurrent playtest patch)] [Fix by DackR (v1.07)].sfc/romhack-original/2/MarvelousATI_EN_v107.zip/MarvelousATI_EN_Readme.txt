﻿
=====================================
Marvelous ~Mouhitotsu no Takarajima~
マーヴェラス 〜もうひとつの宝島〜
=====================================
Marvelous ~Another Treasure Island~
=====================================
English Patch - DackR
=====================================
Version 1.06
=====================================

After a year of toil, here it is.

All non-english script bits have been translated, 
and Tashi's script has been edited.

All event graphics are hacked and translated.

EVERYTHING should now be translated.

Tashi's Original patch can be found here:
http://www.romhacking.net/translations/2006/

If you find any bugs, please report.
I can be found through PM on romhacking.net.

Please enjoy!

v1.07 Note:
A bug was found that effects the ending screen of the game. This was caused by 
a compression glitch related to relocating the graphics for the colonel's note. Special thanks to 
@terminator2k2 (christian) for bringing this to my attention!

v1.06 Note:
This release is to address an issue with patching a ROM previously patched with Tashi's translation. 
I must have been using an earlier or later build. As a side-effect, I've built in some fixes for 
script glitches reported by Sabin Stargem. Thanks again!

v1.05 Note:
I've revised the final rankings so that they only take 2 lines. The third line is reserved for "The End!"
Mavericks cave map shows as garbage. Relocated and corrected data. Fixed.
A puzzle on Maverick's ship should be "8+8-3=". Fixed.
Made a few small fixes to the script concerning random typos.

v1.04 Note:
During Jim's "Don't Be Unlucky" mini-game, there were minor graphical glitches at the corners of the screen. Fixed.
Talking to the boy on the right during the PK Shootout caused the dialogue to glitch. Fixed.
When pulling the Monkey's various bits, you can get a reaction where it becomes angry and pushes away the player.
I had missed the fake monkey's angry response. This is now translated.
THANKS TO Sabin Stargem!

v1.03 Note:
When using the Save&Quit option, some kanji was displaying after saving. Fixed.

v.1.02 Note:
Fixed ROM Size-- Now matches Tashi's patch.
Fixed ROM's internal checksum.

v.1.01 Note:
Fixed game-breaking bug when opening treasure chests.

----------------
Included Files:
----------------
./Tashi/MarvelousATI_EN_Tashi_v1.07.xdelta
./Tashi/MarvelousATI_EN_Tashi_v1.07.ips
./MarvelousATI_EN_v1.07.xdelta
./MarvelousATI_EN_v1.07.ips
./MarvelousATI_EN_Readme.txt

----------------------------
Unpatched ROM Checksum Info
----------------------------
CRC-32: cedf3ba7
   MD4: 0a0e567efe37fc2e0adc5c717ebcf315
   MD5: b9b77e5f378b871ece75caba82718a8e
 SHA-1: 46fe42f195d43b71ba0608356eb7c2b65bff70ac

------------------------------------
Tashi's English Patch Checksum Info
------------------------------------
CRC-32: 815053c0
   MD4: c43a07c71568a4e26193f1add92d8c14
   MD5: 55cc5f08f1f0891269e6ffcc8d67ca58
 SHA-1: 4721a3b1825c488153980b07f76df13f4f1158d8

---------------------------------
Version 1.07 Patch Checksum Info
---------------------------------
CRC-32: 092a9db9
   MD4: 3359fbcbf32e841de3314a5e8debfa03
   MD5: d9ac315caf3cd20c7e5b638625b0fa4a
 SHA-1: 5ba071614dff1c0b131e56af625a7e5e3f60000c

------------------------------             
Original ROM Common Filenames
------------------------------
Marvelous (J).sfc (GoodSNES v0.999.5) 
Marvelous - Mouhitotsu no Takara-jima (NTSC)(Jap)(1.0).sfc (Zapatabase 2011-01-30) 
Marvelous - Mouhitotsu no Takara-jima (Japan).sfc (No-Intro 2011-12-24) 
Marvelous - Mou Hitotsu no Takarajima (Japan).sfc (No-Intro 2011-xx-xx)

--------------------
Patch Instructions:
--------------------
-Use an unmodified, unheadered ROM (or a ROM patched with Tashi's patch). 

-Your choice of included xdelta or ips to patch.

-xdelta UI or FLIPS are recommended patchers.