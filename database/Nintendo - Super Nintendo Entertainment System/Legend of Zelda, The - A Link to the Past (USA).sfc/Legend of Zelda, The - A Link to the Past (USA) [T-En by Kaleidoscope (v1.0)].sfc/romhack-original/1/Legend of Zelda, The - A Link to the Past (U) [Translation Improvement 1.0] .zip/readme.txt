A Link to the Past Translation Improvement by Kaleidoscope. 

This is a text hack of A Link to the Past, changing mistranslated/awkwardly phrased/censored lines to be closer to their Japanese translations as well as easier to read using a literal retranslation and the GBA script.

Thanks to the creators of Hyrule Magic for a program that allowed me to edit the text.