______________________________________________________________________

 Secret of Mana : VWF Edition (SNES)
 Font & Text Enhancement Patch
 February 9, 2000
 Version 1.00

 FuSoYa's Niche
 http://www.crosswinds.net/~fusoya/
______________________________________________________________________

 CONTENTS
______________________________________________________________________

 1. Credits
 2. Description
 3. A Small Warning...
 4. Legal Notice
 5. Contact Information

______________________________________________________________________

 1. Credits
______________________________________________________________________


 ROM MODIFICATIONS:     FuSoYa (Defender of Relm)

 BETA TESTING:          Sailor P3RX1

 THE USUAL SUSPECTS:    ZSNES debugger, Yoshi's disassembler, Jeremy
                        Gordon's 65816 assembler, Naga, Borland's C++
                        5.02 package.

______________________________________________________________________

 2. Description
______________________________________________________________________

 This patch is a slight enhancement of Secret of Mana, born out of a
 desire to improve the text somewhat from the stretched font Square
 used.  A VWF has been implemented, the ROM and story text pointer
 table expanded, and the story text has been rewritten slightly to
 take advantage of the extra space.

 In other words, it looks better and seems more wordy. ^^


______________________________________________________________________

 3. A Small Warning...
______________________________________________________________________

 Due to the large number of different SoM ROMs that I suspect may be
 out there, I feel it's necessary to stress that this particular patch
 is intended for the American version 1.0 ROM _with_ the standard
 0x200 byte header. If you encounter problems with the patched ROM, I
 suggest you verify the above attributes with SMC.COM.
 Also use it to check that your ROM has a checksum of 20988 (dec).
 Note that this checksum will be the same for both the patched AND the
 unpatched ROM! If it doesn't have that number, then I recommend you
 find one that does.


______________________________________________________________________

 4. Legal Notice
______________________________________________________________________

 The Secret of Mana VWF Edition Patch (hereafter referred to as the
 "Patch") is not official or supported by Nintendo, Square, or any
 other commercial entity.

 The Patch is freeware thus it can be distributed freely provided the
 following conditions hold:(1) This document is supplied with the
 Patch and both the document and patch are not modified in any way
 (2) The Patch is not distributed with or as part of any ROM image in
 any format, and (3) No goods, services, or money can be charged for
 the Patch in any form, nor may it be included in conjunction with any
 other offer or monetary exchange.

 The Patch is provided AS IS, and its use is at your own risk. Anyone
 mentioned in this document will not be held liable for any damages,
 direct or otherwise, arising from its use or presence.
 

______________________________________________________________________

 5. Contact Information
______________________________________________________________________

 FuSoYa
   www:   http://www.crosswinds.net/~fusoya/
   ???:   06942508

______________________________________________________________________
