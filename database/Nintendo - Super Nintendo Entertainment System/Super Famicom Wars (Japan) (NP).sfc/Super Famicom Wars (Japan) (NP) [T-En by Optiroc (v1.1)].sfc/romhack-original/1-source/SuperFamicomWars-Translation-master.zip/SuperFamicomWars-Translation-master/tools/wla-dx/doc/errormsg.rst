Error Messages
==============

There are quite a few of them in WLA, but most of them are not as informative
as I would like them to be. This will be fixed in the future. Mean while, be
careful. ;)