Fire Emblem 4: Genealogy of the Holy War
English Fan Translation
Beta Version 7, released July 7, 2016
========================================


Foreword
========
This is an unofficial work and is not supported by Nintendo.
Please do not sell, trade, or rent this translation for money, goods, or services.
This translation is the result of many years of volunteer work,
and is being provided for free as a gift to all FE and gaming fans.


Version History
===============
b7 - July 7, 2016
- Reverted prior "fix" for Sol as it was causing countless bugs with HP calculation.
- Arena level-up bug should now really be fixed this time.
- Intro graphical text has been cleaned up to remove artifacting.
- Additional script revisions added.
- Activating Adept with a negative attack speed should no longer freeze the game.
- Temporarily added a check for Hawke in the epilogue, implementation may change in a future release.

b6 - June 6, 2016
- All reported (and some unreported) typos fixed.
- Missing dialogue blocks added for Ishtore and Reptor.
- Fixed broken Welcome Home castle dialogue.
- "Return ring" renamed to "Return band".
- Musar's name fixed for Ch. 9 Status menu.
- Ced Speed bug fixed; Str/Mag/Skl/Spd/Def/Res inheritances capped at +15.
- Arena level-up bug fixed; Only fixes the growth rate overflow,
    it's still technically possible to have a zero stat level-up if you're unlucky.
- Sol HP display bug fixed; Sol with a Brave sword heals for both hits,
    but finishing blows only heal for enemy's remaining HP.

b5 - May 19, 2016
- Prologue villager chats and DiMaggio's speech display text window at bottom as intended.
- Quan/Ethlyn/Finn departure speech in Chapter 4 displays properly.
- Fixed punctuation/typos/spacing from the various reported screenshots.
- Hawke/Banba/Mabel/etc. death speeches should display their original portraits again.
- Fixed the Circlet item not clearing the whole item description window.
- Fixed Sakra's arena name being garbled.

b4 - May 15, 2016
- Fixed broken opening demo
- Fixed enemy names in Status menu
- Fixed unit names for Chapter 5 Unit/Items/Skills menus
- Fixed dialogue windows not displaying translated text
    (Holyn's recruitment, Quan/Ethlyn retreating, Sigurd/Eldigan speech)
- Added "x gold stolen" message for Rogue enemy unit
- Cleaned up Intro and Chapter Title graphics
- Fixed reported typos

b3 - May 14, 2016
- Fixed blank castle shop names when entering a captured castle
- Fixed various dialogue window text overflows
- Modified some skill descriptions

b2 - May 14, 2016
- Last minute changes

b1 - May 14, 2016
- Initial release


Instructions
============
The image file that the project has been based off of is known in GoodSNES
as "Fire Emblem - Seisen no Keifu (J)" with a CRC32 checksum value of DC0D8CF9.
If a file with a different checksum is used,
various unsupported bugs may occur during play.

If the file contains a header, the file size should be 4,194,816 bytes.
And the patch file you should use is either the "for_headered_rom.ips"
or "for_headered_rom.xdelta".

If the file does not contain a header, the file size should be 4,194,304 bytes.
And the patch file you should use is either the "for_unheadered_rom.ips"
or "for_unheadered_rom.xdelta".

The .ips files can be used with any various IPS patching utilities.
I have personally used Lunar IPS and find that it works very well.

The .xdelta files are for use with the DeltaPatcher utility,
and are provided as an alternative method for patching.

If you are using an emulator that supports "soft-patching", which allows
a file to be modified in memory during run-time but leaves the original
file intact, please follow the instructions that should be included with
that emulator in order to do so.


Credits
=======

Fire Emblem 4 Translation Team
------------------------------

[Japanese to English Translation]
bookofholsety
gringe
amielleon

[Graphics]
AzimuthFE

[Programming]
DDSTranslation

[Special Thanks to]
Nintendo, for creating this game in the first place
J2E, for pioneering the first translation and providing a valuable resource for this project
MP2E, for his efforts to Project Naga
