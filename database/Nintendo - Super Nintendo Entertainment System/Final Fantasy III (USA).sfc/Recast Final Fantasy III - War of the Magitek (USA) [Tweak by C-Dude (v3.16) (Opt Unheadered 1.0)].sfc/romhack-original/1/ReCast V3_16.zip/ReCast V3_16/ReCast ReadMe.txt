===============================
ReCast FF3: War of the Magitek
ReadMe
===============================
	Patches are for FF3 US 1.0
	N is unheadered, H is headered.
	Do not patch over an old version.

ReCast is a 'stand on shoulders' vanillish hack.  Basically, I took a bunch of things
that other modders developed and put as many of them together as I could.

> Bug Fixes
> NPC Changes
> Script Changes
> Mechanic Tweaks
> Character and Enemy Graphics

Of the things mentioned above, there are four tent poles I used as a base:

> Ted Woolsie's Uncensored Edition 2.01 
	(by Rodimus Primal)
> Divergent Paths
	(by Power Panda)
> C.V. Reynold's Comprehensive Bugfix Compilation
	(Which will be credited below)
	[Only to C3:FFFF]
> FF6 Hacking Sprite Database 2017
	(by Madsiur, itself a compilation of dozens of graphic artists, who will be credited later)
	
More characters learn natural magic.  Many of the characters have altered graphics and characteristics.
Banon is now a fully playable character (without a game-over condition, too!).
The plot and script have also been adjusted, but remain roughly vanillish when compared against the original.
Lastly, enemy graphics were changed and tweaked to be ridiculously tiny
(scaled relative to the player sprites, rather than dwarfing them as gigantic Romance era paintings).


----------
Disclaimer
----------
The contents of these patches are presented as-is.
I am not responsible in the event they are used incorrectly and damage to save files, files, or your computer results.

ReCast was developed with SNES9X and may have emulator issues with other emulators.



=============================
Credits
=============================

-------------------------
Patches, Script, and Code
-------------------------
Angelo
ArmorVil
Assassin
Bropedio
B-Run
bydoless
Catone
C-Dude
C.V. Reynolds
darkmage
Djibriel
Dragonsbrethren
DrakeyC
Drakkhen
Everything
Gens
Gi Nattak
GrayShadows
Hatzen08
Imzogelmo
Kejardon
Leet Sketcher
Lenophis
Leviathan Mist
Lord J
Madsiur
Master ZED
mblock129
myself086
Novalia Spirit
Power Panda
Rodimus Primal
Ryo_Hazuki
Serity
SilentEnigma
Synchysi
Terii senshi



-----------------------
Bug and Balance Reports
-----------------------
Alby4t5
Fathlo23
GI Nattak
Lockirby2


-----------------
Custom Spritework
-----------------
Astaroth
Badass
"Beyond Chaos" collection
C-Dude
CrumpledMedal
DrBlank
"Eternal Crystals" collection
JamesWhite89
Junjinka
Pocoloco
Koreki
Kugawatten
"Rise of the Dark Sorcerer" collection
Rjenyawd
Sapprentice
SmithyGCN
Sutebenukun
Tinman
Tsushiy
Zeemis
Zozma


--------------
Sprite Ripwork
--------------
AirShuffler
Bean
Blue99
CaptainChomp
Daemoth
Davias
Dazz
Indogutsu
JirbyTaylor
Madruga
Nemu
Ragey
Ryan914
Satoh
SixFootBlue
Spindaboy
Tenbuki
Tonberry2k
Ultimecia
ValocDarkmire
Vanarus
Volo



=====================
Questions and Answers
=====================

--------
Gameplay
--------
Q: My hack crashes/goes to black screen.  Why?
	A: I'm unaware of any emulator incompatibility, but the hack was made for SNES9X.  Try playing it on that.
	   Alternatively, it's possible you've applied a headered patch to an unheadered ROM or vice-versa.
	   It is important to note that this hack is built off of the US 1.0 version of FF3SNES, the one
	   that doesn't have the Sketch bugfix from later releases.  If you try to apply this patch
	   to the japanese version of the game or to the US 1.1 version, it WILL NOT WORK.

Q: There's this pause at the end of battles, and my characters are trying to attack nothing.  Why?
	A: One of the battle mechanic features added in this patch requires an invisible enemy to manage it.
	   When all other enemies are defeated, this enemy enters an action in the battle queue to self-terminate.
	   Any actions queued before that termination will go through, using MP and items and doing basically nothing.
	   You can use this little pause at the end of battle to toss a healing ability or revive a fallen ally.
	   If your CONFIG is set to WAIT mode, you can also menu at the end of battle to equip/unequip someone,
	   which might be useful if your equipment is sparse and you're passing it from party to party.

Q: Locke is stealing over and over from enemies.  Is this intentional?
	A: Yes, enemies now have an inexhaustable amount of their common steal item.
	   This is so that Locke can "save criticals" by stealing items and throwing them later.

Q: Edgar's doing crazy damage to birds.  Why?
	A: Spears are wind element so that they're effective against flying enemies.

Q: Locke's doing crazy damage to mechs.  Why?
	A: Daggers are earth element so that they're effective against machines.
	   
Q: How do I get Edgar to stop covering an ally?
	A: Use the Cover command on Edgar himself to remove it. It's also removed on death and upon being moogled.

Q: I'm stuck in battle but the enemies are dead.  What do I do?
	A: It will take a moment for the invisible enemy that handles some of the extra mechanics.
	   Make sure you're not in a spell or item menu if Wait mode is on.
	   If there's a character up, have them defend (It might be you've got quick turns to resolve).
	   Banon's Command will grant him one turn of quick, so he's a likely cause of this pause.
	   
Q: These enemies hit hard!  What's up with that?
	A: The damage formulas have been changed to give physical attacks a fair shake.
	   As a result, enemies hit for a lot more damage than they used to.
	   This hack tries to ease you into this extra damage gradually, and there are many ways
	   to mitigate it and recover from it.  Use the back row to your advantage: magic is of
	   full effectiveness and physical damage is halved, both against and for you.
	   You can afford to button mash only as far as Mt. Kolts.  If you don't start to
	   strategize, if you don't use items and relics, the game will really start to hurt
	   around Mt. Kolts.
	   
Q: What's with the haste sound red swirl occasionally covering a monster?
	A: Soon after you meet Edgar, you will start seeing this. It is a mechanic to help you identify a monster's status.
	   A warded enemy has Shell, and glows green
	   A protected enemy has Safe, and glows yellow
	   A mirrored enemy will glow blue
	   A hastened enemy will glow red
	   A slowed enemy will glow white
	   A frozen enemy is stopped, and will sparkle blue
	   A sleeping enemy will have pillow feathers flutter around them
	   A blinded enemy sees dancing lights
	   A berserk enemy sees red chocobos
	   A muddled enemy sees regular chocobos
	   A muted enemy is sometimes surrounded by magic seals
	   A miraged enemy has the Smoke spell protecting it, and is hidden by eyes
	   An undead enemy will target randomly, sometimes attacking its own allies.  Fallen angels dance around them.
	   There will be a brief pause at the end of battle while the mechanic that handles this system cleans itself up.
	   If you're fast, your last commands in a fight will go through.  This can be a waste of MP or a chance to heal/revive, plan ahead!
	   
Q: Zombie doesn't seem to be doing anything. Why?
	A: Zombie inverts healing on the character and will from time to time make them
	   toss their targetting and attack whoever. This is most likely to occur when
	   the zombie attacks a target who has become invalid, like a dead monster.
	   Special moves like Blitz and Bushido are incredibly dangerous to use while zombied!
	   
Q: Where's the Holy Water?
	A: It's gone, you have to use a remedy or a spell to remove Zombie.

Q: I can't leap on the Veldt!  Why?
	A: Unequip Gau's Cummerbund.
	
Q: I keep running into a boss I can't beat on the Veldt!  What do I do?
	A: Either leap the boss to skip it, or soft-reset.
	   Soft resetting with L+R+Start+Select will change the veldt battle index.

Q: What do CzarinaRing and CzarSignet do?
	A: If you get to critical health, they will fully heal and remove some status effects.
	   This can only happen once per fight. It WILL trigger and do nothing if a lit fuse
	   reaches 0, so Soothe that counter!
	   
Q: What do the Imbue moves do?
	A: The first four (the elemental blades) change the target's weapon element, as well
	   as the spell that will be proc'd when they use the fight command.  They also
	   set proc rate to 100%.
	   Heal Orb will restore HP and remove a few key statuses.  It CAN be used
	   on a wounded target.
	   Clean Edge removes the effect of the elemental blades.
	   Trance sets some beneficial statuses and will trigger the Morph state later.
	  
Q: I input a blitz and Sabin just sort of splashed green energy.  What was that?
    A: That's the failed blitz.  It restores a little HP and removes a random status
	   as a consolation, instead of just saying "Failed Blitz Input!"
	  
Q: Why does the Hound command stink?
    A: You need to walk the dog!  Interceptor's power will increase the more steps you take.
	
Q: I queued up Runic twice and it doesn't work, what the hell?
    A: Runic is now permanent until Celes dies, is dispelled, or is moogled.  The pink pulse
	   will let you know when it's active.  Yes, it stays even after she's caught a spell.

Q: Rage keeps canceling, what's up with that?
    A: Each Rage order only lasts for two turns.  Only rages induced by other means
	   (like the Wildstyle lore) last until death.  This is actually a huge buff
	   to Gau, as you aren't locked in to two moves for an entire fight.

Q: I tried to set up Retort on Cyan and it didn't work.  Why?
    A: Cyan's second Bushido has been replaced with Thwart.
	   Thwart does very little damage, but will inflict the Fearful status.
	   No enemy had protection against this status, which halves a target's damage output.

Q: What the heck is Jujitsu?
    A: Jujitsu is a very special new command.  It randomly selects two rages and
	   executes them back-to-back.  It can be extremely powerful depending on how
	   the user is equipped.

Q: Why does Sketch suck?
    A: Like Vanilla, Sketch uses the target monster's stats instead of Relm's stats.
	   Unlike Vanilla, I've tried to change the moves it calls to be more effective
	   against the enemy sketched.  There's a LOT of Sketch data and I can't guarantee
	   each monster got a worthwhile change to their moves.  Sketch is most useful
	   as a mercy command when Relm is needed in the party but underleveled.



-------
Spoiler
-------
Q: Is Zonezeek in the auction house?
	A: No, you get Zonezeek automatically later in the scenario.  You can't miss him.
	   Golem is still there, and can be bought from the Jeweler after the Magitek Factory.
   
Q: I used Trance to morph Terra and the meter isn't counting down. Why?
	A: Trance grants two turns of Morph.  After the second turn, Terra will revert automatically.
	   Morph still doubles damage to anything that doesn't ignore defense (so no double healing).
	   You can use Trance as much as you like in battle, but if used while Morphed it will not extend its duration.
	   
Q: I'm worried about missing rages! Where are they?
	A: There are a few rages that can be missed in the World of Balance.
	   As long as you've encountered a rage enemy (even if you ran away), it will be on the Veldt.
	   If you're up to the floating continent, it might be time to start looking for rages.
	   Hare is known on recruit.
	   Wolf is known on recruit.
	   Raven is in the forests outside Narshe.
	   Bear is encountered during the Narshe attack.
	   Mechanic is encountered in the caves of Narshe, often alongside bats.  Only blue mechanics count.
	   Brawler is in the cave interiors on Mount Kolts.
	   Commander is in the Imperial Camp and must be fought.
	   Hazer is on the Phantom Train and (rarely) in the Narshe secret passage.
	   Lizard is first encountered on the floating continent, and is on the world map in the World of Ruin.
	   Rhino is in the fields around South Figaro and Nikeah.  It will be very hard to find on the Veldt this early, though.
	   Shark is in the Serpent Trench.
	   Frog is in the World of Ruin, near Albrook or Mobliz.
	   Knight is in the World of Ruin, in South Figaro Pass.
	   Spy is in the Cave of Phantom Beasts and on the Floating Continent.
	   Ronin is in the World of Ruin, in Cyan's Dream and other places.
	   Slicer is in the World of Ruin, in the first room of Setzer's Tomb.
	   Adamanchyt is in Troika's sacred mountain interiors, while searching for the espers.
	   Coeurl is on the Floating Continent.
	   Dragon is on the Floating Continent.
	   Fenixi are found in the World of Ruin, in the Narshe secret passage and snowfield.
	   Enuo is in the World of Ruin, in the ancient caves below Figaro.
	   Tanuki is in the World of Ruin, in the Fanatic's Tower.
	   Siegfried is on the Phantom Train, and also can be found in the World of Ruin in Phoenix Cave (event). 
	   Vargas is fought many times, but only Vargas 3 counts as a rage.  He is found in Dino Forest in the World of Ruin.

Q: Wait, so which of those are missable rages?
	A: Raven, Rhino, Ninja, Adamanchyt, Coeurl, and Dragon are missable.
	   Brawler, Hazer, and Shark are hypothetically missable, but it's extremely unlikely.
	   
Q: I'm worried about missing lores! Where are they?
	A: There aren't any missable lores, but you might have trouble getting Meteor.
	   Keep Strago alive!  Use Thaumium and Cherub Down if you have to.
	   All other lores can be learned from Dark Force in Kefka's Tower, if missed elsewhere.
	   
Q: Biggs is changing clothes when I talk to him.  What's going on?
	A: If you told Biggs to keep his uniform after the banquet, he will put it on before he speaks with you
	   on the airship.  If you told him he could take it off, he won't do this.

Q: How do I save Cid?
	A: You can't.  Cid's death is a mandatory part of the story now.  Feed him BootFish to make it go the fastest.

Q: I'm stuck in ruined Mobliz.  Why?
	A: Terra said she's going to go hunting.  Leave the village and fight some battles, then come back.

Q: I'm stuck in ruined Doma.  Why?
	A: Go into the barracks and take a nap.

Q: I'm stuck in Dragon's Neck Colosseum.  Why?
	A: Talk to everyone.  You'll need to bet a specific something to move on.
	   You can get what you need for the betting chain from the general store.

Q: I'm stuck at the bottom of the Art Gallery Stairs.  Why?
	A: Turn the lights on!

Q: Mount Zozo's rusted shut.  Where do I go?
	A: Makes sure you spoke to Lola and sent her reply via carrier pigeon.
	   She will not ask you unless you've acquired Starlet.
	   You then need to talk to the merchant and buy the rust rid.

Q: I'm stuck in Mount Zozo.  Why?
	A: Open the locked chest.  The key can be found on the cliff.

Q: The raiders won't leave Nikeah Bar.  Why?
	A: You need to finish the events in Tzen first, and then make sure
	   to talk to ALL of the raiders in the bar.
	   
Q: Siegfried is attacking me from behind!  Why?
	A: You are in the World of Ruin.  Siegfried will consider you worth
	   fighting for real after you've survived the Floating Continent.

Q: Chasm is so unfair!  Why?
	A: It's to create a sense of urgency during certain fights.  To be fair, there are only
	   a few spots 'of airship height' at which a chasm attack can occur...
	   The IAF sequence (if a certain enemy is left alone on screen)
	   The Floating Continent (if a certain enemy is left alone on screen)
	   Solitary Isle (the actual chasms destroying the land)
	   The Falcon's deck (Doomgaze fight)
	   The Fanatic's Tower (L100 Magic fight)
	   The Opera (Ekauq fight)
   
Q: Meteor is so unfair!  Why?
	A: Meteor has a chance to inflict instant death.  Stack magic evade to increase your chances.
	
Q: Doomgaze is so unfair!  Why?
	A: Inflict some statuses on him!  His attacks can be limited by being blinded, burned, or slowed.

Q: What does the Offering do?
	A: Gives Terra double-cast, makes her absorb Fire, and halves magic costs.
	
Q: What does the MoogleCharm do?
	A: Gives Mog double-cast, makes him absorb Bolt, halves magic costs, and halves the encounter rate.
	
Q: What does PrismPaint do?
	A: Gives Relm double-cast, makes her absorb Water, and halves magic costs.

Q: What does the IceHeart do?
	A: Gives Celes double-cast, makes her absorb Ice, and halves magic costs.
	
Q: What does the MagiBrooch do?
	A: Among other things, gives Strago x3 attack.
	
Q: What does the Train Ticket do?
	A: Changes Banon's "Command" to "Boko", and makes him immune to instant death attacks.
	
Q: What does Dragoonite do?
	A: Changes Edgar's "Cover" to "Jump".
	
Q: What does the Cummerbund do?
	A: Protects Gau against a lot of statuses, and changes "Rage" and "Leap" to "Fight" and "Jujitsu".  Unequip it on the Veldt to leap.

Q: Hahaha, I can equip two weapons in the battle menu.
	A: That's not a question.
	
Q: Okay, fine. Why can I do that?
	A: The battle inventory is complicated and I couldn't get it to restrict the Genji Flag. Rather than block it completely,
	   I decided to leave it in as an easter egg. You can use the battle menu to access some high-power strategies, like
	   fingerpainting with Relm or running dual-flails on Sabin.
	   
Q: I can't get the cliff Esper to fight me.  What do I do?
    A: Who's in the ice?  Bring his daughter in your party.
	   Maduin will not attack unless Terra is present.	   

Q: Why did you take away Edgar's tools?  You ruined him!
    A: Tools trivialize most of the World of Balance.  Edgar was easily the best character for the first half of the game in Vanilla.
       I tried to limit multi-target attacking in the early game so that players would actually fight the monsters and learn some of
       the mechanical changes.  That meant that Edgar had to be nerfed in the offense department.
       Used strategically, Cover can be quite effective at preserving your resources in the early game.  It is especially effective in
	   mitigating status special attacks: you can give Edgar protection relics and have him block things like poison and blind for other
	   party members.  Cover does fall off later as enemy magic attacks become more prevalent, which is why you're handed Dragoonite
	   for Edgar to change it into Jump early in the World of Ruin.
	   
Q: Why do Darryl's weapons and the Tools have the same icon?  I thought they were throwable, you wasted my Gil!
    A: I expanded the table of icons, but not enough to make room for a separate icon to distinguish Darryl's tool weapons
	   from her tool command items.  I made the weapons throwable for flavor, but it did not occur to me that players would
	   assume they were all throwable and buy them in favor of clear throwables like Deuces and Aces.
	   Regrettably I have not yet been able to address this problem, so I apologize.  Here's a hint to get your money back:
	   Turn the Gil.Speed up, go to Zozo, and attack the pirates with Locke.  They'll counter by trying to steal.  When you
	   beat them, you'll get back a LOT more Gil than they stole.
	   
Q: What's with the chocobo/elevator/crane/raft graphics?
    A: I had to make a lot of sacrifices on sprites to standardize the palette structure.  I know this doesn't mean much
       to somebody who isn't a FF6 hacker, but the game can only show eight field palettes for characters at a time.  It
	   usually gets around this limitation by swapping out the last two palettes here and there for area-specific objects,
	   including the Chocobo.  To make those palettes usable for generic townfolk and player characters, I had to simplify
	   the graphics so that that palette swapping was no longer necessary.  This meant that the player party would only
	   have to share two characters to one palette, but it also meant abandoning any kind of dithering and limiting
	   gradients to three colors max.  Sprites with a lot of gradient colors and dithering, like the chocobo, suffered
	   due to this change.
	   
Q: You changed the Blitz inputs, what on Earth could have possessed you to do that?
    A: When I first changed the inputs, it was out of frustration for the diagonal requirements.  I have since learned
	   that the game simply ignores diagonal inputs and takes either contributing direction as a correct button press.
	   Still, I wanted to remove them and I wanted the Blitzes to be different but easy to remember.
	   As such, each Blitz builds on a series of button press components from earlier Blitzes.
	   Those components are XY, LR, ^v, and <><.
	   
Q: Relm can equip two paint brushes, why would you ever use a palette?
    A: You're asking the wrong question.  Relm can equip two palettes, why would you ever use a paint brush?
	   Relm's physical attacks are mediocre.  All of the special proc maneuvers are on the palette weapon,
	   which is meant to be her 'shield'.  They let her steal MP from the enemy party to fuel her much more
	   potent magical attacks, and they can also proc their corresponding spells over and over again.
	   Let's also not overlook the evasion bonus, which can became quite substatial with two palettes.
	   This is the aforementioned fingerpainting strategy.
	   
Q: I saw a video where Terra was using the MTek fire beams, what happened to that?
    A: That was version 1.  I was trying to make her more balanced by giving her a unique ability
	   that harkened back to the mage knights of Final Fantasy 5.  Admittedly she's lost some power
	   there, but you can make it up by pairing her with a strong two-weapon attacker, as she'll
	   force them to proc the selected spell twice per attack.