Apply dkc_3_msu_Europe.bps on Europe Donkey Kong 3 rom (Donkey Kong Country 3 - Dixie Kong's Double Trouble! (Europe) (En,Fr,De).sfc)

Note bps needs flips:
https://dl.smwcentral.net/11474/floating.zip

Rename into dkc3_msu.sfc

Store dkc3_msu.msu and the pcm into this folder