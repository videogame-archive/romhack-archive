Magical Quest 3 starring Mickey & Donald (Snes)
Nephew Colors Hack v1.0


Change Donald's nephews to their well known colors - Huey is red, Dewey is blue and Louie is green.

Disney archivist Dave Smith once said, "Note that the brightest hue of the three is red (Huey), the color of water, dew, is blue (Dewey), and that leaves Louie, and leaves are green."


You need to apply this patch onto a non-interleaved ROM with NO Header (Rom Checksum: 2F36, CRC32: 32EEA1E9, Size: 2,097,152 bytes).


Jonny
