LITTLE MAGIC (SFC)
ENGLISH TRANSLATION V1.00B
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Little Magic
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions

--------------------
1.About Little Magic
--------------------
Little Magic is a nifty little puzzle game along the lines of The
Adventures of Lolo! This patch is for the Super Famicom version of
the game; you may be familiar with the Gameboy Color one which SGST
translated.

---------------
2.Patch History
---------------
The Little Magic project started a little over a month ago. I worked
on it, then it sat on its ass, then I worked on it, then it sat
on its ass, then I worked on it and finished it. Yay.

Please note that this patch is a BETA insofar as that I THINK everything's
done, but I haven't been able to beat the game to verify that I didn't
screw up the ending in some way. If someone manages to beat the game,
please donate a savestate just before the ending. Thanks!

September 23, 2001 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE LITTLE MAGIC TEAM
Gideon Zhi - Project leader, lead romhacker
Tomato - Translator
Zackman - Translator

--------------
4.Known Issues
--------------
No known issues.

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "lilmagic.smc" make sure the patch
is "lilmagic.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
a header. If you right-click the ROM and select Properties, it
should read "Size: 512KB (524,800 bytes), 528,384 bytes used".
