This is FASTROM for Soreyuke Ebisumaru Karakuri Meiro - Kieta Goemon no Nazo!! (J)

It is fully compatible with the English translation patch.

MISTER cheats supplied for both!

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5