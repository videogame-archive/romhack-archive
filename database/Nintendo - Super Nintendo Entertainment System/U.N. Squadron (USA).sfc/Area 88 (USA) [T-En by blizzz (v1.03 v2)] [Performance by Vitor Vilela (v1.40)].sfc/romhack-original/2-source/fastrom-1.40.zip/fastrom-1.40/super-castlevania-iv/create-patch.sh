./do.sh
flips sc4_base.sfc sc4.sfc patch.bps
