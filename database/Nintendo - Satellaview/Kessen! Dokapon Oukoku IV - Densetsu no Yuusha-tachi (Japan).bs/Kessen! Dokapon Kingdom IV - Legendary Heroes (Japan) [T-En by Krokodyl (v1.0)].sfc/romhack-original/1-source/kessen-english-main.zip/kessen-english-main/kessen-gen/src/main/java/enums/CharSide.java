package enums;

public enum CharSide {

    ONE,
    TWO
}
