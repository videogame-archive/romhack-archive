rm axelay.sfc; cp axelay_base.sfc axelay.sfc && asar -Dstrict=1 main.asm axelay.sfc
