A set of optional patches for Updated Wizardry I-II-III: Story of Llylgamyn fan translation

IBM PC Item Names: Converts all weapons/gears/item names based upon from IBM PC or MS-DOS releases

Apple II Item Names: Converts all weapons/gears/item names based upon from original Apple II release

They must be applied -on top- of the updated translation

Known issue:
- Item Names: The Knight of Diamonds starter shields remain unaltered due to shared strings with unidentified Shields for Large Shield, while Small Shield leaves unchanged as Buckler