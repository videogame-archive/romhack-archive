**- Gundam Wing Endless Duel FastROM and Flashing Lights Reduction Test Patch -**

**Superficial Changes**
  Vayeate stage music changed
  Wing Zero now has a unique stage based on the first fight between Wing Zero and Epyon (Shenlong stage with a unique palette).

**Purely Lag-Reducing Adjustments**
  FastROM flag enabled and most relevant addresses changed.
  Landing dust particles removed.
  Wing Zero's qcfP fireball hitdust effect changed to generate less dust.

**Current Flashing lights changes**

**Intro:**
  Removed the flashing yellow background when Tallgeese enters.

**Epyon stage:**
  Background blue/yellow flash: Increased cycle duration.
  Lightning: Slight slowdown of palette cycle rate.
 
**Continue screen on start press:**
  White background flicker color muted (turned to dark red).
  Color cycle time heavily increased.

**Character Select:**
  Character description background flicker removed.
  Original darker flicker color used for unselected character.
  Brighter flicker color used when character is selected.

**Options:**
  Green background flicker removed entirely.

**Match:**
  Static effect slightly darkened on Mission start/end text.
  Lifebar green flicker removed.
  Lifebar low health red and yellow flicker is now just red.
  Passive ammo meter flicker removed.
  Target reticle for vulcans is a solid orange instead of alternating red and yellow.
  Super background flicker no longer flickers and color changed to orange.
  Player orange death flash removed.
  Victory blow full-screen flicker now stays a solid blue color.
  Spark effects removed.
  
Tools used:
  Bizhawk 2.7 and the BSNES core (ROM edits saved as cheats)
  Notepad++ (to manually edit Bizhawk .cht file or alter chunks of ROM manually)
  HxD (copy/pasted Bizhawk CartROM into HxD and saved)
  FloatingIPS (to create the patch)
  Advanced SNES ROM Utility (to calculate checksum)
  SNESLabs.net as an information resource.
Thanks to:
  Eric from the Gundam Wing: Endless Duel Discord for helping to find and confirm a fix to a game-crashing bug with AI.
  Survivor for fiddling with and learning unrelated SNES RAM hacking. 
  Zool for learning unrelated general SNES stuff alongside.
  kandowontu for advice and attempting to help teach me to do this the proper way (I still did it the wrong way, but it's very appreciated).
  Beta testers: Eric, tobemorecrazy, pjams and the wichitasnes crew, Rolento13, kandowontu
  Flashing Lights Change Consulting: Eric, Rolento13, Kosheh, pjams, The Prismatic System
  The entire Gundam Wing: Endless Duel community for their support.
  Rabite for no particular raisin.
