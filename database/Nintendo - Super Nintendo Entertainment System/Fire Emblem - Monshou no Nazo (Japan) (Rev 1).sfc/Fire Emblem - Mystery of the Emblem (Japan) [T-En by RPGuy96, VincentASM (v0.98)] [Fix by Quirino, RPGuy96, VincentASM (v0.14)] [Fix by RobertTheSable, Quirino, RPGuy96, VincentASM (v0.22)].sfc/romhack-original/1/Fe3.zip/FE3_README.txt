Fire Emblem: Mystery of the Emblem
Translated by VincentASM
Hacked by RPGuy96
Additional translations provided by Cleteromagos (battle text) and AceNoctali (perfect ending)
Editing help provided by Devon_v and KiddoCabbusses
Version 0.98

Contact Information:
You can find both the translator and hacker at FESS, specifically the Mystery of the Emblem Patch Topic:
http://forums.grandbell.net/index.php/topic,126.0.html

Missing:
Stats for the class scroll

Buggy:
Scrolling Intro (don't press anything for a while and you'll see it)
Various small graphical things.

Now, you might notice that there's actually two patches in this zip file.  That's because there's two versions of Fire Emblem: Mystery of the Emblem.  The first, version 1.0, seems to be the more common.  fe3.ips is based off that version.  Try using that first, and, if you get garbage once the game actually starts, change to the other patch, fe3v11.ips.

NOTE: This patch only works with headered ROMs.  If you don't know what that means, don't worry - chances are your ROM has a header.  If it doesn't have a header, there are numerous tools (the most famous of which is SNESTools) for adding/removing headers.

EMULATOR NOTE: This patch does not work at all with ZSNES 1.42, and ZSNES 1.51 has issues rendering battles with Mystery of the Emblem with or without the patch, though the game is still playable.  Fortunately, BSNES, an emulator with the goal of perfect hardware emulation, runs the patch fine, and there have not been any reported problems with any version of SNES9X.  If you have issues, please check your emulator version.

Enjoy!
