This is for the Japan version of "Magical Pop'n"

Should be compatible with the english translation patch.

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

ANONYMOUS
RC_Meatpuppet
SAM M.