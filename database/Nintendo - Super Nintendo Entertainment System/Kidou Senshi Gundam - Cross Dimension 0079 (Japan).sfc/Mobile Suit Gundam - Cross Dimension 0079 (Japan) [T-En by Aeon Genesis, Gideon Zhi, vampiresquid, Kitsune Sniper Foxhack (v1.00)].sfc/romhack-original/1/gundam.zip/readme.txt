MOBILE SUIT GUNDAM: CROSS DIMENSION 0079
ENGLISH TRANSLATION V1.00
Copyright 2004 Aeon Genesis
http://agtp.romhack.net

ToC

1.About MS Gundam 0079
2.Patch History
3.Patch Credits and Contributors
4.Known Issues
5.Application Instructions
6.Troubleshooting

------------------------------------------
1.Mobile Suit Gundam: Cross Dimension 0079
------------------------------------------
MS Gundam is a sort-of fast paced strategy title based on the very first
animated series. It's what I'd consider to be a "lite" version of the
events -- it covers, at its most extreme, the absolute major points and
missions, but not much else. In that sense, it's sort of "Gundam Lite"
as it were. The characters are fairly flat and the story is extremely
loose with details, and the fact that bosses are wimpy cowards and flee
at the first sign of any damage (after which you're continually forced
to go hunting for them) doesn't help the pacing any, but it's not too
bad of a game, and an interesting surprise awaits those who finish the
main story arc.

---------------
2.Patch History
---------------
I honestly don't even remember when I started working on this one, only
that it looked like an easy project at the time. Once the font width
issue got worked out (and that took -ages-) it -was- an easy project,
which is kinda nice I guess. I'm writing this on three hours of sleep
(followed by six waking hours and an exam) so my cognitive functioning
is slightly impaired, and I don't really remember much about the
project's history other than the past few weeks, which involved getting
the script reinserted, the other assembly junk and miscellaneous graphic
text done, and the playtesting sorted out. Whee.

October 31, 2004 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE CROSS DIMENSION TEAM
Main Team:
Gideon Zhi - Project leader, Romhacker
vampiresquid - Translation

Special thanks to...
...the unnamed person who helped with the font width hack.
...Kitsune Sniper for the great new title screen.

--------------
4.Known Issues
--------------

There are no known issues. If you find any, please post
about them on The Pantheon (http://donut.parodius.com/agtp)

--------------------------
5.Application Instructions
--------------------------
Quick ROM Info:
1.50B (12mbit LoROM), WITH Header (1,573,376 bytes).

If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "gundam.smc" make sure the patch
is "gundam.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
A HEADER!. If you right-click the ROM and select Properties, it
should read "Size: 1.50 MB (1,573,376 bytes)". SNESTool can add
your headers for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
The answers to the questions it asks you do not matter unless you're
using a copier to play the game.

An easy way to tell if the game has a header or not is that if you do
the above and the game does not run, it probably doesn't have a header.
Use SNESTool to add it too a clean Japanese ROM and try again.
And don't whine about SNESTool not working in Windows XP, it works
fine for me and I'm running on XP Pro.

-----------------
6.Troubleshooting
-----------------
--If the game does not run at all, read the above section on
  application instructions (specifically on header addition.)
  Make sure your ROM is not read-only when you add its header.
  Also make sure that if you previously hard-patched the ROM and
  the game crashes as described, you will need to re-apply the
  patch a clean, Japanese original ROM.