---------------------------------------------------------------------------------------
Wizardry I-II-III: Story of Llylgamyn (Super Famicom NP)
2020 Updated English Translation by Hengki Kusuma Adi
---------------------------------------------------------------------------------------

Description:
Wizardry I-II-III: Story of Llylgamyn is a Super Famicom remake based upon the original Famicom version of mainline trilogy and it was released June 1st, 1999 only in Japan for Nintendo Power based cartridges, later in August 5th, 2000, a fan translation of this game was released by Gideon Zhi also known as Aeon Genesis (AGTP) focusing on making it fully playable in English. Since then, I played through the first part with a translation patch applied and noticed that some of them incoherent due to some several inconsistencies, glitches, typos left without any kind of version updates. So anyway, my first time ever doing with romhacking, with only some limited hacking skills required for me, I tried to fix it more using Aeon Genesis pre-patched as rombase. This updated addendum hack fixes everything by eliminating some glitchy mess, cleaning up some rests, retranslate everything that should get rid from tons of Engrishes that were still present even in the original Japanese release are now fixed.

List of changes:
- Many translation changes now taken from official English releases such as the SNES port of Wizardry V (censorships doesn't count for my fixes) and other fan translated Wizardries specifically for Gaiden IV.
- Corrected all/some grammatical errors that was also still present in Aeon Genesis translated even the Japanese original. Some instances like "Overload" upon entering maze plus during near ending of credits roll in the first game, "SaveData and Change Scenario" now "Data Saved! Changing Scenario", etc.
- Some monster names are corrected, for example: "Rabit Rat" (originated from Wizardry II) to "Rabid Rat" just like the official English release of Knight of Diamonds for NES.
- The rest of all caps and incomplete case sensitive texts all corrected. With exception of some acronyms, MURMUR-CHANT-PRAY-INVOKE, etc.
- All magic spell descriptions now cleaned up, retranslated entirely, mostly taken from computer ports reference chart and Gaiden IV fan translation. Some descriptions in previously translated one are vaguely understandable like suffocating spells Makanito ("All enemies levels eare exchanged" Noted that typo), Lakanito ("Enemy group slowed"), light spell Lomilwa ("Friends light maze") etc., some are broken like Latumapic described along with Japanese leftovers ("See Eねemy's tるe form"), Tiltowait described with tons of line breaks ("Heat deals 1 <breaks>15<breaks>to<breaks>enemy"), and finally some are misplaced like Dialko (HP maxed) belongs to Madi, Madi (Revives corpse with full HP) belongs to Kadorto respectively, etc.

Things I'm currently unable to-do:
- Increase text string limitations for Options switches in Options Menu (still Ster and Of).
- Some spell descriptions specifically for Dialko (Cure paralysis) which currently described as Detoxify at the moment due to letter spaces issue and technical hacking difficulties.
- Correct reordering Wizardry II: Legacy of Llylgamyn and III: The Knight of Diamonds => Wizardry II: The Knight of Diamonds and III: Legacy of Llylgamyn respectively to now match like the original source material.
- Remove all 4 different language switches and sets all into English by default similar to Gaiden IV fan translation. (You still need to set all switches manually before playing and after system file deletion)
- Premade Duo Fighters name still in acronym "FTR(x)" like usual, albeit has 8 empty letter spaces for hacking it otherwise if renaming each to "FIGHTER(x)" they'll come up with "FIGH"s only leaving "TER(x)" unused and premade Priest actually shows up as "PRIES" no "T".
(x): number 1/2. UPDATE: This was later named properly as in 1.10 onwards (see Changelog).
- Turbo File menu remains unchanged as still partially translated, however only english texts for importing characters have been realigned properly. UPDATE: This was later translated entirely in 1.02 (see Changelog).
- "Paralyzed" in Display Status interface (overwrites H.P. cap) still reads "Paralysed"

Changelog:
1.0
- Initial release

1.01
- Fixed broken Invoking prompt messages
- Mistake in Tiltowait damage cap on description now corrected from Japanese source (10-115 => 10-150)
- Some item names properly retranslated (i.e. Slayers of Were => Were Slayer)
- Changed "<NAME> is need Kadorto now" to "<NAME> needs Kadorto now"

1.02
- Added optional patch to make weapons and items based upon from IBM PC version (Translation patch must be applied first on top before using it)
- Many Item names have been retranslated and (not all) modernized entirely
- Renamed "Potion of Neutralizing" to "Potion of Antidote" (thanks to Grauken for a suggestion), this potion name barely fit in either in official Japanese release (in all caps) and fan translated one, upon selling it while still in inventory shows up as "Neutralizin"
- Turbo File menu entirely translated and corrected
- Changed "Adventurers Inn" back to "Adventurer's Inn", using squishy <'s> (A2 A3), otherwise the usual <'s> (27 73) barely fit without a space resulting "Adventurer'sInn"
- Changed "Are you OK ?" to "Is this OK?"
- Changed "Turn switch off, in this state of things." to "It is now safe to turn off the power."
- Changed "Character Sorting" to "Reorder" matching from official western releases

1.10
- Added optional patch to make weapons and items based upon from very first Apple II version (Translation patch must be applied first on top before using it)
- Removed the ability switch letters to Japanese during Character/File naming. This wasn't necessarily needed as this translation patch only focuses on more English language playability
- Removed the ability to switch language parts in Sub Command as well omitting Japanese toggles in Option Menu screen (Japanese still default)
- Premade default character names are now match properly from NES counterparts (sorry no CLERIC censorship)
- Many rewritten strings for [Select] help screen related things
- Some text string edits for Option Menu screen (still unable to extend more for Ster and Of)
- Credits roll related strings including staff names all corrected
- Changed Hipopotamus(es) to Hippopotamus(es)
And more...

1.2
- Translated the untranslated races and classes descriptions (by pressing Select button)
- Edited allocate bonus points help description
- Edited command descriptions on Turbo File menu
- Changed monster names (Were Rat > Wererat, Were wolf > Werewolf, Were Tiger > Weretiger) 

Applying Instructions:
The first thing you do is to download beat patcher tool (http://www.romhacking.net/utilities/893/), or go to alternative ROM patcher online (https://www.marcrobledo.com/RomPatcher.js), or download UniPatcher if you have an Android phone (https://play.google.com/store/apps/details?id=org.emunix.unipatcher). Second make sure you have headerless, Wizardry I-II-III - Story of Llylgamyn clean unpatched ROM (Clean .bps) or Aeon Genesis applied over (AGTP Patched .bps), please do not ask for help how to get it otherwise I would refuse to do such a thing. Last step run a patcher program, then apply it on a clean rom you already provided, and it should get indicating successful message.
 
Here are the following requirements to get the updated patches to work properly:

Wizardry I-II-III - Updated English (Clean).bps
---------------------------------------------------------------------------------------
Filename: Wizardry I-II-III - Story of Llylgamyn (Japan) (NP).sfc
CRC32: b8a72553
MD5: 5987975fb59733089149003c506810af
SHA-1: 6b63c968aec822c0728513c01cd729ffd45dbab7

Wizardry I-II-III - Updated English (AGTP).bps
---------------------------------------------------------------------------------------
Filename: Wizardry I-II-III - Story of Llylgamyn (Japan) (NP) [En by Aeon Genesis v1.0].sfc
CRC32: 16ffe85a
MD5: 167f3de8c5e5f464d1d473eb628b2aaf
SHA-1: c2fe27a3e1802b33c40b5c9fea3aab934396e792

For report any issues and suggestions, I'd recommend you to contact over at my social medias such as Facebook, Twitter, Discord Server or even Youtube channel. Always provide screenshots/videos, save files (.srm) for further clarity.
Links below:
https://gamerhenky.carrd.co

Enjoy!
-Hengki Kusuma Adi

*ANYTHING ELSE, NOBLE SIR?*