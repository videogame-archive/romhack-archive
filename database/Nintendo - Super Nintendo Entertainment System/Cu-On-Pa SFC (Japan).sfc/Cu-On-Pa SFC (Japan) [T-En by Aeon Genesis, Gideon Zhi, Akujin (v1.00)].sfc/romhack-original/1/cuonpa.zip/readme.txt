CU-ON-PA SFC
ENGLISH TRANSLATION V1.00
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Cu-On-Pa
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions

----------------
1.About Cu-On-Pa
----------------
Cu-On-Pa is an EXTREMELY addicting little puzzle game. Released for
the PC as Endorfun, Cu-On-Pa simply defies real description but rest
assured, it WILL suck you in once you get the hang of it :)

---------------
2.Patch History
---------------
The Cu-On-Pa project started a little less than a month ago, back
before the game was even emulated. Akujin translated everything,
and I inserted it back in and fixed a few pieces of engrish here
and there. This is the finished (we hope) project.

October 6, 2001 - Initial version 1.00 Release

---------------
3.Patch Credits
---------------
THE CU-ON-PA TEAM
Gideon Zhi - Project leader, lead romhacker
Akujin - Translator

--------------
4.Known Issues
--------------
No known issues.

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "cuonpa.smc" make sure the patch
is "cuonpa.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
a header. If you right-click the ROM and select Properties, it
should read "Size: 1.00MB (1,049,088 bytes), 1,052,672 bytes used".
