patch created by bankbank
right now it's just the main menu and options menu, but those can be a big help
enjoy!