Title: Final Fantasy V Tweaks 
Author: T29
Version: v2.7b
Release Date: 17/10/2022

Contents:
---------
|1. Introduction.
|2. Installation.
|3. Features.
|4. Patches used.
|5. Changelog.
|6. Special Thanks.
|7. Legal info.
_________________________

  1. Introduction
_________________________

The purpose of this patch is to provide the best possible experience for both 
longtime fans and newcomers without affecting the gameplay too much.

The script uses the Legend of the Crystals Translation done by Spooniest and Vivify93 as a 
base, and some jobs, abilities, and description's names from the GBA version.

If you have any suggestions to improve the patch let me know in the 
romhacking.net forum thread (https://www.romhacking.net/forum/index.php?topic=34785.0).

_________________________

  2. Installation
_________________________

1. Start with an unmodified FF V Japan SNES ROM "Final Fantasy V (Japan)". 

2. Use a IPS patch utility to apply the "Final Fantasy V Tweaks v2.7a.ips" patch to the 
ROM.

3. Apply the optional Patches if you desire.

________________

3. Features.
________________

-Better equipment for some jobs that previously can only equip one or two weapons 
(like the white mage).
-A GBA-like sprint.
-Now you learn blue magic without having to equip the "Learning" ability.
-Reworked Learning ability into an ability called "Lore" that gives you the stats of a Blue Mage.
-Berserker now has a command that casts berserk on him instead of always being berserk.
-Calm was reworked into an auto-berserk command.
-Restored enemy counter.
-Some minor improvements on the menu.
-Now the Ragnarok gives you stat bonuses.
-Time spell "Drag" has been reworked into a +1 temporary level up (useful to learn the "Lv #" spells)
-Genji equipment it's no longer missable.
-The missable songs and spells now can be purchased at the Dwarf Kingdom.
-Now Dragon Lances can be stolen easily from Jura Avis.
-Dancer job was buffed to at least be usable.

=================================
a. Optional patches.
=================================
-Inu's patches [Beta].ips
A compilation of the following patches made by Inu:
   ff5_atb_switch.ips 
    Adds a function to switch the action order with the X button. 
   ff5_flee.ips
    Disables Flee in battles where you can't escape. 
   ff5_lr_menu-1.0.ips
    Adds LR menu functionality. 
   ff5_optimize.ips
    Improves handling of strongest equipment.
   ff5_reequip.ips
    Improve handling of reequip.

 Note:  They were made for the Japanese ROM, I don't know if 
	they work properly in FF V Tweaks, so I didn't apply them to the main patch.
	If you find any bug please let me know.
 Edit: There's a bug on the config menu, I'll try to fix it. Thanks to Lynx for
       reporting it.

-PS1 Dash.ips
Makes the dash ability behave like it did in the PS1 port (Thanks to jtm297 for 
letting me know).

-GBA Font.ips
Changes the menu font into the font of the GBA port.

-Old Font.ips
Changes the menu font into the old font used by this hack (FF VI's menu font without shade).

-PS1 Font.ips
Changes the menu font into the PS1's version font.

-Formula_Tweaks [BETA] (by Modoh).ips
A beta port of FF5 Weapon Formula Tweaks (https://www.romhacking.net/hacks/6885/).
NOTE: I removed it temporaly while I manage to fix it.
_____________________

4. Patches used.
_____________________

Power Drink fix (InstructrTrepe)
Observe fix (InstructrTrepe)
Kiss of Blessing fix (InstructrTrepe)
Fractional M (InstructrTrepe)
Blue Mage sprite fix (Grond)
Landing fix (BerikXardas)
Catch bug fix (Noisecross)
Knives fix (Jorgur + noisecross)
Rune weapons fix (assassin)
Goblin Punch fix (assassin + noisecross)
Minimum M (assassin + noisecross)
FF5 Dash GBA (Inu)
FF5 Better Item Menu (Tzepish)
FF5 No Missable Items & Spells (Tzepish)
FF5 Replace the Drag/Speed Spell (Tzepish)
 Note: I edited it a little bit.
Multiplayer Sound Effect (Inu)
Sprite touch-ups (Chicken Knife)
Quick Death (LeetSketcher)
Ginger Battle Galuf (J121)
Caught monster display (noisecross)
Un-Berserker (Jorgur)
Count Monsters patch (LeetSketcher)

_____________________

5. Changelog.
_____________________
v2.7b
-Fixed a bug in Inu's patches optional patch.
v2.7a
-Removed Modoh's FF5 Weapon Formula Tweaks due to a bug caused when I unninstalled
 the incompatible patches. Thanks to Lynx for reporting it.
-Restored Power Drink fix, Knives fix, Fractional M and its related patches.
-Buffed some weapons while I manage to re-install FF5 Weapon Formula Tweaks.
v2.7
-Added a PS1 dash optional patch (Thanks to jtm297 for letting me know).
-Added an optional patch to use the GBA version's font.
-Added -Inu's patches [Beta].ips optional patch.
-Buffed Dancer job.
-Ragnarok and Excalibur are no longer throwable.
-Removed Power Drink fix, Knives fix, Fractional M and its related patches in order
 to apply Modoh's FF5 Weapon Formula Tweaks (Don't worry, Formula Tweaks has 
 the same effect as the removed patches).
v2.5a
-Added an optional beta port of Modoh's FF5 Weapon Formula Tweaks.
-Added screenshots of the optional fonts.
v2.5
-Reworked the "Drag" spell.
-Applied the FF5 No Missable Items & Spells patch.
-Increased the chance of steal a Dragon Lance from Jura Avis.
v2.4a
-Changed the equipment of the Berserkers and Mimes.
-Reworked the now useless "Learning" ability into an ability called "Lore" that
gives you the stats of a Blue Mage.
-Now the "Equip Rods" ability gives you a magic bonus.
v2.3a
-Added stat bonuses to the Ragnarok.
-Changed the menu font into a FFIV/Mystic Quest-like font. 
-Added an optional patch in case you want the old font (FF VI's font without shade).
-Added an optional patch in case you like the PS1's version font. 
v2.3
-Added the FF5 Better Item Menu patch.
v2.2c
-Now you learn blue magic without having to equip the "Learning" ability.
v2.2b
-Removed a patch that caused the "Sort" option to disappear items. (Thanks to Lynx for reporting.)
v2.2a
-Fixed some text.
-Changed the hack's name.
v2.2
-Berserker now has a command that casts berserk on him instead of always being berserk.
-Calm has been reworked into an auto-berserk command.
-Restored enemy counter.
v2.1
-Fixed a bug that caused the obtained items to not display properly.
-Added more bugfixes.
v2.0
-Fixed a error that caused the "Items" command to display smaller than intended.
-Added some bugfixes.
-Updated credits.
v1.0:
-Initial release

_____________________

6. Special thanks.
_____________________

-RPGe for doing the original translation.
-Spoonify93 GameMods for doing the Legend of the Crystals Translation.
-Noisecross for the Text Editor used on this hack.
-Inu, Assasin, Grond, BerikXardas, InstructrTrepe, Chicken Knife, Lumiere, Jorgur, 
J121, Praetarius5018, JLukas, Samurai Goroh, Tzepish, Modoh and LeetSketcher for doing some patches used 
on this hack and helping in the hacking zone.

_____________________

7. Legal info.
_____________________

-The autor is not associated with any video game company or any other company.
In no event the autor shall be heldliable or responsible for any damages that may 
occur from direct, indirect, or consequential results of the ability
or disability to use or misuse any material it provides.

