-------------------------------------------------------------------------------
KWHAZIT / CHRONO COMPENDIUM
Chrono Trigger Retranslation Patch
September 28, 2007
http://members.fortunecity.com/kwhazit/ - http://www.chronocompendium.com/
-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------
1.) History and Foreword
2.) ROM Hacking Notes
3.) Installation
4.) Credits
-------------------------------------------------------------------------------
1.) History and Foreword
-------------------------------------------------------------------------------

2007-09-28 V 1.00

- First release

2007-10-05 V 1.01

- Error fixes

A list of error fixes per each version is at:

http://www.chronocompendium.com/Forums/index.php/topic,4693.0.html

KWhazit began translating Chrono Trigger a couple years ago. When ZeaLitY saw
his efforts, he scrapped an unsuccessful collaborative retranslation project
and adopted his, delivering an intuitive 4-column spreadsheet containing three
scripts with marks for lines still needing translation. KWhhazit completed his
work on March 30, 2007. ZeaLitY declared that he would not be doing a patch,
at least through his own work, as he did not have the personal time to
sacrifice. Six months passed, during which a developer for KDE tried using
Chronotools to insert the script, encountering problems. ZeaLitY went ahead
with a blitzkrieg effort to insert the script with Temporal Flux to produce
this patch in a month's time.

It is not the opinion of this project that Ted Woolsey's work is inferior or
needy of improvement. In fact, Woolsey did an extraordinary job giving Chrono
Trigger depth and flair despite restrictive space limitations on text. Many
memorable quotes are owed to his writing.

KWhazit retranslated Chrono Trigger with the Compendium's presentation to
achieve a vision of perfect canon by showing exactly what Japanese players saw.
For this reason, the script may use unusual English at times, and Japanese
honorifics are present. This is not an argument against KWhazit's skill, but
rather a symbol of the overall goal to produce a literal version of the
original Chrono Trigger. KWhazit retranslated as accurately and conservatively
as he could, seeking to make his work as transparent as possible. There is no
obscene cursing, kawaii jokes, plot changes, or modernities; what you see here
is what the Japanese audience saw. To criticize the retranslation for the
occasional Engrish or for a lack of localization is futile: that was the goal.
With KWhazit's work, a completely canonical and accurate version of Chrono
Trigger has been presented; it is a standard for all future works and analysis.
Please consult the script release for annotations.

If you'd like to view a searchable script in Excel spreadsheet, HTML, or text
format, or if you'd like to cut straight to an article detailing the many
differences between versions, check out:

http://www.chronocompendium.com/Term/Retranslation.html

To learn more about the processes involved in making the retranslation, visit:

http://www.chronocompendium.com/Stories/45

Please report all bugs at the Chrono Compendium Kajar Laboratories forum:

http://www.chronocompendium.com/Forums/index.php/topic,4693.0.html

PLEASE NOTE: The Chrono Compendium REALLY needs a translator to help us with
Chrono Cross Ultimania, Chrono Cross Missing Piece, and Chrono Trigger
developer interviews. A TON of interesting information is locked away from
English audiences. If you can help even with a few captions on Missing Piece,
drop a line at chronocompendium@gmail.com.

-------------------------------------------------------------------------------
2.) ROM Hacking Notes
-------------------------------------------------------------------------------

This patch does not feature:

* Variable-width font (slows down performance)

This patch does not enable this Japanese feature:

* Equipment screen item count (would interfere with names)

This patch does enable these features:

* Ayla's Cro nickname (via second naming screen with Ayla; choose the nickname)
* Marle's formal name (simply adding "dia" to the end of {Marle} strings)
* Special Japanese ending art for Crono & Marle's balloon parade ending
* Sky / Dark element icons replacing Lightning / Shadow images

Certain item and location names were shortened. To view the full names, consult
the script release. There are no easter eggs; don't bother searching.

-------------------------------------------------------------------------------
3.) Installation
-------------------------------------------------------------------------------

The retranslation comes in the form of an IPS patch, which will be applied to
your US Chrono Trigger ROM. Please do not ask me where to get a ROM; it is
assumed that you have one. Once the patch is applied, it cannot be undone. Also,
you need to determine which patch to apply. If you aren't sure what to do, just
apply the one that is named "CTR-Headered.ips". Here's the process:

1. Make a copy of your ROM. This patch can't be undone, so you probably want to
   keep your old ROM untouched.

2. Use Lunar IPS or a program of your choice to select the patch and the ROM you
   would like to patch it to. If you aren't sure what to do...just open Lunar,
   hit 'Apply IPS Patch,' then find the Retranslation .ips file.

3. It will then ask you to specify the rom you wish to modify; use the copy of
   your CT rom.

You can also rename the patch to the name of your rom and run it in ZSNES, and
the emulator will automatically apply it. They must be in the same folder or
specified in the Paths options.

-------------------------------------------------------------------------------
4.) Credits	
-------------------------------------------------------------------------------

KWhazit translated the Japanese script of Chrono Trigger.

ZeaLitY edited, arranged, and presented the scripts in the four-column format,
created the patch with Temporal Flux, and beta tested with the aid of the
springtime of youth. Kyronea briefly assisted and found lost lines.

JLukas extracted the Japanese script, and with Geiger helped with CronoNick,
with restoring the Japanese art, etc.

Geiger created Temporal Flux and wrote the Chrono Trigger Offsets Guide:
http://geigercount.net/crypt/

Vehek created the title screen and located lost lines in March.

Lena Andreia edited the Sky and Darkness menu elemental icons and made the
final site banner.

whatev and doulifee provided ancient lost line assistance.

A hearty thanks goes out to all those who love the Chrono series and have
waited as long as we have for a new translation of Chrono Trigger.

Thanks also goes out to Ted Woolsey for doing a cool job the first time
around and making Chrono Trigger a fun, well-rounded game.

Lastly, I'd like to thank everyone who has contributed or hung around the
Chrono Compendium. Whether you're a tomato, pirate, Guru, or just a
plain old awesome ROM hacker, you've come together with many other fans to
make the site the true center of the universe.

If you can translate and have some free time, we'd love to find out what's in
those interviews, Missing Piece, and Ultimania. Just drop us a line.

http://www.chronocompendium.com/ - http://members.fortunecity.com/kwhazit/

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

....         ,irrX7;:  XM0:  :;ra8;.,X2X;M .W,. :,,S:  WX , W:@r Ma   rX  i0   
     ..:irrr7;i   iXaZS  rMB2X77;7XS; ,, :B 82: .i:;i  0W . M M 7X  . W  .@    
7228aS7;,.;72BMMM@X:rSZS7. rZXr;iir7SSr:. ;X:WSi.i77;   M .,riair    a  ;S     
2;:   .2MMMMMMMMB0B2i;7rXi77.ZZ87.i   ,,.  ;ZSB77,:7a , @ ., .Si .2@M.  Xi     
  iSZBM82ZSi   .SB@0r,:r;;MMMrX8WMBWB8 BS :r  :ii;7;B,, a;,   7 ii   7SZMMMMW7 
a07 .rZZSXX20W8ZS7XSMM0X0Zi  MM@@7MMMMM7MWraSX Xa:7i;Z.,:  78..X  X@W8@ :    2M
  aMMZ.  ,.     .,    r8;ZM@8        2 BZ@ 2MMMiZB Z,88   :BM 2 0M8S: .7       
WMa    ...,:;r;;r7S8ZX   8B  ,i,,:::.        ;aMiMWMWiS XMB B7XX2X:.SS7:i      
S      ..,:iii:ii,:irS07BZ@ ::,7 ,:,:iiii;:i.    : .M@MB,   870:,.XMM2  M      
  ,i77ri,,::XZWMMMMM0XS;Z8  : Z2 :,ii::::::ii,...      X,a iW  iZBM8 rM  i     
;XXX7ri0BBMM@a;:  ,i;rS ;M7  ;M; ,:i:::i:::,i,,:,,,,. 7iX, MMMMW   ,X SM M     
.     r8a00aXXZZ,7SXZ:. 8W  ;M@  .,,:,,i:ii:,  ,,,.. ;:XW SS   XMMX S  @:@a    
::;XX7r;i.     ::::ii  8ZMMXMM:  ,..,....,,,.;  . .  aS.2:M    @a@rMWa  M M    
8@BZaXi.   ,r7SSXri;;2MMa   X      ...,..,,,.i8     SrM Z2@  .  Mr  aMW  ;Z,   
    ,i,irS2ZaaS;:7Z08SS:               .,::.7:SM    MBi ZZ,  .  ,W   MiX S Z   
W@@B7i:7Xrr;:i 8MMMMZ  Za    :;i:           ;;:XM   Z8  @B:   ,  M.  X@; , M   
i    ,:ii:.    ,:     . 8MMM7 i2WMMMMMMMWX    . WM  Xi  2MM   M  B7   MS  .M   
i7MMMW7.  ;i.ZWMM  087 M  WMMMMM@MWa2WM0MMMMM0i  MM2S   2MXM  M  7r8  M2i 7W   
ZMM,  ;SMWB :M@. MMM0M: i  @M0MM   S0XXXZi rWMMMr  @MM  SM 2  X W  M  W7M  X:  
7ZSMMMX87X  r   MW2aMM8Sa   MM@MMSXSZWMZ M   0M7MM @,MM ;M;M  MM;  M  2 B  W:  
X:Z;   MS: ,  72BX2BS72WWMr   8MMMMMMMMX 2    ZX7M2MX8M@@MB  MMM2,a   X7M  M   
MMB0MXM2MriM2,7a0ZZSS8WrXaMMa.    irr77Z@WXaX 7S   M:W@,7M  MWrZMZ    iSM  M   
WMW0ZM@0 0  M  SW2SWMBW;.iX;,r0MMa    ,2MM0WX     ,M MBM;W ,M.M M0    irM  M   
 MMM2M  M ::M, :2XrZZMW2ar  M8i   :Ba:     iZMMMMMiW .XMSM  @MB       arM  M   
 WBaM S M SWM  7i,.XSS;r722   ia8Xi   72X.         ZX:,;:MM   M2M     M2Z  Z   
.MMi  WM; M:W MM .M2 ;;X7;2ai      :;:..:2MMMMZ    Z      M    WM     Mi   @   
iMMM  @M 0M7MBi: 0Mi SW.i  7X8X.      ,:. . r82S   a:.:i, MM .  ;;    M   .:   
  MM  M;rXM a SSMiB M7M  MM. ,:7XX;,:;iir;;,  r W  7r ,i:  0..:   M  ;.        
      M M @ S :M, M2.:S @8r 7MS.: ,.      ::iX0WBr ;2  ,.   7    M:  .         
M0ZM:  ;7;i;8, M  M .Wr0.S WrM   @M       .MM2r   ,,; .. 7ZZM:rMMW: .          
M M:M7 B i .8 2   ; iiM  @Z. M ;MM  MM   WM    ,,,:,,SSM@a:  8@X Z:            
iMM MM X ;7MMBM  :,.    .M i MX@,a MWS  @Z  .,:,,i,..:i;:iirM0   M             
 M  2MM  ZM  :M8BMZ  M i   ; MX,:Z0r: :B     .,,i,,::, .,i;X2    @             
  0 iMM, Z0  8.SiXMMMMS:Mi   ;  :M  X@MMa27:                    M,             
  M .MMB ;8 ,W  S r Z M22M WM   M2  MSr22BWMMMMMMW02:  .i:     XW              
. Mi MMMS W,2B  M   ;   aZMMMSiMS  8,  :,:     .,raWMMMM@0rii: M               
:  M0MZ  .8MBB rM  ;W  i   r 7M7MSMMM@@Zi. .,. ,...     rMMMMMW                
:. 7.   :2i2 M;r:i:8B  @   7  M Mi.. ;BM80MMMMWMWWS        .S                  
i   MX r7@S  aB  aM B,B;. @; ,i MMMai ,            7Zaaa: .Z M                 
i    MiriZ0Z7i;8.MM M@ S ;M, @  0 ;MMMMZi,   :,          MM W                  
M     MM0raBr:SS, ; M@ M0S@  0 ZM     :MMMM@;.   .  :    M  W                  
MM    ,MMMZ ;2X0S ,;.  8a M M: Wa :ii,     SMMMMMa::,    S r                   
MM.    iMMMM8SZr   ,Sr.   MBa.27; ...:iiii.      .i2BMMXM 7a                   
MMM,    ,MMMM0:XMB   ZaaZr7.MMai: .,::,,,,::i;;;i,        M                    
MMMM      MMMMM  .@M0MMW7:::X.  M  ..,::i:::::::iiii;;:  M                     
MMMMMa      MMMMMMMMMMMMX.;7i   M. ...  .,:iiiii,,iiii:  M                     
MMMMMM@      ;M      @@MM  i7  XMr ,,... ,::::::iii;;:  @                      
MMMMMMMMB      0,,   i0WMM  i  Za     ,:::,::::i::,.   ii                      
MMMMZ 2MMM7     2MMM rM0WM8    MMMMS     ,:::::::.     8                       
MMMMMB  8MMM:     MM XMW88MS , rMMMMMMM0    ,;i;i:     0                       
MMMMMMM8  8MMMX    880MSM@MM0  2M8XMZ0MMMMMa    .ii:. ,i                       
MMMMMMMMM:  :MMMM    XM8WW7irM8MS2.M      7WMMM0,     X                        
GRIMMJOW*JEAGERJAQUES  7Z08@@SZaWM0MMMW         i:iXSaS                        
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------