MAGICAL DROP
ENGLISH TRANSLATION V0.95b
Copyright 2001 by Aeon Genesis
http://agtp.romhack.net

ToC

1.About Magical Drop
2.Patch History
3.Patch Credits
4.Known issues
5.Application Instructions

--------------------
1.About Magical Drop
--------------------
Magical Drop's a neat Puyo Puyo clone, but backwards. You'll see,
it's fun ^_^ Plenty of secrets to be found, too ;)

---------------
2.Patch History
---------------
This patch took me the better part of three days and was made
specifically for Aeon Genesis' anniversary. Woohoo!

March 7, 2002 - Initial version 0.95b Release

---------------
3.Patch Credits
---------------
THE MAGICAL DROP TEAM
Gideon Zhi - Project leader, romhacker, ASM hacker
Byuu, Xeur-of-yore - Translators
satsu - Graphics hacker

--------------
4.Known Issues
--------------
-The title screen is still in Japanese, but it's stored
very strangely and satsu's having a hard time with it.

-I have not been able to locate the game over menus.

The patch is beta because it hasn't been formerly tested.
Please report any bugs, spelling errors, and such
on The Pantheon (http://donut.parodius.com/agtp)

--------------------------
5.Application Instructions
--------------------------
If using ZSNES, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "live.smc" make sure the patch
is "live.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS A HEADER.
If you right-click the ROM and select Properties, it should read
read "Size: 1.00MB (1,049,088 bytes)". Use SNESTool to add a
header if your ROM doesn't have one -- if you're using an emulator,
your answers to its questions to not matter.
