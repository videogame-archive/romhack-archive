#### ###  ######  #######  ######## ######## ####      ######  ########  ###### 
#  ### # ##    ## #     ## #  ##  # #      # #  #     ##    ## #  ##  # ##    ##
#   #  # #  ##  # #  ##  # #  ##  # #  ##### #  #     #  ##  # #  ##  # #  ##  #
#      # #      # #     ## #  ##  # #    #   #  #     #  ##  # #  ##  # ##  ####
#  # # # #  ##  # #    ##  #  ##  # #  ###   #  #     #  ##  # #  ##  # ####  ##
#  ### # #  ##  # #  #  ## ##    ## #  ##### #  ##### #  ##  # #  ##  # #  ##  #
#  # # # #  ##  # #  ##  #  ##  ##  #      # #      # ##    ## ##    ## ##    ##
#### ### ######## ########   ####   ######## ########  ######   ######   ###### 
                           Another Treasure Island
						   
                         ***************************
                         *    Table of Contents    *
                         * 1. Included files       *
                         * 2. Notes                *
                         * 3. Contact info         *
                         ***************************

1.  Included files
	Marvelous playtest build/
		Marvelous - Mouhitotsu no Takarajima (Japan).ips
		Marvelous - Mouhitotsu no Takarajima (Japan).xdelta
		script.txt
		readme.txt

2.  Notes
	i.    This is the playtest build. There might be bugs. I've played through successfully, but there could be things I missed. Please contact me with your opinions, suggestions, complaints, etc.
	ii.   The patches are to be applied on a ROM with the m5dsum: b9b77e5f378b871ece75caba82718a8e (the 3MB version)
	iii.  This patch translates all dialogue from Japanese to English. The UI has been sort of translated to English. Certain graphics are not hacked yet. I'm working on it.

3.	Contact info
	E-Mail: watashiwa@gmail.com
	IRC: #tashi @ irc.irchighway.net
	PM: tashi on RHDN forums http://www.romhacking.net/
	
Ver. 2012-06-18