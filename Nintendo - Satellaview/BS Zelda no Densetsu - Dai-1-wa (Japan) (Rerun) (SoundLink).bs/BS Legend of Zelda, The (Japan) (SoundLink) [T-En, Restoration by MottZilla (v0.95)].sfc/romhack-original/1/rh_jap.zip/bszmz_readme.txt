BS-Legend of Zelda 'MottZilla Patch'
By: MottZilla
Beta Version: 0.95 - May 6th, 2012
For BS-Zelda MAP2 ONLY
For ROM WITH 512-byte Copier Header.

---------------------------------------------------------------------------------
All rights to patches and program patch code belong to MottZilla. You may not
distribute modified versions of this patch without permission. You may not sell
this patch, in any form including but not limited to: CD-ROM, ROM file, Cartridge
etc. This text file must be included with any distribution of this patch.

To play this patch on a real console I recommend a device such as the RetroZone
PowerPAK, Krikzz's Super EverDrive, Tototek's SuperFlash, or older Copiers like
Game Doctor SF, Super Wildcard, Pro Fighter, or Super UFO. No reproductions may
be sold. They may only be made for personal use, no commercial purposes. If you
see a cartridge being sold be aware that the components needed amount to less
than $10USD usually. And remember that a bootleg has no worth other than the sum
of its parts.

---------------------------------------------------------------------------------

New in v0.95
* Fixed possible lockup/crash if SRAM uninitialized. If you had trouble with the
game crashing after the title screen, this should fix it.

New in v0.94
* The red Dungeon markings on your map are now updated every week just like the
  original broadcast. First has none and each week after has the previous 2.
* Bad Ending will show Credits afterward.
* After Credits game will reset to the Title Screen.
* Calculated Checksum. Both English and Japanese versions have GOOD Checksum.

New in v0.93
* Changed SRAM Memory Map. Seems more compatible. ZSNES emulator now works.
* Added SRAM functionality test and error handling. If SRAM isn't working
  the program will not crash or hang, you will get an on screen message.

New in v0.92
* Fixed Heart Container TRE saving. Saving won't let you cheat to keep TRE HCs.

New in v0.91

* Fixed Sound Effect Lockup that could occur while saving.

New in v0.90

* Fixed Time Related Events and Saving Problem.
* Disabled Saving after Killing Ganon to prevent possible issues.

New in v0.80

* Lots of Stuff

---------------------------------------------------------------------------------

This patch is an evolution of the old BS Zelda Lite and BS Zelda Real Hardware
patches I created in the past. With this project the playability of BS LoZ is
now excellent. Some of the features of this patch are:

* Works on authentic real Super Nintendo Hardware!
   Most other versions including all based on Roto's don't work.

* Title Screen and Story Roll
   Retro feeling title screen and story sequence.

* Classic feeling Menu System
   Similar to the original LoZ Menu but with practical improvements. You have
   three save slots, 3 characters, enter your name, pick your Map/Quest.

* Both Map 1 & Map 2 Quests!
   Combined both Maps into 1 Patch, the first and currently only to do so.

* Four full Weeks of 50 minutes playtime
   Previously Triforce based advancement has been removed in favor of a more
   broadcast experience. 

* Playable from Beginning to End
   Play both maps with no known glitches, problems, or missing features.

* Different Endings for Success and Failure
   Using art from the original broadcast to have two different endings. 


My goal for all my patches has been to actually function properly on real SNES
hardware due to the older patch by Roto and all other patches which are based
apon it not working on real SNES hardware or more accurate SNES emulators. And
to make the game fully playable from start to finish. I believe I have reached
these goals. But there are a few details I might finish in the future. The red
dungeon dots are supposed to show the previous week's dungeons. Currently they
don't update. Also I might someday add an end week "results" screen showing off
how well you did. But these are minor details that I didn't want to hold back
a release for. There are no known major bugs at this time. If you discover a
bug please report it on the BS-Zelda forums. 

Important Gameplay Tips:
Due to the game's original broadcast nature the game will always take 200
minutes to play from beginning to end. Because of this many players will find
themselves with alot of extra time at the end of each Week. If you don't want
to use this time you may go to your inventory screen and press L+R+Y+B at once
to end the week. You'll see minutes fly by in seconds until the end of the
week is reached. Also because of the long nature of the game you may wish to
save your game in the middle of a week. At the Inventory screen press L+R+Up.
You will hear a sound effect to confirm the data was saved. However if you
have already defeated Ganon in the final week, saving is no longer possible.
One final note, if you wish to reset your game with your controller, at the
inventory screen press L+R+Start+Select. 

Final Notes:
When you complete the game you will see an ending sequence. However your save
file will not be changed.

Thanks to everyone in the BS-Zelda community for ideas, testing, and general
support. Also thanks to:

Con - For sharing various research and knowledge which helped in development
of this patch.

KiddoCabbusses - For alot of beta testing and other help.

Duke Serkol & Bumpus - For the English Translation.

Roto & Dreamer_Nom - For the inspiration to want to make this patch.


==============================================================================
PLEASE DO NOT SELL THIS SOFTWARE. DO NOT MAKE CARTRIDGES WITH THIS SOFTWARE AS
THIS BETA VERSION IS INCOMPLETE AND MAY CONTAIN BUGS. DO NOT SELL CARTRIDGES
FOR A PROFIT. HARD WORK AND A LOT OF TIME WENT INTO DEVELOPING THIS PATCH.

WARNING!

REMEMBER THIS IS A BETA. IT MAY NOT WORK 100% AS INTENDED.
==============================================================================