Apply first the 
Donkey Kong Country Kremlings Revenge Remodel v1.1_11.09.2017.ips 
on 
Donkey Kong Country (Europe) (En,Fr,De).sfc

Then apply krerev_msu.ips on this rom. Do not! apply any other msu patches (like dkc_Europe_pal_noheader_msu.ips).

Note: the europe pal version will be automatically transformed into a ntsc by applying the Kremlings Revenge patch
therefore you need the manifest.bml respectively dkc_msu.xml for ntsc (included in this subfolder).