
                 The Legend of Zelda - Triforce of the Gods:
 A re-localization of the classic based on the original Japanese 1.0 version

Brought to you by:

  Producer/programming
    oldmanoftheSEA		twitter.com/omotss

  Translation
    Monolith Traveler		twitter.com/MonolithTravelr

  Title screen
    Zoya Schultz		twitter.com/schultz1417


Instructions:

Open the included .html file in your browser and drag/drop the following ROMs
that you legally possess:

* Zelda no Densetsu - Kamigami no Triforce (J) (V1.0)
* Legend of Zelda, The - A Link to the Past (U)

Then click "Generate ROM", which will save the output ROM in the form of a
browser download.

NOTES:
- There is no need to rename your files, the contents will be automatically
  recognized.
- Headers are automatically stripped and the patcher will accept both
  headered and headerless ROMs.  The result file will be headerless.
- This romhack is based on the Japanese version, but uses assets from the
  English version.  In order to avoid distributing these assets, the patcher
  needs both ROMs to produce an output, hence the odd distribution mechanism.


List of changes/improvements:

* Many improvements to the game script to be closer to the original Japanese
* New title screen
* All Japanese 1.0 glitches intact
* Completely revamped text system which displays faster than all other versions
* Sanctuary entrance restored
* Kholdstare ice fade-out fixed
* Longer filenames (7 character limit)
* Fixed misaligned credit text
* Hylian glyphs and sign arrows from the Japanese version

Enjoy!
