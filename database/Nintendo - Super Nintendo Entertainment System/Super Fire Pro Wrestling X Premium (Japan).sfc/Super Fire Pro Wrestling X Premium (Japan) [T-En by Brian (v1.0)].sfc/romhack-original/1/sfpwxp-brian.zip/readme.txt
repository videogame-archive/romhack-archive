Forward by Eric Engel
=====================
A long lost Super Fire Pro Wrestling X Premium patch has been found! This one is a bit more complete and features real wrestler names (as opposed to the fake names typical of Fire Pro games, or the made-up/placeholder names found in the Sydra patch)!

Now, I had nothing to do with the finding of this version, let alone the creation of it. I merely converted it to an ips patch that can be applied to the NO-INTRO rom of Super Fire Pro Wrestling X Premium, so it will hopefully not be lost again!

It appears that, unhappy with Sydra's translation, someone going by the name Brian took it upon himself to start hacking and re-translating the rom. While it is unclear if he worked directly off the work Sydra started, Brian's site does state that he worked with Sydra on his version. Sydra later states that Phil, well known for his various SNES wrestling game translations, also contributed to the project.

All information I have on this is contained herein, so if you are looking for anything else on the subject, I can't help you. Sorry!



Translation Recovery
====================
Here's a quick rundown of events related to the recovery of this version, to give credit where credit is due...

1) brick9mm asked on the Fire Pro Arena forums asking about rumors of alternate translations of the game.
	(http://www.fpwarena.com/forum/viewtopic.php?f=5&t=876)

2) Legendary Sena located an old site for patches by a guy named Brian, although download links were no longer working.
	(http://web.archive.org/web/20050120213321/http://olympia.fortunecity.com/laver/174/patch.htm)

3) baronfreebird apparently had some of the patches lying around, and uploaded them to zippyshare. (download no longer works)

4) After unsuccessfully trying to apply the patches, freem and brick9mm worked out that the patches needed to be applied to the old fig format rom.

5) brick9mm successfully patches the rom, and uploads it to a rom hosting site, still in fig format.

6) And finally, I convert the fig format rom into a standard sfc rom, turn it into an ips patch, and upload it to RHDN.



brick9mm's post to the rom hosting site.
========================================
'This upload may seem redundant, as there has been a translation of the game floating around the internet for almost 20 years now. However, that translation (referred to as the "Sydra" translation) is littered with errors that are sure to irritate anyone who knows the slightest thing about Japanese wrestling (aka anyone who'd think about playing this in the first place).

These errors included over half of the roster being given "fake" names. While it's tradition for the Fire Pro series to have fake names for its real roster, these fake names were not translations of the original names, but in reality, they just didn't care. The legendary Mitsuharu Misawa is named "Jim Miny", whereas one of his greatest rivals, Toshiaki Kawada, is named "Jack Chan". This may be slightly humorous to some, but it's definitely irritating that they didn't bother to give half of the roster their real names. 

Enter the translation I have here. Way back, a guy named Brian (whom I don't know a thing about) decided to give the game the proper translation it deserved, and he did. Everyone has their real names, and the wrestler creation mode is fully translated. This translation, for whatever reason was completely lost to time, and the half finished "Sydra" translation is the one available on every ROM site on the planet.

Thanks to a few members of the Fire Pro Wrestling fansite, FPWarena, and someone who managed to backup the patch files before the original links died, I present the definitive translation of the best wrestling game on the Super Nintendo. The ROM is in FIG format, an old format before the use of IPS patches were commonplace. It works perfectly on both SNES9x and my Super Everdrive, though for whatever reason, I can't save the data on my Everdrive. I can't recall whether or not I could to begin with. Your mileage may vary. 

Thanks Brian, wherever you are.'



Sydra's post on Fire Pro Arena
==============================
'Ahhhh, it's been a long time....

I learned of the existence of Firepro World today, and stumbled upon this conversation. I actually can explain what happened during the translation process in regards to the names, since I am the one that did it afterall. I started the project with zero knowledge about hacking/hex editing/japanese/etc. Everything I did was made up as I went along :) It started as a simple hex editing translation, with the problem being that many of the names consisted of 4 kanji, which limited me to 4 characters for the name. I went into the rom and graphically changed kanji into double letters, which quickly turned names into jibberish. This allowed for longer names, but still only 8 characters. The joke fake names were used as placeholders, until I could think of something better to do with them. It wasn't until someone named Phil came along with a knowledge of assembly language that allowed us to make the names proper(and with proper upper/lowercase!). Kinda amusing that the last of the "bad" patches would be the one that most survived the years'