Fire Emblem: The Genealogy of the Holy War
IPS Translation Patch version Reparation 0.87g
A DTNTD patch

Based on the sources released by j2e Renegade, which can be found at
http://twilkitri.fewiki.net/FE4/trans/fe4-0.50.9.1-jay.tar.bz2
j2e Renegade member Boo's reference material can be found at
http://twilkitri.fewiki.net/FE4/trans/boo-ref.2002.10.03.zip

Current source for this patch can be found at
http://twilkitri.fewiki.net/FE4/trans/fe4transsrc.zip

Newer hacking done by Twilkitri
Editing by Twilkitri

Many thanks go to Eien Ni Hen, Emilyn, Summerwolf, and AceNoctali for providing various translations


USAGE

If you're using an emulator with auto/soft-patching support, then give the patch the same
name as the ROM, excluding the extension.

EG: If your ROM is "fe4.smc", name the patch "fe4.ips". NOT "fe4.smc" or "fe4.smc.ips".


Alternatively you can permapatch the file with a patching program, but this is not
recommended for various reasons, the most notable of which is that you can't take the patch
off.


PROBLEMS?

This patch only works on a headered FE4 ROM. The size of the ROM should be:

4, 194, 816 bytes

If it is instead

4, 194, 304 bytes

then you have a ROM without a header and you should either find one which does, or find
a program to add a header to it for you.

Headers are unnecessary and I've considered releasing a headerless version (as opposed to
a headered version, not in addition to) but I can't be bothered at the moment.


Twilkitri, 2012-05-06
