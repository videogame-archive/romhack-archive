-------------------------------------------------
- SD Gundam X Translation Patch			-
-------------------------------------------------

- How to install

* NOTE * Always patch over an original (un-patched) rom

If you're using Zsnes then you can simply rename the patch to whatever your rom filename is with a .ips extension

If you're not using Zsnes or you just prefer to have the patched rom you can use a tool like ips.exe or SNESTool

For IPS.exe:
	place the patch and rom in the same directory
	go into a DOS prompt by clicking Start then Run and typing: Command
        go to the directory when the rom and patch are and type: ips <rom filename> <patch filename>

For SNESTool:
	run SNESTool
	Type U on the keyboard
	Select the IPS patch file
	The select the rom

- What this patch changes

Pop-up menus for ships and other units 				- 100%
The In-game Submenu which pops up with you hit X		- 100%
Weapon listings in bases					- 100%
Nicer font for In-game Submenu (the other one looked nasty)	- 100%

- Future Plans

Longer weapon names (when I get around to figuring out how pointers work =))

- Contact Info

Everywhere but MUDs I go by Serin9X on MUDs it's Callinon

My email is: callinon@home.com

Feel free to email comments about the patch and suggestions for what I should put on the page .. NOTE: I will not respond to requests for the ROM, it's fairly easy to find at any major emulation site and as such I won't provide it

Also if you'd like to help me with the translation or the rom hacking email me, I'm neither a rom hacker nor do I read japanese, I'm basing this entirely off of my own experiance with the game so any help would be an improvement
