Final Fantasy IV - J2Evisceration Fix
---------------------------------
By Masaru

This patch restores the removed kain's speech at the beginning of the game that was in line with the original japanese script.

To apply this patch, use a japanese unmodified and unheadered copy of Final Fantasy IV (1.0 or rev1/1.1 depending of which one you have)

Two patching formats are provided, so you can use either .bps or .ips.
(Do not apply both patches.)

Use FloatingIPS or rompatcher.js to patch the rom 

Special thanks to Spooniest/FlamePurge for creating this hack and FCandChill for helping

Rom information:
Final Fantasy IV (Japan)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 7502ED13FE969B294AAB9EA3600DD8341713CD03
File/ROM CRC32: 21027C5D

Final Fantasy IV (Japan) (Rev 1)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: EAC14578B3465FFCE874119005F9B244E8565A79
File/ROM CRC32: CAA15E97