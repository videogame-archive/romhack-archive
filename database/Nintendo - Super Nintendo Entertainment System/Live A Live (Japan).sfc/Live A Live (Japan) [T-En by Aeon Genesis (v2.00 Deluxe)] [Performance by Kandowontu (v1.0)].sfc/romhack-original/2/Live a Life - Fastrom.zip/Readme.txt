This is FASTROM for Live a Life (J).

It is fully compatible with the Aeon Genesis translation.

MISTER Cheats provided for both!

SPECIAL THANKS TO ALL MY PATREONS

EXTRA SPECIAL THANKS TO TOP PATREONS:

RHZ
RC_Meatpuppet
Sam M.
mobilevil
June M.
Sunrise Redeemer
Wabbajack

twitter.com/kandowontu
patreon.com/kandowontu
discord.gg/U4CtzqDGa5