SHIN MEGAMI TENSEI
ENGLISH TRANSLATION V1.00
Copyright 2002 by Aeon Genesis
http://agtp.romhack.net

ToC

0.  PLEASE NOTE
1.  About Shin Megami Tensei
2.  Patch History
3.  Features
3.  Patch Credits and Contributors
4.  Known issues
4.1 The Game that Hates Emulators
5.  Application Instructions

-------------
0.PLEASE NOTE
-------------
DO NOT USE ZSNES WITH THIS GAME. As of this writing
(6/30/02) ZSNES' SPC engine sometimes causes the
game to lock up when changing scenes.

THIS PATCH IS FOR USE WITH THE FOLLOWING (INCORRECTLY)
LABELED ROM _ONLY_: "DIGITAL DEVIL STORY V1.0 (J)"
DO NOT TRY TO USE IT WITH V1.1, IT WILL _NOT_ WORK.

--------------------------
1.About Shin Megami Tensei
--------------------------
Shin Megami Tensei (referred to from here on as SMT)
is an RPG released by Atlus on October 30, 1992 on
the Super Famicom/SuperNES system. The graphics are
astounding for its time, the story is deep and quite
literally involving, and best of all, you the player
have a large effect on the final outcome of the game.
You are -not- limited to a rail, you do -not- have
to always choose the same side of the conflict. You
have the freedom to decide, on your own, which side
of the conflict, if either, is right and which is
wrong.

---------------
2.Patch History
---------------
Work started on Shin Megami Tensei back around
March of the year 2001. DDS did some preliminary
translation work, but the scripts were messy and
they needed a redump. Ian Kelley, famed for writing
many strategy guides as well as being the translator
(note: NOT the scriptwriter) for J2E Translations'
Final Fantasy IV project, jumped on the bandwagon
during the summer of 2001, but the scripts were
still sadly flawed. Early in the year 2002, I
finally got the urge to debunk (most of) the totally
insane control code system in the game and produced
some (relatively) clean script dumps. After four
months of blood, sweat, and tears on my part and
Ian's part, the final result is now in your hands.

June 30, 2002 - Initial version 1.00 Release

----------
3.Features
----------
Since SMT is probably my biggest accomplishment yet,
I thought I should let you, the reader, in on some of
what the translated ROM image, after application of
the IPS patch, features.

-300 kilobytes of English script! The original Japanese
script probably amounted to about 100K total, not counting
the fact that Japanese characters take up twice as much
space as English characters in computer generated text files
(but not in the ROM image, mind you.)

-An extra 512K of blank space was tacked onto the end of
the ROM to accomodate the new script, and the method that
the game uses to find its text was reprogrammed so as to
make full use of this new space.

-Fully autotruncated names for monsters, items, and spells!
Whenever one of the above is greater than eight characters,
its name will automatically be truncated in menus but not
in actual dialogue! This way the original names of all of
the enemies and items is retained, with the longest enemy
name weighing in at seventeen full letters!

-Romanized, rather than translated, race names! A lot of
the races would sound really bloody dumb when translated,
so in keeping with the spirit of the game they were left
untouched. A full explanation of what each race name means,
as well as the characteristics of the demons belonging to
that race, is included in the accompanying manual.

-A subtitled title screen! Rather than try to do the
original graphic justice, which probably couldn't be done
in the first place, the five kanji that read "SHIN MEGAMI
TENSEI" were retained and their meaning, or romanization
as the case may be, was simply layered underneath them.

-An dynamically expanding combat text window! The problem
arose that the top line of the combat window was always
occupied by the number of demons you faced along with
their name, so we only really had one line for text. The
window can easily be expanded, but only from the first
line -- if we tried to do anything else, the window
glitched! The problem was that if the window were any
larger than two lines, it started covering up characters'
status readouts and ruined the ability for the player to
effectively form his or her strategy. An extra control
code was rigged up, and now the window moves seemingly
on its own when necessary!!

-Italicized dialogue for accented and foreign-sounding
people, so their text looks as weird as it should sound :D

---------------
4.Patch Credits
---------------
THE SHIN MEGAMI TENSEI TEAM
Main Team:
Gideon Zhi - Project leader, romhacker
Ian Kelley - Translator

Special Thanks
Klarth - Semi-generic inserter used in the project
Akujin - Coded the original script dumper
LordTech - Helped me out with my 24bit pointer
           routine way back when
DDS - Preliminary translation

--------------
4.Known Issues
--------------
There are no known issues.
Please report any bugs, spelling errors, and such
on The Pantheon (http://donut.parodius.com/agtp)
Screenshots are preferred, as are savestates.

If the issue is not a spelling error, grammar quibble,
or line overflow, if it's something weirder (like the
Fuma Bell's effect not wearing off) please test it
in the original Japanese game before posting it on
my board.

---------------------------------
4.1 The Game that Hates Emulators
---------------------------------
The following issues are emulator issues and are NOT
caused by the patch. It is recommended that you use
SNES9X with the game, as ZSNES has a fairly major
bug which causes the game to lock up. The following
are known issues:

Issue: Game locks up when changing scenes
This is a problem with ZSNES' SPC engine.
Use SNES9X.

Issue: The top half of the names in the stat window
are missing.
This is a problem with ZSNES. Use another
emulator.

Issue: Demon fusion graphics are garbled.
Issue with both SNES9X and ZSNES' graphics engines.
I think.

Issue: Fuma Bell effect does not wear off.
I have no idea what causes this, but it's an emulator
issue.

--------------------------
5.Application Instructions
--------------------------
If using SNES9X, make sure that the patch has the same name as your ROM.
In other words, if your ROM is called "smt.smc" make sure the patch
is "smt.ips" okay? If you're using a Mac, a Mac IPS patcher is
available. Check the AGTP Links page. If you're using a copier, you
probably already know how to patch the ROM :) Be sure to apply the
patch to a clean copy of the ROM, and make sure your ROM HAS
a header. If you right-click the ROM and select Properties, it
should read "Size: 1.50MB (1,573,376 bytes)". SNESTool will add all
of your headers for you easily, and you can find it at
http://rpgd.emulationworld.com
In the utilities section, click on the IPS Tools link.
The answers to the questions it asks you do not matter unless you're
using a copier to play the game.