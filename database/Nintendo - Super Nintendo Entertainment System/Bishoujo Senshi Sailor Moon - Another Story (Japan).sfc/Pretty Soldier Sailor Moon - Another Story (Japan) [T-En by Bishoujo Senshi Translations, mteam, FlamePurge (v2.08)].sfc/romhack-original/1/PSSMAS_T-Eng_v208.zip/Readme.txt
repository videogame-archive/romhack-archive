                              Pretty Soldier Sailor Moon: Another Story
                                        English Translation
                                         v2.08 (Sep 1 2021)

====================================================================================================

- Sailor Moon (c) Naoko Takeuchi/PNP, Toei Animation Co., Ltd., Kodansha Ltd., Bandai Co., Ltd.
   Bishoujo Senshi Sailor Moon: Another Story (c) Angel, in addition to the previous holders.
   All rights reserved.

- No ownership is claimed by FlamePurge or mziab over Bishoujo Senshi Sailor Moon: Another Story or
   the franchise from which it originates. Commercial use of this patch, including but not limited
   to reproduction, sale, etc. is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge, mziab, and Bishoujo Senshi Translations are not liable for damage incurred to the
   end-user, their OS, or their hardware while using this patch.

- Apply this patch only to an unheadered "Bishoujo Senshi Sailor Moon - Another Story (Japan).sfc"
   with the following specifications:
     Hashes: CRC32 - 02A442B8
               MD5 - 5F776488E366B6D6B44F6E8A01D9953D
              SHA1 - 137F84BA5D0736B887213E0C0CABD0649BBBAFC7
   mziab's font fix for the prologue crawl on real hardware has been incorporated in this revision.
   Do not apply it in conjunction with this patch.

- Send error reports to FlamePurge or mziab either by posting in the project thread on ROMhacking.net,
   or via the site's PM feature.

- Players are encouraged to keep a backup of their original game file in case an error occurs.


   Table of Contents

To reach a given section, Ctrl+F the text fragments in brackets.


Preface ............ [RM01]
Game Controls ...... [RM02]
Additional Patches . [RM03]
Cheat Codes ........ [RM04]
   Easy Mode ...... [REM4]
   Very Easy Mode . [RVE4]
   Debug Mode ..... [RDB4]
Changelog .......... [RM05]
Reflections ........ [RM06]
Credits ............ [RM07]

====================================================================================================

   [RM01] Preface

Bishoujo Senshi Sailor Moon: Another Story is, to date, the only officially-released Sailor Moon
role-playing game. However, it didn't cross the pond for a myriad of reasons. The common assumption
is inclusion of elements from seasons R and S, while North America was just getting season 1 when
the game launched.

Thankfully, some starry-eyed fans remained undeterred, and resolved to see the game in English.
Together they formed Bishoujo Senshi Translations, and in 1999 distributed v1.00 of Another Story's
translation. It was marvelous to play this hidden Sailor Moon tale with an English localization, but
as the years went by, more and more fans noticed glaring issues and holes in the script.

Unfortunately, it seems the pure and literal experience that BST intended to deliver fell flat. The
Liner Notes go into slightly more detail, but a lot of mistranslations and even outright made-up
dialogue meant that wide swaths of conversations were confusing or just plain nonsensical. That's
not to discredit them entirely, though; they did some amazing things, such as filling in certain
plot holes, and of course the reprogramming is top-notch. However, polish was severely needed.

The relocalization began when I messaged Hiei- after the French translation patch was released. He
put me in contact with mziab, and we began tinkering away at a new English Another Story, working it
into something more reminiscent of an official 2019 release. Even the minutest change had thought
put into it, in an attempt to to make the game's presentation more cohesive and professional.

To the best of our knowledge, every mistranslation that was noticed has been corrected, but please
note that some may have slipped through the cracks.

If there are questions about character names, lore terms, or Another Story's place in the series
timeline, please check the included Liner Notes.

====================================================================================================

   [RM02] Game Controls

FIELD MAP
   Control Pad: Move in indicated direction, move confirmation prompt cursor
      A Button: Talk, examine, confirm, advance text
      B Button: Run
      X Button: Main menu
      Y Button: Advance text
  START Button: Make Up Link menu
 SELECT Button: Options menu
L or R Buttons: Sprint


MENUS
   Control Pad: Scroll in indicated direction
      A Button: Confirm, exit Puzzle screen
      B Button: Cancel
      X Button: View character status in Form Party and Make Up Link menus
      Y Button: Register Link Tech in Make Up Link menu
  START Button: Exit Form Party and Make Up Link menus
L or R Buttons: Flip pages left/right in main menu, flip pages down/up in battle menu, switch target
                 when using Attack command in battle


WORLD MAP
        Control Pad Up: Forward
      Control Pad Down: Backward
Control Pad Left/Right: Turn in indicated direction
              A Button: Enter town
              X Button: View/exit map
              Y Button: Special teleport
        L or R Buttons: Move left/right without turning

Simultaneously press the L, R, START, and SELECT Buttons at any time to perform a soft reset.

Visit the Juban clock shop and Crown Arcade for detailed tutorial information.

====================================================================================================

   [RM03] Additional Patches

These can be applied before or after the translation patch.

- PSSMAS Grind-Be-Gone v1.00.IPS (by mziab)
   Halves enemy encounter rate while doubling earned XP and yen. Can be combined with the cheat
   codes below.

- PSSMAS Swiss Manicure v1.00.IPS (by mziab)
   In the Keines Village item shop, the item Schwartz (Cures Numb) is replaced by the item Manicure
   (Temporarily boosts ATK +5). This should aid in finishing Chapter 2/Mercury.

====================================================================================================

   [RM04] Cheat Codes

These codes exist in the unaltered game, but it wouldn't be a proper 20th Anniversary release if
they were omitted from the readme.


 1. [REM4] Easy Mode - Begin at LV 16

At the title screen, hold down the X Button on Controller 1, then press the START Button. A chime
will ring, and all ten Sailor Soldiers will start a New Game at level 16.

----------------------------------------------------------------------------------------------------

 2. [RVE4] Very Easy Mode - Begin at LV 99

During the prologue sequence, hold down the A Button on Controller 2, and on Controller 1's D-Pad,
press:

- Up x2
- Down x2
- Left x2
- Right

Sailor Moon will say, "Onegai, Ginzuishou!" ("I beg you, Silver Crystal!") All ten Sailor Soldiers
will start a New Game at level 99 with maximum stats.

----------------------------------------------------------------------------------------------------

 3. [RDB4] Debug Mode - Enable the debug settings!

This one's a bit difficult to enter, and a little more involved than the previous codes. During the
prologue sequence, hold down the R Button on Controller 1, then quickly press:

- Down x5
- Right x5
- Up x5
- Left x5
- Up, Down, Left, Right
- B Button
- A Button

A randomized voice clip will play, and the following commands are enabled on Controller 2.

  - Map Select: Press the R Button at the title screen. 000 will display in the upper left-hand
     corner of the screen. The A Button raises the third digit, the B Button raises the second,
     and the Y Button raises the first. Note that not all possible values are valid, and invalid
     values will lead to a soft- or hard-lock.

  - Debug Display: Press the R Button during gameplay. The top of the screen will show coordinates
     of the Sailor Soldier currently under the player's control, plus other unknown info. Pressing
     the R Button again will close it.

  - Event Flag Editor: Press the Y Button during gameplay. Digits will display in the upper
     left-hand corner of the screen. Use the D-Pad to scroll through the four numbers on the left.
     This can also open in tandem with the Debug Display, if the Display is opened first. Press the
     Y Button again to close the Editor.

  - Walk Through Walls: Press the START Button. This will allow the currently-controlled Sailor
     Soldier to pass through solid objects. Press the START Button again to disable it.

====================================================================================================

   [RM05] Changelog

v2.08 (Sep 1 2021)

- Text in Collector's Pawn Shop now reflects the true reward for selling the rare item Studio Cap.

- Added Swiss Manicure patch.

----------------------------------------------------------------------------------------------------

v2.07 (Feb 22 2021)

- Another typo correction in Chapter 2/Venus.

- Two instances of mid-sentence double spaces fixed.

- Lore term Hikawa Shrine corrected.

- Accessory name change to better reflect its Japanese name.

- A massive mistranslation due to ignorance inserted has been corrected. This is sheerly the fault
   of FlamePurge and mziab had no part in this. Please understand that this happened due to ignorance,
   not maliciousness.

----------------------------------------------------------------------------------------------------

v2.06 (Nov 21 2020)

- One minor typo fix in Chapter 2/Venus.

- Trivia: Released on the anniversary of the episode airing of Sailor Moon (1990's) where Sailor
   Venus appeared for the first time.

----------------------------------------------------------------------------------------------------

v2.05 (Jun 6 2020)

- One year anniversary release. Space character of 16x16 dialogue font decreased from 7 pixels to 4.
   Lots of line reformatting as a result.

- Small change to world map font's uppercase N.

- Handful of dialogue revisions.

- Lore terms Tomoe Research Labs, Dream Land, and Venus Love Me Chain corrected.

- Credit information at pink logo title screen remade to match original Japanese style.

----------------------------------------------------------------------------------------------------

v2.04 (Sep 10 2019)

- Even more typo fixes. Thanks to Sissy Blade for reporting!

- Small change to battle and menu fonts' uppercase N.

- Happy 20th anniversary to Another Story in English!

- Trivia: Released on Ami Mizuno's birthday, just like the 1999 patch.

----------------------------------------------------------------------------------------------------

v2.03 (Jun 30 2019)

- Yet more typo fixes. Thanks especially to MisterRadon for reporting!

- Fixed several gemstone accessory descriptions.

- Trivia: Released on Usagi and Chibi-Usa Tsukino's birthday.

----------------------------------------------------------------------------------------------------

v2.02 (Jun 14 2019)

- More typo fixes. Again, thank you to those who reported!

----------------------------------------------------------------------------------------------------

v2.01 (Jun 10 2019)

- Typo fixes. Thanks to all who reported!

- Fixed error with enemy names Ruin RaiderA and Ruin RaiderB.

- Fixed error of duplicate Evil Surge tech, which removed "Need more EP" message.

----------------------------------------------------------------------------------------------------

v2.00 (Jun 6 2019)

- Entirely relocalized script, including correction of over 400 mistranslations.

- General series terminology updated to current official English series standard as of 2019.

- Several terms exclusive to the game were relocalized.

- Retranslated and re-truncated descriptions of Basic Techs, Link Techs, and Formation Techs.

- Retranslated and re-truncated descriptions of various items.

- Retranslated enemy names, the majority taken from Ian Miller's etymology research.

- Multiple item names have been updated and corrected.

- Slight updates to 16x16 dialogue font; large updates to 8x8 menu fonts.

- Revised English title logo. (Credit to M0nsieurL)

- Modified original patch's Juuban Hospital sign to reflect spelling used in this revision.

- Corrected error where Usagi's portrait was used in an instance where Sailor Moon's portrait is
   meant to display.

- Corrected error where Artemis' portrait was used in an instance where Sailor Venus' portrait is
   meant to display.

- Added missing portraits to Chapter 5/Chibi Moon post-boss scene if the player brings a team of
   mixed Inner Soldiers and Outer Soldiers.

- Fixed bug from the original game, where the player's chosen dialogue font color would be ignored
   for the first few lines of Chapter 2/Jupiter. (Credit to mziab)

- Fixed bug from the original game, where item Red Berry would be selectable in battle to cure Stone
   status, but cursor couldn't target afflicted allies. (Credit to mziab)

- In original game, player could not view Status menu of allies afflicted with Stone status. This
   restriction was removed. (Credit to mziab)

- Applied intro fix patch, which corrects dialogue font during the prologue crawl on real hardware.
   (Credit to mziab)

- Provided bonus patch, which reduces enemy encounters by half, while doubling earned XP and yen.
   (Credit to mziab)

- Trivia: Released on the anniversary of the episode airing of Sailor Moon Crystal in which
   Professor Tomoe was defeated.

----------------------------------------------------------------------------------------------------

v1.00 (Sep 10 1999)

- Bishoujo Senshi Translations' initial release. Complete English translation of PSSM:AS. Includes
   16x16 variable width font, translated building signs, and increased dialogue text speeds.

- Trivia: Released on Ami Mizuno's birthday.

====================================================================================================

   [RM06] Reflections

  mziab

I can say for a fact that Sailor Moon has been my first serious exposure to anime. Around the same
time I also discovered emulation and JRPGs. So when I stumbled upon Sailor Moon: Another Story and
the BST fan translation, it felt like a dream come true. I've loved the game. So much so, in fact,
that I took it upon myself to translate it to my mother tongue as one of my first ROM hacking
projects. I'll spare you the trials and tribulations involved, but in the process of making it, I've
noticed that apart from some terms being kept romanized, some parts didn't really make sense.
I chalked that up to Japanese-y game writing, fixed them the best I could at the time and mostly
forgot all about it after my patch was done.

It was only years later, when I wanted to revisit the game, that I took a quick peek at the original
Japanese script and discovered that what I'd seen so far was just the tip of the iceberg. And since
I already had most of the necessary tools left over, the idea of touching up the English translation
did cross my mind, of course. But due to real life and other projects, this idea never got off the
ground.

...Not until my help with the French translation caught the eye of FlamePurge, who had the same idea
of touching up the translation, but lacked the tools. Since my own efforts had been fruitless and I
really wanted to see it done, I promised to share what I had. That would've probably been the end of
my involvement, but... seeing vivify's passion for the game and the franchise in general reignited
my own and that's how this collaboration came to be.

I ended up sharing a lot of my old doubts about the script, old notes and trivia, not to mention
rewriting some of the tools and doing some extra hacking. We've spent many days going over the
script, discussing everything and anything that looked remotely suspect, uncovering more in the
process, bouncing ideas off of each other and generally putting in as much time as humanly possible
into this passion project. We even ended up discovering and fixing some original game bugs!

It's been a really fun ride, even if parts of it had me doubting our collective sanity, heh. In any
case, I hope you will enjoy our little offering! We've done our utmost, but we're only human, so cut
us some slack, 'kay?


  FlamePurge

I've been into Sailor Moon since I was 2 years old; I was hooked from my first episode. Later, in my
teenaged years I discovered emulation. So naturally, I came across Sailor Moon: Another Story.

Even when I initially played it, the dialogue seemed questionable at best. I didn't really like the
Japanese words peppered through the script, and some conversations just made no sense. But the patch
had been released years ago, so there was nothing that could really be done.

Sailor Moon saw a renaissance in the 2010's, and with it came a renewed interest in fan translations
of its games. It was then I recalled Another Story... Seeming to suffer from the classic "literal
means pure" problem, its translation begged for an improvement, and I wanted to be the one who made
it. Unfortunately, I'm not capable of anything that extensive, so I was prepared to let these dreams
slip by.

However, by chance I stumbled upon the French translation patch of Another Story by Hiei's team. I
jumped at the mere idea of being able to finally give the script the love it deserves, and better
showcase FuSoYa's masterful reprogramming. That's how I met my friend mziab, the guy behind the
Polish translation, among others.

I thought the project would be a simple matter of rewriting the existing dialogue... I was very
wrong. It's no exaggeration when we say 400+ mistranslations have been corrected. Even throughout
the beta test we were finding dialogue that was just completely off-base. It was an interesting
endeavor nonetheless, though; I'd worked on a couple of fan localizations before, and this was my
first time really collabing and bouncing ideas off of another team member. I very much enjoyed that
aspect, and having some moral support by my side helped when things got to be too much. I hope to be
able to collaborate like this more in the future!

Despite all the frustrations we encountered, I knew it'd be worth it in the end. With Sailor Moon,
it always is. After all, everyone knows you just can't keep a good Moon Princess down.

====================================================================================================

   [RM07] Credits

- Bishoujo Senshi Translations: Moose M., Lina`chan, Nuku-Nuku, Janitha R., SoM2Freak, Harmony7,
   Xeur, FuSoYa, Kisai, Cecil StormClaw

- mziab: Tools, reprogramming, data insertion, graphical editing, retranslation, Chapter 2/Jupiter
   font color fix, Red Berry fix, Status menu/Stone improvement, Grind-Be-Gone patch, Swiss Manicure
   patch

- FlamePurge: Font editing, text editing, graphic editing, localization, scriptwriting

- ffgriever: Retranslation support

- Kini: Retranslation support

- Rose: Retranslation support

- M0nsieurL: Pink title logo

Special thanks to Hiei-, Lord, FantasyAnime, Ami Sapphire, Sissy Blade, SerYoGa, Midna, additional
helpers, and all you Moonies out there!